<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoOA2yO0r8/ftRgUvIXEs46Nwke0Kig5azfH91uBE/UtgcC0eCg9uJYXqSfDKJRHfSr0w/q7
RG7ki1Qlqc9DCEFQSlrJ6Ci0MORny3/VNfufMj1QT6/Vusq8j7wGGcRsezVkUb6yOW/MRP7dZ6PW
kv5+24Wiq4IlEHbFKr8QX8WA5SoKWDCorubjtqlZp9h7MiYTHQIFB3kX+YuY5ie+LDRgxgTPJFSc
qduv8oTr7Uu6LX6yZDvaMMCuq4kkvmdj9TvfFoqo3Vm8Ha/vA09wQdSnyf9DQ529w2RKTHR5ZKx8
7ZZ+5FypiVRS6F27bTvsPRk7P+KY/TIXIIeJOVV2ogP2xG+ZCOqjlgIH+M2vQdhqKqpXX7CxE1tM
tXk01cB+aAD5b9UqwqfQu8W8NZM03FQXeub4ipM0WNlrZCRhoon7T1gcZNlDeruYVoza7BZXBw1u
VO50uB3hXXvm6Ltt8LDhcdxlUZSp7F1Sk8hKYzzFVPdszUO7ZqRboUTVuUX2EFyD2Adgh90prri9
bm9a1Ibv2RlRJOo7A4ugGU/zIjxWpojDilWaPeyAHxEhpKttOFe9vWUMnxaW/TUMuBY/C6n8zX+f
A+FD8Tet72WNGS+ERjYxrqqS6iF3ck94rtBgDnmtci8DCk5czMZ4TQhOErrwkYUAM0yrEWGxY/0J
ZxRelBuG8Od9Hj/QwHhe0f5ms+CHdbzx6b+gZOrpUdf5+jPDwVb1TZyrCvX2N9OEXDCuM/xMR78L
NyJg9AHhaonDQdxBijAVQcjQ1h1wTKkbTrXiAl2Nac3sZqdF0W8fBYiCo5//TKzIzZB6179GNmYC
V8EBl7U2rrY5ZDkUXCON6OwtzE729U0WyaAv0ESevUITmauQud/ge4NTnfG=