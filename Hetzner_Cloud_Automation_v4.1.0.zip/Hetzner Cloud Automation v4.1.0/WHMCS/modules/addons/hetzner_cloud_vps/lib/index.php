<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/9ppaDCtp9q2SDRO94WCAm1UH0HSWZFyRouLa2LZL5Z+tcLIuebKrVxd27iUbqaZ5yVFQAs
0901z7gBnqWkF+LkgVihWgVsfK6zTtwoo5bQAMCJzonGl//pg+/MHLOcwlr6dZy3fMCip6hpLbEd
HxXp0RiVVQd9ouKjYMyreCOlNw1uNJU8ITxeWIwjk4bVDNhoZdXv9wD4h+IQLkIbGcDv+97gjOwp
k45/FSg6Q95yesyaNXJAiNMrQgiBftezDEt4BJ8D/0X6J/ae0dfgTp7oai9cVm+PlnG34EkOowWT
EFu1k+8bWYzUHmenwgyhosGLXnNFuaEeaKI6T27wjiRLGhRkaggaSoNvhdVX/SegO5Dw59I4+wiI
7LOVLJa/Tgpw90j6fyWVGzcKe42LfgWdhaU9hpD2OjC1rL6etEDn624Ddb/NK3DnHbnujz/aRNuF
HXeTMRhK8iSePdRGZmO3ul+6C+LY3WwOf8rTyLifsvfzzyfJEFKULwLFeAEDvhnimGkTPfQMmh5Z
SLebGnZ99cjDkBEGkhJO1ddv/PU1pniuXxdFkIoQgODwZNMb0nlOWiTJ/IwvnbQZASD+PaHgHCJ9
1Ok8U62L+jMX8D60SyU69Nh32ZBIzWkRKZiAIQQA5y4AkF9O91YhNWqUmOSD3S9ElFpSSZIGOzez
Yh7QbzuFiE5kCbSF7/YbnQb7rIje0kQhHmaAtnR4OGDKGhjoblGYOK5DExH4FLDnrHBukpS7srUu
03hRgnPf373L9cZqZ+M0jzWEU0eDpTMNLsguUAtsZiA0FLKK1Rj4RhsrNr1vIaZ40VTkdG0Mqb6p
l5zzZrL0cI4HIfEHsj8gfPoyg9Ysr1lUu7j1tDSBkv2rJr7yasXYiUpJn8G=