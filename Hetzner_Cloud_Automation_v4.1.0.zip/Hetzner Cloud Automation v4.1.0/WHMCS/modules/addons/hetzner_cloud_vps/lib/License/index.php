<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv8ekM2GzG5NRPWiGrF1SNcvK3I9K47ECOouQT1B4Pfulkv5+gcAU8eFQPA/SIXzQsiOSpqk
h4GTJHFilqefEQWG+myTTUXoZKnKU5vJYJZSx9JDTN0eUN5LqCFF/Dh4kE3kOmsmEvJFa1Qo8utD
NDxzSTUiFyDL4YnViTwFAIzQOurTnK3BqpDzEbGlr5G4yDZ6DDBP+ro8jjg3m0UiPuM7JMCDNSwx
CBKZAsxolqVL0W5ibYY8HpKcENwWWuPFxDlUBJ8D/0X6J/ae0dfgTp7oaWDbqwq+scm2wTSHcSWU
azuN/srXtbWUWnf4lk2C4jKHUnTPFyWAvI9C+w3Q7lYiu7r9vXwOmXB92+haU2CnK6gjhW2xusJC
SL0MaeXuJ/at/QpOSPL2zla2OMpI2OkXXdmBie1uDYEi6kGMAfrwK9oDWFBaCumfsjGtrC1X2nVl
nWQuiEyzhbhirPMEclYhtqg8N6wLiIaXu6Xia0YBXUDzwE5+HLCr5Y/TaeC/W8bysGtPhygz6nmU
bCTiW+mNcpWbbzB72aoFlHZKH0kmpxI5IEV2L1u9y5hvz51gjmezWXDxEDpYQSJS8asWLVC8nvby
aeXs9+3o0ZSJ1Q+CcOGBheyYOrtIbYvliHSL4J6BUmMjNmujEZhnOjdG83Jzn7BvL5r7c4M581Jq
jROQKo8EerCDE0ca3mDPjRpv6uzr2GXCBYvg4I2XrkFsHYArXRVTUScomc/vcEQGov3nT5vgLaA4
2aXPpJXwthhpvrefmeGDS/fzaPDnWCW7PHT5DUSvhuqQ9tjuEqW9qdHTafs0L9SJ2fG/FglcBaxR
2Retm0fEVzbmn4Y+rA7ef44SV2obkHcEh4OE1jC6Pz8tjOokNyx4Im==