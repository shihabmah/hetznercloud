<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmnKoVK03JBwtP5SrY7pZQaPNUujzZ7ZzvouWS5cP49TVBGZDE6BpESwkTIJMjrEvfuoHk/q
JyVGRdDlcp/btNHOUfYHWdbBLNLYRAZjz1z4jYYX2qTC7vfR1c5ItggSt3RzhBl/O/muPYCsixyC
yrZ1TtrqXalw38E/vMhE5o6wWK5J5eoeCclG+/3dflCctzkigl8x/FV8UjQ+hNL9IeRr8DDhaSz4
/3xuztaDBvk72NK4FJgR6S2bph9urwGgfQucBJ8D/0X6J/ae0dfgTp7oaZfkOpSXZmBgDpn96QYT
aTvrIzrEooufIFlQVuSCe16qyekcB67H0QoEEXt3DOqa8BU6iGP3DkYV0pj+dqes+PQW3M0IhzcK
QKLPs5e0FphOPv9UppQKyK7TTs2uTPL7YKSWSXWPKGiJOA8JRBpSiF1Etz4zZ51ED5+yo/Y+NKcT
0gozhJljHInb+HvKCJYRIKdtUQVD9IAJSZySgcfJUdxBkdb6BnNgJNuNKJkJoJbJSQnLYySkBoqD
iKmHWFHQawoLRKoWidRJnKEhbpEFIWtOxLhNH83a5pyauvcLqWq5yj8iLJ4dc57hl2s0JsKcAAmh
uciT1udCfsn0LWH1gxjsY+8W+GxZhQk2P1uLWFPgify5Wndq6yHi/yzRSh0QR3hU27rzXOhe/wA7
aBOTULyM0521gQW5Ge0/sASohmmF6B5M918fhmRr/GXFBAUAXUSo01pJKXRzUIDtOmvHN6xcrnkG
5bCz5eg6Yf6cH9rH8YrUxAG0tawVJ3fNmxGTwc69trlpC9u6W/DF3HQ3vVRvARP4ZlSxQFh1FUj+
dO22HJKS3SxmhAVjA+cwN+ZzgliYlHz3A7nWDRkgW0bZG8D/Ce9UQlmq+3HVYtS0sgbsE7Gq4X7X
xOHhdgCzyhmC49UH2EqfclwBXsmClGGuAW/CiR0JTxFBx5PRJ45q1PI2hX9BffVsweVChafrKnok
lHygvyky8NZCbc1sPC6yRYUOE9+HWu6ETEgimi04XSkG2lLSIxt/OsJkvf4AonbGGy2LkbzxXU8u
BgHCdfvS6xHA4qxPio3W0y4nl1isReSB/boMVbP9jnvkdDAAkJfNdjxUJ5YnOJ4DuBm/oxH1lWRC
vHk4B7+F2re9a9/Z6e+sC83l0mjGaxvqLkwVzgGBcuFY97pRg/N5qT9jX6Q/anOPIV9/2GjT04HO
MNiJsOm0baVbCct87cipG4vbx7VKcqU00Y8nNTLcCOD8gRVHPonhNoDO7/pPfwbua3QlPzEhGcSC
8OnVrvsCmZylR079rwLvfHXuhfWFEQyMD9hihJz1tqTooPJr4jLNCCQ+/XLR20i3Q46xyfBcNV7c
HOZrT/EHsHEmtpA468jrgP76XRMaRbwg+2dDGYFAroWF5aJzzIIW0sR9eWTdA1fH8+cuXWI2zOcV
XnNauPQdBxxAu/cCxPE7QnuncWQdu/ahL+QgXI/WFYuWjAZEzc4JjV0Nmwlp6H6+hV9xYt+9EWTP
gqDim5wdajEXPvMx2MbdPBAY97MPyQ/GGfMkDvxgtZyojmM+j+fsOMvX/pu0vJQOvpSWZnZnG8hM
tZilkwYF9Z7T5pBAr9AhKrFpl3aXzBeXqCUS1yqS3JGrGhi9+9Hi2iPLb9krEY8PKLpw9Fs2OYTh
ayJZuphNTdhIyFbxpTWTw3EIY9WP34d27Ij0km0tHG6wM9b1BUz4A8xIdpHPJPuMVlONTrtV6oPq
q3ecJkTisl4LaKJoZEivfWvna2EsAWl5UZyMpNoERaD1O+IaUXK2XVdqZ9AccDEPIdXs5C50jZyQ
LZuZcqAS4RLHd+j+m+IVBO8IpX8Feic/fsGKqvYZiYW3V8XPw0UEkCr+ic24DCGinL1jSdKtYExT
NB+GXqqf5N+vulNZvVLyaNT5HUqgjqbVn2EXgKKAPblA6C/uNfUAD5e6o8a80xtXBEBW8kRLd3To
elFeqkFCKWYZgkQOoIyd2CS0fY6XKXcTgGKQ7n47PZ0l9MwSM0JfY2kebp8wCNI6JOrgTWArUY3/
llvHNFl8BgFu4Q3htx5i7fwAcCV4PLvJj02MRhax3GqQkNu0sYEvI4nAm42YR32Zn4AiPbpX9fVA
8oKuZpkYnRZXK4yhzfv3/RVQCwCYpVmrG2w95uBu51pozPu7GEiph32W7NkvLBval4rrWu4ABoT/
4YjDIvNoZbaIaHUcgTeMx2yJmyQQhNDZzw07aLre9/bVnFyWupyqSb8oi5Ply3kVAmFL7SX8xIwJ
ec4v3kMX+4U8T/sGmPCtW5MX64SP8IQOhHAaK1WdkO1x9q10O41joOHAfwjHmCZoKJGdQkKAX4Io
xN3q3NTQXldC1yykGjqp1yqrrzZnYeMqs7Bj0w8lay6FXGCL8sCS27SrmP9fT1VpJ95SdWm2dAhu
gZVDEmJWeZSH58kbD49XAg5QjCAV0ZWGKYlZsHrWMG7y+A0p5bwmpXa7p/YY8E/c+fRiTmMz6G0g
HtBknkC7/ksLRU3C8gq9KXEG1GU6DtkTLg5I2/fnbtIFahirYA43jOvUD53o+HReXtUAXJ3GvvVY
9A1gdOMZH3My1PhAG7HNJy9lPMo3ILHHNcrwqHNYP9++ftq3dK50GxwyS+mL/KqXKA5AbGsPOpvc
/xmozIbg0U2JJtaxqOWWs5iRnrO4ko9wDTGtVtc19TSa+nVPc5KADPNfD93JEkABb2ye2i6cTUds
HvOQsFGqPYuB+CQ2Yn9Ue3lSLyYMP/RW6QJyUHPyS3IytI4QguJOpvAZL1TlG2FDq3wr21KZ6hh/
LLZjSkm66KgXM3fitDVEc0K8O76ik8c1K1NrjDZDB5r+W5FAnFrDUDpe8xYm1+6NHPIdHPJsBPWJ
pUzpK3HwCIq96RhoWxarjTfXx6NOvSZ7uxZvRhB2DjI8T3wjXC0Ep4hTZuK6cds7Y4n8Ca4Ph4dY
23bF8za6fzLVhMSligv9zQcZR3SnE9f2YaqM7B9nw3bhojQtmy3ApSFL6+cedT5v7jkfa+Eo13cK
9+KEZNzTiURWE/unlMSEVSFbyN+7jD5Vl+evUJl8oxuwvR6B16N/tB3eODlzmESJMX6eP6ZI6eFj
fDxm6h/RaEkGnGt/fAjBmUwdiEeK8gfu2oEXpDBeLB35IBZHWLZt0WEmMLvFvNQAK4nO1ID3AYiZ
F+k1+L3E+7vdZk4jIodSNjpWVb4TXzW7CST2w5q/G3lHLLozSIGoGgoSys+whTFBa+NmjWfeCqK5
XX1u/lWWzyonxRczNpCKEKKO5FrJ1deNWI4FDLEnNlA83E6FEzedpwqaDaNH1t8+OFDwN69MpBtt
JyDJekzCdIBlnzY1qihvtYzv8w7S1TeHDWDB9w0JJS76b6dSgah6DKr1MKagqJOBWvJo2iItsEfM
Na6m5zaJxMtfSFy4eY5JNw9UwMOddjkuaib4WGpMCNyUb/mTTgYbu+WBGuW2zot/UFpU8PI2O5x4
p9i7TundQR3ezg5K26ceikM2fq2FRenUgj27uv7eR4nQl3Q/yoJVCiby1fznqEoNNBhD9rGegYtQ
T4rDxD5MoIKIVVlbqm2d9/82lg6Q0sMw+8Fgt1wJLUV3WeIvmBLqXb+16pYnH/xNSutw8wL0deUq
hBZZfyLtua75SYHyk+HSR11o4lJFtZ+T/0nQUCqjXctLeWGVq4LynQC83jDA9NTtEjBu+utvnsUz
mb1MVqPeWaO+WsWOUAKtxaWi7AdcKtzCnXKNIgweCK4X0gDyaN1abHNMWbSWrH41KTStG0xToWOm
MbxJMTzINAjT8+3kOyGLK+FY9B8qYX7UUZYPlPlPwOY2HV/rOlKLBtoc7JORt+D2mSi62PbOXcNf
KNY9tfJGLwsiIHIUdjxsZ/pmuZF0c2wLJtS3dAY/t600EG4RArXZeeamQFjTws5tKkwEezM4mbeP
buiE5TgsX3CLMIMFYD97aFBZX35kQJwHKu/mK8rVkSTAu2d3R7uBMz7qljisVtagG4N7C+eZXHj9
vzIHXft0Qkunn+XeSnQv52xGKoVmz4vdBTFl/wWX/8Qv/i2u7uhKprfpEqE/b2YjnTixcA1N4EPX
aoyOXbF8Cw2bImclGKt/28PMn83gRVmx5mi9DULayplIkq8JLCDRRAETLwIsWj6X1k2IT9hg4KSv
ohc6zUxg59MpPTAPFKzEKSgdcFvV3S5TiSuWO5EdKQgWb9+gDwmLEiHPydyjuR50xULwdTI+GDjC
vlfIPRgpJWKBFeHo0jTT6ARBgg6aGGHt4NG2J1IouV3O8cB4SuiG6TxKlp7Ufb/WzQ9ns2lK0jPI
cBhNYtiZ3sAutAtEhrZAPFnGYcQLx32cWtNORmcBV0m8rWvKcd/E66OJxsONbDJUK4YMnDMsbcGj
tMxI0IcjZmDuWslI9J6QN5i3Bga6ClS3oLUKoIfg1pT3uvaT1fZt4IhSJK8Me8AxriRorVaijJZn
FwkpJrv2qAs1Q322VxwISPqR4X/p2f9Ipt7j8tb/uWpFY1SBwyz2439o01z62jCkNbEt9DUD/ooN
ez6QdpjFak+RDNxCDTuO2zHnJ6mct9BEieFKQzTlQQeDcairLDtFlDdYnqS2LQK2swVBJFaGUVCL
rEKig/cd3cpPz5Dk40ePTrswGaMxGkugkkm00ItnLC6yEYX88k3RQQXUjrVcPvmvdD1byplFrIjf
Zjs4oNRYFfKB/3HCFkwPmigqRVr2zgqULNMWlL+3phz16WJuSOniNoIid7RrCkZ2jQ0jI0UBruEF
OUVyvkG/xGmqPzKau/nn3K6Y02XT/yZJsU66aVLjnhVEtP7hYbvWVqIl82U9dgDZCme8MO8PEHN+
nQ3K5D91YZqNqOhdYClnMvvY2bOY2YNeLkkBKQLPgNBMx1euLwkz1emgV5/wAwGLMAJCcNAS32pQ
XWRq+LPbgv5KrOoTfiiSb1wsoLoA3OE8xdGsX3CKOyqY5uKbRCjBBqa5weFvXfu/h8PEGEciLYH2
TV+HoHfXXnc0hT7CITRJJHN74jNUDy+0Gl4kpk23njFHvzrt8WMmVDZLkUb/pn4Kq5G0u7470Orp
4FTICO1bwa9s8aNbSc1Ta1tQgf3CgcPQR54Ti6HoDtPxUCzY55SgcJ2tzKqK9asL2bDBDOD77jYg
/eIR+1b0uDIabslgn3iK8wsa3cP5Y+2sh0qRixvLFSGEpBdb87ciXgVe5d7Gj/QwsCE7XDZsXMmo
0wjcDk/ael2ftlwdaxav5/UeZ56VHPIyTc1X2oCNi33+rjVCCQ3XeXKquI4=