<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoJkqLW5C2gVq5v4UqSRTT2+JK/kdycGwPkuT5cYON0ObuZJIEngQpdMOmF5GjYGAG2KGT2L
hk7lece1E7JpEzFoFK7y7NXKEP0jyQvgSBkG/aNCb6CZ3QNdcvAYpZU6LgdCCFwbsH+lcRpbIlkn
xm9F1Udz6M44iSkm0+bUyHQJj5PO3MK/30KccWDCDsNZjX/GvRhcC2epcKQFAaMECwj+uLWlY+MK
TVgiF+8cssqh4IKmC/fA67JFCQzmGDd8EnUnBJ8D/0X6J/ae0dfgTp7oaffbBaUbO6eb6iwma52X
aDv4/+H6Z9/lbK4Z4aPe98HsLjHsxQy50004n7uJ5m3oL3VpLZ42hD7mBaRjP6cvUrNGNT0FUvRk
bTJbaMDp6PjrrfeuoFPbOC9s+9SMTOt8Zj17JaWxx4zVSHHM0a3m4lRCa1NFzS4rocHi8wf1czG/
Q1f1NGU+1PLpruzz1aTL0v13NaMEEFef/48+OGBeZ842Xb2kZxn+DqlqtyK0PBHbn+71nLQ/r2/t
JP4x2jansoKe/DArUT3d7BCWdXnJAgDxqGhKC9s4UL9HSQa8sHY2IRNDtq1CIL7U/alDcbTmoSAJ
Ozc5FyBhNxu0rI6FKk//fdgaKL1bzERYYzGpDmPaD5LHmw1imlBTZ+hcvLL+rhITrvDqqRcuw/Kz
o2ZzMQvVnlNMM/ntD4AZ5+RpJ1rlbHmkLtBCL0sh4DgcgtjLDv0NFnEGqCzEm2/oyctA/T33i0cF
bJv2B1QdYKAgRHkdsfWfLZP4/E+3gEB5DbDneZ6GaCB0cbCKDcyzTS3gJYvGnherWkGu3buWGXtk
a4XojCt1+Rvuc6LQ7wACTHSAo38QC7SJ1qkdxkWhIArtpsvQUDCuvie+vPkbAzqfsm==