<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwn94jkFbEOSLlc7+3dC/qSFc8JqYZ4DbyPV9dfi9g1nvo1a/edS4g9vWyxi0LrOnG1w3Agb
+fHOZ7eTBs/m99Y+oX7llPRgqDDeiegpf8bhZlXNLT+eD+gskbXE4p8c3BBUPrDxf1tT2wSO9JFW
VJWO8xepuczXXMsSMCBkTYR2USrINIy6LOrPOzZsIUvu17Vq/eyvfyeIpv/2VVeQFX5kNcq3x2f5
Mto0wj19UMC2xsXzgb4L1KU0SOcvrxCl0cEZlIqo3Vm8Ha/vA09wQdSnyfADPW85tAsdNOGuZZfG
ePBUGbphA/j86tqBhNkxgpdgklTbaOXGda4oqAnB53ZN78zjeg4qrED7ZUEbCBPYROAtwORPBg/x
DA+VnDlgAhUX1umtTE2574ECsksGW7Eny+OlojnjeD+cxy3hFHAqVuB8Dw87DWv0np3SNEdQJ+V5
ycHH7TDyVv+3HuCl3Dks47ME3ZQJTiO5Gh3W3hIxZKxIDZDOd8yNkSDTO9+ntejEn/Zamj8m9A3+
+I4t0Q5C0Sf65cFiffqu4oMnVtg55QJ2BnUl0Ev7GUZLxMgqdoj0Ou5HwJ4BtauodsoBeMHnGHCv
fFzpd3ddlYYMbRPaYYg6ZrN7PUxvfpWe207DlHRdfnbEPw9Fh2Yt73TDTFMDHQ4Z5NEClY1XY8lD
hEebNylPx5yOmuOoGmYSIYdyLu2V/tK80jeV8XxghSVWdcO3FsrMnzypmwDS3T50m70LHc/ZYlxe
9SgQuCj/YdU5iIsnHjD7j/f6+LE0ZfKJdvVCv87fa7aFMGu9vy6DZ4zTzk+Uh/EJ0hrHbVpy4SNK
AZwagBpcb3xFRt3sx+wK+FV9GuIHcnOwUZeHkBOhrL9zsGZ8bhAcWzyZc0==