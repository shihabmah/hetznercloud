{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage nofilter}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}

{if $accounts|@count == 0}
    <div class="hcva-highlight-box hcva-highlight-box--warning">
        <i class="fas fa-exclamation-triangle hcva-highlight-icon" aria-hidden="true"></i>
        <span>{$lang.not_configured|default:'This module is not yet configured. Add an account under <strong>Accounts</strong> first.' nofilter}</span>
    </div>
{else}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-camera" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_take_snapshot|default:'Take A Snapshot'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.snapshot_create_note|default:'Snapshot any server in this Project. Publish it and every service on the Project can rebuild from it — this is how a prepared build is offered as an installable image. Snapshot storage is charged per GB per month.'}</p>

        <form method="get" action="" class="hcva-inline-form">
            <input type="hidden" name="module" value="hetzner_cloud_vps">
            <input type="hidden" name="action" value="snapshots">
            <div class="hcva-form-group">
                <label for="hcva-snap-account">{$lang.label_account|default:'Account'}</label>
                <select class="form-control" id="hcva-snap-account" name="account_id" data-hcva-autosubmit>
                    {foreach $accounts as $account}
                        <option value="{$account.id}"{if $account.id == $accountId} selected{/if}>{$account.name|escape}</option>
                    {/foreach}
                </select>
            </div>
        </form>

        <form method="post" action="">
            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
            <input type="hidden" name="module_action" value="create">

            <div class="hcva-form-group">
                <label for="hcva-snap-server">{$lang.label_server|default:'Server'}</label>
                <select class="form-control" id="hcva-snap-server" name="server_id" required>
                    <option value="">{$lang.select_server|default:'Select a server'}</option>
                    {foreach $servers as $server}
                        <option value="{$server.id}">{$server.name|escape} — {$server.ip|escape} ({$server.status|escape})</option>
                    {/foreach}
                </select>
                <div class="hcva-form-hint">{$lang.snapshot_server_hint|default:'The snapshot is taken from the running disk. Shut the server down first for a fully consistent image.'}</div>
            </div>

            <div class="hcva-form-group">
                <label for="hcva-snap-desc">{$lang.label_description|default:'Description'}</label>
                <input type="text" class="form-control" id="hcva-snap-desc" name="description" maxlength="191" placeholder="{$lang.snapshot_desc_placeholder|default:'Windows Server 2022 base build'}">
                <div class="hcva-form-hint">{$lang.snapshot_desc_hint|default:'Leave blank to name it after the server and the current date.'}</div>
            </div>

            <div class="hcva-form-group">
                <label class="hcva-switch">
                    <input type="checkbox" id="hcva-snap-publish" name="publish" value="1">
                    <span class="hcva-switch-track"><span class="hcva-switch-thumb"></span></span>
                    <span class="hcva-switch-text">{$lang.label_publish_now|default:'Publish as an installable image'}</span>
                </label>
                <div class="hcva-form-hint">{$lang.snapshot_publish_hint|default:'Tick this for a prepared build — a Windows install made from an ISO, for example. It then appears in the Reinstall picker for every service on this Project, under Custom.'}</div>
            </div>

            <div class="hcva-form-group">
                <label for="hcva-snap-label">{$lang.label_image_name|default:'Name shown to clients'}</label>
                <input type="text" class="form-control" id="hcva-snap-label" name="label" maxlength="191">
                <div class="hcva-form-hint">{$lang.snapshot_label_hint|default:'Used only when publishing. Leave blank to reuse the description.'}</div>
            </div>

            <button type="submit" class="btn btn-primary"
                data-confirm="{$lang.confirm_snapshot_create|default:'Take a snapshot of this server? Snapshot storage is charged per GB per month for as long as it is kept.'}"
                data-confirm-title="{$lang.heading_take_snapshot|default:'Take A Snapshot'}">
                <i class="fas fa-camera" aria-hidden="true"></i> {$lang.btn_take_snapshot|default:'Take Snapshot'}
            </button>
        </form>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-images" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_snapshots|default:'Published Snapshots'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-snapshot-list" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-snapshot-list">
            <thead>
                <tr>
                    <th>{$lang.col_description|default:'Description'}</th>
                    <th>{$lang.col_size|default:'Size (GB)'}</th>
                    <th>{$lang.col_os|default:'OS'}</th>
                    <th>{$lang.col_published|default:'Published'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach $snapshots as $row}
                <tr>
                    <td>
                        {$row.description|escape}
                        <div class="hcva-muted">#{$row.id}</div>
                    </td>
                    <td>{$row.size}</td>
                    <td>{$row.osFlavor|escape}</td>
                    <td>
                        {if $row.published}
                            <span class="hcva-badge hcva-badge--success">{$lang.word_yes|default:'Yes'}</span>
                        {else}
                            <span class="hcva-badge">{$lang.word_no|default:'No'}</span>
                        {/if}
                    </td>
                    <td>
                        <form method="post" action="" class="hcva-inline-form">
                            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                            <input type="hidden" name="module_action" value="labels">
                            <input type="hidden" name="image_id" value="{$row.id}">
                            <input type="text" class="form-control" name="labels" value="{$row.labels|escape}" placeholder="owner=support" style="width:180px;display:inline-block;">
                            <button type="submit" class="btn btn-default btn-sm">
                                <i class="fas fa-tags" aria-hidden="true"></i> {$lang.btn_label|default:'Add labels'}
                            </button>
                        </form>
                        <form method="post" action="" class="hcva-inline-form">
                            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                            <input type="hidden" name="module_action" value="delete">
                            <input type="hidden" name="image_id" value="{$row.id}">
                            <button type="submit" class="btn btn-danger btn-sm"
                                data-confirm="{$lang.confirm_snapshot_delete|default:'Delete this snapshot? Any service still offering it for rebuild will lose that option.'}"
                                data-confirm-variant="danger">
                                <i class="fas fa-trash" aria-hidden="true"></i> {$lang.btn_delete|default:'Delete'}
                            </button>
                        </form>
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="5">{$lang.no_snapshots|default:'No snapshots exist in this Project.'}</td></tr>
            {/foreach}
            </tbody>
        </table>
        </div>
    </div>
</div>

{/if}
