<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzlIyzzK/vl8425YPlpa9MQP+pWK8ZMX4xYulF6hgY1hIXDt8CX0PVt83ZizrX09jTMCx9Fk
bDY6dBP30c7kKEj5KF9i9AVQFM+q28NYHiVw30EYS58NwwNGhcgkZSz/I98+sab+CHNvdOWuh6Uv
nHBLxgXScFXWnV2HW9AwiF8oohO0GKoXTMoQ+8rk27XS8p1ayEKWDxFog1HF3nhMnQyhbz8cL5DE
sC4auvAgWvgoiWcQSf4KOk9xgqShtxqvT19dBJ8D/0X6J/ae0dfgTp7oakjf3H9KR3lu5lNBLiWU
aTuhOwm17oqPPTNSF+bN2vta3o6Qden0XLr9ofTAFqAfgvJo5n3t2YFkEwkMbcBiFhvFW/a1x076
HC6Ec83HS2rkyvVbuWqWU6Zzm7Ig/duiQTYEfE4SlgXCgbsOCzEvV12mxhNbn8kf4fkji5VDLTly
Lyl/UzZ3sUSdGEiV6oVpZZ7Bw3DTUWY3YRHZ0swi2NI9BkwbKR2T83C49wiZxH2poPlhpzVGWOg1
0vDlcPFsZM/+AirYvV8TY6q4AUZpyH5dW2ycenRpAf1EK0lPEC7SpWvaJHw/EWdBhDjN/1UV8N+9
NdFRUGPe0Gf8Gjg3EyTEVeITJZd7tvvrUYXqM1/p/bDMatcj1UAFmYq4kLhAyKym1VTglEUBBXWC
lPRXgPmOkVfAwVsO2C/EWFuWIjYcIUMaXcb4rR9jK7gxppxaYGqLdLnMEzV88S+d2/0ineejEaYz
FTC9EFXTge71KkHswUIjHigj7URXNoE2PU3Qnivmddm6O8vDI4nVJrCcDZqxf2Y/QST+3ktPEu6x
HBa9ZVdsS4+OIVxijh0WqWgWbcLCOEIvSybwpNwvSiS7P3aJ9oMvzjk1VW==