{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage nofilter}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}
{if $apiError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-triangle hcva-highlight-icon" aria-hidden="true"></i><span>{$apiError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-box" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_products|default:'Products'}</span>
        </div>
    </div>
    <div class="panel-body">
        <form method="get" action="addonmodules.php" class="hcva-table-toolbar" style="justify-content:flex-start;gap:8px;">
            <input type="hidden" name="module" value="hetzner_cloud_vps">
            <input type="hidden" name="action" value="products">
            <label for="hcva-product-account-select" style="align-self:center;margin-right:4px;">{$lang.label_select_account|default:'Account'}</label>
            <select id="hcva-product-account-select" name="account_id" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$accounts item=account}
                    <option value="{$account.id}"{if $selectedAccountId == $account.id} selected{/if}>{$account.name|escape}</option>
                {/foreach}
            </select>
            <label for="hcva-product-location-select" style="align-self:center;margin:0 4px;">{$lang.label_select_location|default:'Location'}</label>
            <select id="hcva-product-location-select" name="location" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$locations key=locName item=locLabel}
                    <option value="{$locName|escape}"{if $selectedLocation == $locName} selected{/if}>{$locLabel|escape}</option>
                {/foreach}
            </select>
            <label for="hcva-product-page-size" style="align-self:center;margin:0 4px 0 12px;">{$lang.label_per_page|default:'Per page'}</label>
            <select id="hcva-product-page-size" name="size" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$pageSizes item=option}
                    <option value="{$option.value}"{if $option.selected} selected{/if}>{$option.value}</option>
                {/foreach}
            </select>
        </form>

        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-catalog-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-catalog-table">
            <thead>
                <tr>
                    <th>{$lang.col_server_type|default:'Server Type'}</th>
                    <th>{$lang.col_cores|default:'vCPU'}</th>
                    <th>{$lang.col_memory|default:'RAM (GB)'}</th>
                    <th>{$lang.col_disk|default:'Disk (GB)'}</th>
                    <th>{$lang.col_monthly_net|default:'Monthly (net)'}</th>
                    <th>{$lang.col_included_traffic|default:'Included Traffic'}</th>
                    <th>{$lang.col_per_tb_traffic|default:'Extra Traffic (net/TB)'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$catalog item=row}
                <tr data-hcva-row>
                    <td>{$row.name|escape}</td>
                    <td>{$row.cores}</td>
                    <td>{$row.memory}</td>
                    <td>{$row.disk}</td>
                    <td>{$row.monthlyNet}</td>
                    <td>{$row.includedTraffic}</td>
                    <td>{$row.perTbTrafficNet}</td>
                    <td>
                        <button type="button" class="btn btn-default btn-sm" data-hcva-import-type="{$row.name|escape}">
                            <i class="fas fa-download" aria-hidden="true"></i> {$lang.btn_import|default:'Import as Product'}
                        </button>
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="8">{$lang.no_catalog_rows|default:'No server types are priced in this location.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="8">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>

        {if $catalogTotalPages > 1}
        {include file="partials/pagination.tpl" pagerUrl="`$modulelink`&action=products&account_id=`$selectedAccountId`&size=`$pageSize`&location=`$selectedLocation|escape:'url'`&ppage=`$productPage`" pagerParam="cpage" pagerPage=$catalogPage pagerTotalPages=$catalogTotalPages pagerSummary=$catalogSummary}
        {/if}
    </div>
</div>

{if $providerRates}
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-tags" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_provider_pricing|default:'Provider Pricing'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.provider_pricing_note|default:'Live net rates charged by Hetzner Cloud for this Project and location. Set your own prices above these.'}</p>
        <div class="hcva-rate-grid">
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_currency|default:'Currency'}</span>
                <span class="hcva-rate-value">{$providerRates.currency|escape}</span>
            </div>
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_vat|default:'VAT Rate'}</span>
                <span class="hcva-rate-value">{$providerRates.vatRate|escape}%</span>
            </div>
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_volume|default:'Volumes, per GB / month'}</span>
                <span class="hcva-rate-value">{$providerRates.volumePerGbMonth|escape}</span>
            </div>
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_image|default:'Snapshots &amp; backups, per GB / month'}</span>
                <span class="hcva-rate-value">{$providerRates.imagePerGbMonth|escape}</span>
            </div>
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_backup|default:'Automatic backups'}</span>
                <span class="hcva-rate-value">+{$providerRates.backupPercentage|escape}% {$lang.rate_backup_suffix|default:'of the server price'}</span>
            </div>
            {foreach from=$providerRates.floatingIps item=fip}
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_floating_ip|default:'Floating IP'} ({$fip.type|escape})</span>
                <span class="hcva-rate-value">{$fip.monthlyNet|escape} / {$lang.word_month|default:'month'}</span>
            </div>
            {/foreach}
            {foreach from=$providerRates.primaryIps item=pip}
            <div class="hcva-rate">
                <span class="hcva-rate-label">{$lang.rate_primary_ip|default:'Primary IP'} ({$pip.type|escape})</span>
                <span class="hcva-rate-value">{$pip.monthlyNet|escape} / {$lang.word_month|default:'month'}</span>
            </div>
            {/foreach}
        </div>
    </div>
</div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-sync" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.nav_products|default:'Products'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-products-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-products-table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_group|default:'Product Group'}</th>
                    <th>{$lang.col_account|default:'Account'}</th>
                    <th>{$lang.col_location|default:'Location'}</th>
                    <th>{$lang.col_server_type|default:'Server Type'}</th>
                    <th>{$lang.col_markup|default:'Markup'}</th>
                    <th>{$lang.col_last_synced|default:'Last Synced'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$existingProducts item=row}
                <tr data-hcva-row>
                    <td>{$row.name|escape}</td>
                    <td>{$row.groupName|escape}</td>
                    <td>{$row.accountName|escape}</td>
                    <td>{$row.location|escape}</td>
                    <td>{$row.serverType|escape}</td>
                    <td>{$row.markup|escape}%</td>
                    <td>{if $row.lastSynced}{$row.lastSynced}{else}&mdash;{/if}</td>
                    <td>
                        <form method="post" action="{$modulelink}&action=products">
                            <input type="hidden" name="module_action" value="sync">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="product_id" value="{$row.id}">
                            <button type="submit" class="btn btn-default btn-sm">
                                <i class="fas fa-sync" aria-hidden="true"></i> {$lang.btn_sync_now|default:'Sync Now'}
                            </button>
                        </form>
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="8">{$lang.no_products_configured|default:'No products are using this module yet.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="8">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>

        {if $productTotalPages > 1}
        {include file="partials/pagination.tpl" pagerUrl="`$modulelink`&action=products&account_id=`$selectedAccountId`&size=`$pageSize`&location=`$selectedLocation|escape:'url'`&cpage=`$catalogPage`" pagerParam="ppage" pagerPage=$productPage pagerTotalPages=$productTotalPages pagerSummary=$productSummary}
        {/if}
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-import-modal" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_import|default:'Import as Product'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=products" data-confirm="{$lang.confirm_import|default:'This will create a new WHMCS product. Continue?'}">
                <input type="hidden" name="module_action" value="import">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="account_id" value="{$selectedAccountId}">
                <input type="hidden" name="location" value="{$selectedLocation|escape}">
                <input type="hidden" name="server_type" id="hcva-import-server-type" value="">
                <div class="hcva-form-group">
                    <label for="hcva-import-gid">{$lang.label_product_group|default:'Product Group'}</label>
                    <select class="form-control" id="hcva-import-gid" name="gid" required>
                        {foreach from=$productGroups item=group}
                            <option value="{$group.id}">{$group.name|escape}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-import-name">{$lang.label_product_name|default:'Product Name'}</label>
                    <input type="text" class="form-control" id="hcva-import-name" name="name" required>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-import-markup">{$lang.label_price_markup|default:'Price Markup (%)'}</label>
                    <input type="text" class="form-control" id="hcva-import-markup" name="markup" value="0">
                </div>
                <div class="hcva-form-group">
                    <label id="hcva-import-cycle-label" for="hcva-import-cycle">{$lang.label_billing_cycle|default:'Billing Cycles'}</label>
                    <div class="hcva-tokens" data-hcva-tokens data-hcva-token-placeholder="{$lang.placeholder_billing_cycle|default:'Type to add a cycle'}">
                        <select id="hcva-import-cycle" class="form-control hcva-token-source" name="billing_cycle[]" multiple size="6" data-hcva-token-source>
                            {foreach from=$billingCycles key=cycleKey item=cycleLabel}
                                <option value="{$cycleKey|escape}"{if $cycleKey == 'monthly'} selected{/if}>{$cycleLabel|escape}</option>
                            {/foreach}
                        </select>
                    </div>
                    <p class="hcva-form-hint">{$lang.note_billing_cycle|default:'Only the cycles you pick are priced. Every other cycle is left disabled on the product.'}</p>
                </div>
                <div class="hcva-modal-footer" style="padding:0;border-top:none;">
                    <button type="button" class="btn btn-default" data-hcva-dismiss>
                        <i class="fas fa-times" aria-hidden="true"></i> {$lang.btn_cancel|default:'Cancel'}
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-file-import" aria-hidden="true"></i> {$lang.btn_import|default:'Import as Product'}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
