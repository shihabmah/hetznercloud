{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage nofilter}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}
{if $apiError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-triangle hcva-highlight-icon" aria-hidden="true"></i><span>{$apiError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-network-wired" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_resources|default:'Project Resources'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.resources_note|default:'These belong to the Hetzner Cloud Project as a whole, not to any one WHMCS service, so they are managed here and never shown to a client.'}</p>
        <form method="get" action="addonmodules.php" class="hcva-table-toolbar" style="justify-content:flex-start;gap:8px;">
            <input type="hidden" name="module" value="hetzner_cloud_vps">
            <input type="hidden" name="action" value="resources">
            <label for="hcva-resource-account-select" style="align-self:center;margin-right:4px;">{$lang.label_select_account|default:'Account'}</label>
            <input type="hidden" name="res" value="{$section|escape}">
            <select id="hcva-resource-account-select" name="account_id" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$accounts item=account}
                    <option value="{$account.id}"{if $selectedAccountId == $account.id} selected{/if}>{$account.name|escape}</option>
                {/foreach}
            </select>
            <label for="hcva-resource-page-size" style="align-self:center;margin:0 4px 0 12px;">{$lang.label_per_page|default:'Per page'}</label>
            <select id="hcva-resource-page-size" name="size" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$pageSizes item=option}
                    <option value="{$option.value}"{if $option.selected} selected{/if}>{$option.value}</option>
                {/foreach}
            </select>
        </form>

        <div class="hcva-subnav">
            {foreach from=$sectionTabs item=tab}
                <a class="hcva-subnav-item{if $tab.active} hcva-subnav-item--active{/if}"
                   href="{$modulelink}&action=resources&account_id={$selectedAccountId}&size={$pageSize}&res={$tab.key}">
                    <i class="fas {$tab.icon}" aria-hidden="true"></i><span>{$tab.label|escape}</span>
                </a>
            {/foreach}
        </div>
    </div>
</div>

{if $section == 'loadbalancers'}
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-balance-scale" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_load_balancers|default:'Load Balancers'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-table-toolbar">
            <button type="button" class="btn btn-primary" data-hcva-modal-open="hcva-lb-create-modal">
                <i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_create_lb|default:'Create Load Balancer'}
            </button>
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-lb-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-lb-table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_type|default:'Type'}</th>
                    <th>{$lang.col_location|default:'Location'}</th>
                    <th>{$lang.col_ipv4|default:'IPv4'}</th>
                    <th>{$lang.col_algorithm|default:'Algorithm'}</th>
                    <th>{$lang.col_services|default:'Services'}</th>
                    <th>{$lang.col_targets|default:'Targets'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$loadBalancers item=lb}
                <tr data-hcva-row>
                    <td>
                        {$lb.name|escape}
                        {if $lb.deleteProtected}<span class="hcva-status hcva-status--warning">{$lang.badge_protected|default:'Protected'}</span>{/if}
                        {if !$lb.publicEnabled}<span class="hcva-status hcva-status--neutral">{$lang.badge_private|default:'Private only'}</span>{/if}
                    </td>
                    <td>{$lb.type|escape}</td>
                    <td>{$lb.location|escape}</td>
                    <td>{if $lb.ipv4}<code>{$lb.ipv4|escape}</code>{else}&mdash;{/if}</td>
                    <td>{$lb.algorithm|escape}</td>
                    <td>{$lb.serviceCount}</td>
                    <td>{$lb.targetCount}</td>
                    <td>
                        <button type="button" class="btn btn-default btn-sm" data-hcva-modal-open="hcva-lb-manage-{$lb.id}">
                            <i class="fas fa-sliders-h" aria-hidden="true"></i> {$lang.btn_manage|default:'Manage'}
                        </button>
                        <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" style="display:inline-block" data-confirm="{$lang.confirm_delete_lb|default:'Delete this load balancer? Any traffic still pointed at its address will stop being served.'}" data-confirm-variant="danger">
                            <input type="hidden" name="module_action" value="lbDelete">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="lb_id" value="{$lb.id}">
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash-alt" aria-hidden="true"></i> {$lang.btn_delete|default:'Delete'}
                            </button>
                        </form>
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="8">{$lang.no_load_balancers|default:'No load balancers in this Project.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="8">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>
    </div>
</div>

{foreach from=$loadBalancers item=lb}
<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-lb-manage-{$lb.id}" aria-hidden="true">
    <div class="hcva-modal-box hcva-modal-box--wide">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_manage|default:'Manage'} &mdash; {$lb.name|escape}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <h5 class="hcva-subhead">{$lang.sub_general|default:'General'}</h5>
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form">
                <input type="hidden" name="module_action" value="lbRename">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <input type="text" class="form-control" name="name" value="{$lb.name|escape}" maxlength="128" required>
                <button type="submit" class="btn btn-default btn-sm"><i class="fas fa-pencil-alt" aria-hidden="true"></i> {$lang.btn_rename|default:'Rename'}</button>
            </form>

            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form">
                <input type="hidden" name="module_action" value="lbAlgorithm">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <select name="algorithm" class="form-control">
                    {foreach from=$algorithms item=algo}
                        <option value="{$algo}"{if $lb.algorithm == $algo} selected{/if}>{$algo|escape}</option>
                    {/foreach}
                </select>
                <button type="submit" class="btn btn-default btn-sm"><i class="fas fa-random" aria-hidden="true"></i> {$lang.btn_set_algorithm|default:'Set Algorithm'}</button>
            </form>

            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form" data-confirm="{$lang.confirm_lb_type|default:'Change the load balancer type? Downgrading below the current service or target count will be refused by the provider.'}">
                <input type="hidden" name="module_action" value="lbType">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <select name="lb_type" class="form-control">
                    {foreach from=$loadBalancerTypes item=type}
                        <option value="{$type.name|escape}"{if $lb.type == $type.name} selected{/if}>{$type.label|escape}</option>
                    {/foreach}
                </select>
                <button type="submit" class="btn btn-default btn-sm"><i class="fas fa-expand-arrows-alt" aria-hidden="true"></i> {$lang.btn_set_type|default:'Set Type'}</button>
            </form>

            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form">
                <input type="hidden" name="module_action" value="lbProtection">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <input type="hidden" name="enabled" value="{if $lb.deleteProtected}0{else}1{/if}">
                <button type="submit" class="btn btn-default btn-sm">
                    <i class="fas fa-shield-alt" aria-hidden="true"></i>
                    {if $lb.deleteProtected}{$lang.btn_protection_off|default:'Disable Delete Protection'}{else}{$lang.btn_protection_on|default:'Enable Delete Protection'}{/if}
                </button>
            </form>

            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form" data-confirm="{$lang.confirm_lb_public|default:'Change the public interface? Disabling it makes the load balancer reachable only from the private network.'}">
                <input type="hidden" name="module_action" value="lbPublicInterface">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <input type="hidden" name="enabled" value="{if $lb.publicEnabled}0{else}1{/if}">
                <button type="submit" class="btn btn-default btn-sm">
                    <i class="fas fa-globe" aria-hidden="true"></i>
                    {if $lb.publicEnabled}{$lang.btn_public_off|default:'Disable Public Interface'}{else}{$lang.btn_public_on|default:'Enable Public Interface'}{/if}
                </button>
            </form>

            <h5 class="hcva-subhead">{$lang.sub_metrics|default:'Last 24 Hours (peak)'}</h5>
            <div class="hcva-rate-grid">
                <div class="hcva-rate">
                    <span class="hcva-rate-label">{$lang.metric_open_connections|default:'Open connections'}</span>
                    <span class="hcva-rate-value">{if $lb.metrics.open_connections}{$lb.metrics.open_connections}{else}&mdash;{/if}</span>
                </div>
                <div class="hcva-rate">
                    <span class="hcva-rate-label">{$lang.metric_requests|default:'Requests / sec'}</span>
                    <span class="hcva-rate-value">{if $lb.metrics.requests_per_second}{$lb.metrics.requests_per_second}{else}&mdash;{/if}</span>
                </div>
                <div class="hcva-rate">
                    <span class="hcva-rate-label">{$lang.metric_bandwidth_in|default:'Bandwidth in'}</span>
                    <span class="hcva-rate-value">{if $lb.metrics.bandwidth_in}{$lb.metrics.bandwidth_in}{else}&mdash;{/if}</span>
                </div>
                <div class="hcva-rate">
                    <span class="hcva-rate-label">{$lang.metric_bandwidth_out|default:'Bandwidth out'}</span>
                    <span class="hcva-rate-value">{if $lb.metrics.bandwidth_out}{$lb.metrics.bandwidth_out}{else}&mdash;{/if}</span>
                </div>
            </div>

            <h5 class="hcva-subhead">{$lang.sub_private_network|default:'Private Network'}</h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{$lang.network_name|default:'Network'}</th>
                        <th>{$lang.col_ipv4|default:'IPv4'}</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                {foreach from=$lb.privateNetworks item=net}
                    <tr>
                        <td>#{$net.id}</td>
                        <td>{if $net.ip}<code>{$net.ip|escape}</code>{else}&mdash;{/if}</td>
                        <td>
                            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" data-confirm="{$lang.confirm_lb_network_detach|default:'Detach this load balancer from the private network?'}" data-confirm-variant="danger">
                                <input type="hidden" name="module_action" value="lbNetworkDetach">
                                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                                <input type="hidden" name="lb_id" value="{$lb.id}">
                                <input type="hidden" name="network_id" value="{$net.id}">
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-unlink" aria-hidden="true"></i> {$lang.btn_detach|default:'Detach'}</button>
                            </form>
                        </td>
                    </tr>
                {foreachelse}
                    <tr><td colspan="3">{$lang.no_lb_networks|default:'This load balancer is not attached to a private network.'}</td></tr>
                {/foreach}
                </tbody>
            </table>

            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form">
                <input type="hidden" name="module_action" value="lbNetworkAttach">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <select name="network_id" class="form-control">
                    {foreach from=$networks item=net}
                        <option value="{$net.id}">{$net.name|escape} ({$net.range|escape})</option>
                    {/foreach}
                </select>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-link" aria-hidden="true"></i> {$lang.btn_attach|default:'Attach'}</button>
            </form>

            <h5 class="hcva-subhead">{$lang.sub_targets|default:'Targets'}</h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{$lang.col_server|default:'Server'}</th>
                        <th>{$lang.col_via|default:'Via'}</th>
                        <th>{$lang.col_health|default:'Health'}</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                {foreach from=$lb.targets item=target}
                    <tr>
                        <td>#{$target.serverId}</td>
                        <td>{if $target.usePrivateIp}{$lang.word_private|default:'Private network'}{else}{$lang.word_public|default:'Public'}{/if}</td>
                        <td>
                            {if $target.healthy}
                                <span class="hcva-status hcva-status--success">{$lang.word_healthy|default:'Healthy'}</span>
                            {else}
                                <span class="hcva-status hcva-status--danger">{$lang.word_unhealthy|default:'Unhealthy'}</span>
                            {/if}
                        </td>
                        <td>
                            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" data-confirm="{$lang.confirm_target_remove|default:'Remove this server from the load balancer?'}" data-confirm-variant="danger">
                                <input type="hidden" name="module_action" value="lbTargetRemove">
                                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                                <input type="hidden" name="lb_id" value="{$lb.id}">
                                <input type="hidden" name="server_id" value="{$target.serverId}">
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-unlink" aria-hidden="true"></i> {$lang.btn_remove|default:'Remove'}</button>
                            </form>
                        </td>
                    </tr>
                {foreachelse}
                    <tr><td colspan="4">{$lang.no_targets|default:'No servers are behind this load balancer.'}</td></tr>
                {/foreach}
                </tbody>
            </table>

            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form">
                <input type="hidden" name="module_action" value="lbTargetAdd">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <select name="server_id" class="form-control">
                    {foreach from=$servers item=server}
                        <option value="{$server.id}">{$server.name|escape} (#{$server.id})</option>
                    {/foreach}
                </select>
                <label class="hcva-switch">
                    <input type="checkbox" name="use_private_ip" value="1">
                    <span class="hcva-switch-track"><span class="hcva-switch-thumb"></span></span>
                </label>
                <span>{$lang.label_use_private_ip|default:'Route over the private network'}</span>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-link" aria-hidden="true"></i> {$lang.btn_add_target|default:'Add Target'}</button>
            </form>

            <h5 class="hcva-subhead">{$lang.sub_services|default:'Services'}</h5>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>{$lang.col_protocol|default:'Protocol'}</th>
                        <th>{$lang.col_listen|default:'Listen'}</th>
                        <th>{$lang.col_destination|default:'Destination'}</th>
                        <th>{$lang.col_healthcheck|default:'Health Check'}</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                {foreach from=$lb.services item=svc}
                    <tr>
                        <td>{$svc.protocol|escape}{if $svc.proxyProtocol} <span class="hcva-status hcva-status--neutral">{$lang.badge_proxy|default:'PROXY'}</span>{/if}</td>
                        <td>{$svc.listenPort}</td>
                        <td>{$svc.destinationPort}</td>
                        <td>{$svc.healthProtocol|escape}:{$svc.healthPort}</td>
                        <td>
                            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" data-confirm="{$lang.confirm_service_delete|default:'Delete this service? Traffic on that listen port stops being forwarded.'}" data-confirm-variant="danger">
                                <input type="hidden" name="module_action" value="lbServiceDelete">
                                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                                <input type="hidden" name="lb_id" value="{$lb.id}">
                                <input type="hidden" name="listen_port" value="{$svc.listenPort}">
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt" aria-hidden="true"></i> {$lang.btn_delete|default:'Delete'}</button>
                            </form>
                        </td>
                    </tr>
                {foreachelse}
                    <tr><td colspan="5">{$lang.no_services|default:'No services defined. Nothing is being forwarded.'}</td></tr>
                {/foreach}
                </tbody>
            </table>

            <p class="hcva-rate-note">{$lang.service_note|default:'Saving a listen port that already exists updates that service; a new port adds one.'}</p>
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}">
                <input type="hidden" name="module_action" value="lbServiceSave">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="lb_id" value="{$lb.id}">
                <div class="hcva-rate-grid">
                    <div class="hcva-form-group">
                        <label for="hcva-svc-protocol-{$lb.id}">{$lang.col_protocol|default:'Protocol'}</label>
                        <select id="hcva-svc-protocol-{$lb.id}" name="protocol" class="form-control">
                            {foreach from=$protocols item=proto}
                                <option value="{$proto}">{$proto|escape}</option>
                            {/foreach}
                        </select>
                    </div>
                    <div class="hcva-form-group">
                        <label for="hcva-svc-listen-{$lb.id}">{$lang.col_listen|default:'Listen'}</label>
                        <input type="number" id="hcva-svc-listen-{$lb.id}" name="listen_port" class="form-control" min="1" max="65535" value="80" required>
                    </div>
                    <div class="hcva-form-group">
                        <label for="hcva-svc-dest-{$lb.id}">{$lang.col_destination|default:'Destination'}</label>
                        <input type="number" id="hcva-svc-dest-{$lb.id}" name="destination_port" class="form-control" min="1" max="65535" value="80" required>
                    </div>
                    <div class="hcva-form-group">
                        <label for="hcva-svc-hproto-{$lb.id}">{$lang.label_health_protocol|default:'Health Check Protocol'}</label>
                        <select id="hcva-svc-hproto-{$lb.id}" name="health_protocol" class="form-control">
                            <option value="tcp">tcp</option>
                            <option value="http">http</option>
                        </select>
                    </div>
                    <div class="hcva-form-group">
                        <label for="hcva-svc-hport-{$lb.id}">{$lang.label_health_port|default:'Health Check Port'}</label>
                        <input type="number" id="hcva-svc-hport-{$lb.id}" name="health_port" class="form-control" min="1" max="65535" placeholder="{$lang.placeholder_same_as_destination|default:'Same as destination'}">
                    </div>
                    <div class="hcva-form-group">
                        <label for="hcva-svc-hpath-{$lb.id}">{$lang.label_health_path|default:'Health Check Path (http only)'}</label>
                        <input type="text" id="hcva-svc-hpath-{$lb.id}" name="health_path" class="form-control" value="/">
                    </div>
                </div>
                <div class="hcva-inline-form">
                    <label class="hcva-switch">
                        <input type="checkbox" name="proxyprotocol" value="1">
                        <span class="hcva-switch-track"><span class="hcva-switch-thumb"></span></span>
                    </label>
                    <span>{$lang.label_proxyprotocol|default:'PROXY protocol'}</span>
                    <label class="hcva-switch">
                        <input type="checkbox" name="health_tls" value="1">
                        <span class="hcva-switch-track"><span class="hcva-switch-thumb"></span></span>
                    </label>
                    <span>{$lang.label_health_tls|default:'Health check over TLS'}</span>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save" aria-hidden="true"></i> {$lang.btn_save_service|default:'Save Service'}</button>
                </div>
            </form>
        </div>
    </div>
</div>
{/foreach}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-lb-create-modal" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_create_lb|default:'Create Load Balancer'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}">
                <input type="hidden" name="module_action" value="lbCreate">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <div class="hcva-form-group">
                    <label for="hcva-lb-new-name">{$lang.col_name|default:'Name'}</label>
                    <input type="text" id="hcva-lb-new-name" name="name" class="form-control" maxlength="128" required>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-lb-new-type">{$lang.col_type|default:'Type'}</label>
                    <select id="hcva-lb-new-type" name="lb_type" class="form-control">
                        {foreach from=$loadBalancerTypes item=type}
                            <option value="{$type.name|escape}">{$type.label|escape}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-lb-new-location">{$lang.col_location|default:'Location'}</label>
                    <select id="hcva-lb-new-location" name="location" class="form-control">
                        {foreach from=$locations item=loc}
                            <option value="{$loc}">{$loc|escape}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-lb-new-algorithm">{$lang.col_algorithm|default:'Algorithm'}</label>
                    <select id="hcva-lb-new-algorithm" name="algorithm" class="form-control">
                        {foreach from=$algorithms item=algo}
                            <option value="{$algo}">{$algo|escape}</option>
                        {/foreach}
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_create|default:'Create'}</button>
            </form>
        </div>
    </div>
</div>

{/if}
{if $section == 'snapshots'}
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-camera" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_snapshots|default:'Published Snapshots'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.snapshots_share_note|default:'A published snapshot becomes a rebuild option for every service on this Project. Use it to offer a prepared image — a licensed Windows build, for example — without giving one client access to another client snapshot.'}</p>
        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-snapshot-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>
        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-snapshot-table">
            <thead>
                <tr>
                    <th>{$lang.col_description|default:'Description'}</th>
                    <th>{$lang.col_os|default:'OS'}</th>
                    <th>{$lang.col_size|default:'Size'}</th>
                    <th>{$lang.col_created|default:'Created'}</th>
                    <th>{$lang.col_published|default:'Published'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$snapshots item=snap}
                <tr data-hcva-row>
                    <td>{if $snap.description}{$snap.description|escape}{else}&mdash;{/if} <span class="hcva-muted">#{$snap.id}</span></td>
                    <td>{if $snap.os}{$snap.os|escape}{else}&mdash;{/if}</td>
                    <td>{$snap.sizeGb} GB</td>
                    <td>{$snap.created}</td>
                    <td>
                        {if $snap.shared}
                            <span class="hcva-status hcva-status--success">{$lang.word_yes|default:'Yes'}</span>
                        {else}
                            <span class="hcva-status hcva-status--neutral">{$lang.word_no|default:'No'}</span>
                        {/if}
                    </td>
                    <td>
                        {if $snap.shared}
                        <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" data-confirm="{$lang.confirm_image_revoke|default:'Withdraw this snapshot? Clients will no longer be able to rebuild from it.'}" data-confirm-variant="danger">
                            <input type="hidden" name="module_action" value="imageRevoke">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="image_id" value="{$snap.id}">
                            <input type="hidden" name="share_account_id" value="{$selectedAccountId}">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-eye-slash" aria-hidden="true"></i> {$lang.btn_withdraw|default:'Withdraw'}</button>
                        </form>
                        {else}
                        <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" class="hcva-inline-form" data-confirm="{$lang.confirm_image_share|default:'Publish this snapshot? Every service on this Project will be able to rebuild from it.'}">
                            <input type="hidden" name="module_action" value="imageShare">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="image_id" value="{$snap.id}">
                            <input type="hidden" name="share_account_id" value="{$selectedAccountId}">
                            <input type="text" class="form-control" name="label" placeholder="{$lang.label_image_name|default:'Name shown to clients'}" maxlength="128">
                            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-eye" aria-hidden="true"></i> {$lang.btn_publish|default:'Publish'}</button>
                        </form>
                        {/if}
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="6">{$lang.no_snapshots|default:'No snapshots exist in this Project.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="6">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>
    </div>
</div>

{/if}
{if $section == 'certificates'}
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-lock" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_certificates|default:'Certificates'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-table-toolbar">
            <button type="button" class="btn btn-primary" data-hcva-modal-open="hcva-cert-create-modal">
                <i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_add_cert|default:'Add Certificate'}
            </button>
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-cert-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-cert-table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_type|default:'Type'}</th>
                    <th>{$lang.col_domains|default:'Domains'}</th>
                    <th>{$lang.col_expires|default:'Expires'}</th>
                    <th>{$lang.col_used_by|default:'Used By'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$certificates item=cert}
                <tr data-hcva-row>
                    <td>{$cert.name|escape}</td>
                    <td>{$cert.type|escape}</td>
                    <td>{if $cert.domains}{$cert.domains|escape}{else}&mdash;{/if}</td>
                    <td>
                        {$cert.expires}
                        {if $cert.expired}<span class="hcva-status hcva-status--danger">{$lang.badge_expired|default:'Expired'}</span>{/if}
                        {if $cert.issuance && $cert.issuance != 'completed'}<span class="hcva-status hcva-status--warning">{$cert.issuance|escape}</span>{/if}
                    </td>
                    <td>{$cert.usedBy}</td>
                    <td>
                        <button type="button" class="btn btn-default btn-sm" data-hcva-modal-open="hcva-cert-rename-{$cert.id}">
                            <i class="fas fa-pencil-alt" aria-hidden="true"></i> {$lang.btn_rename|default:'Rename'}
                        </button>
                        {if $cert.type == 'managed'}
                        <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" style="display:inline-block">
                            <input type="hidden" name="module_action" value="certRetry">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="cert_id" value="{$cert.id}">
                            <button type="submit" class="btn btn-default btn-sm"><i class="fas fa-redo" aria-hidden="true"></i> {$lang.btn_retry|default:'Retry Issuance'}</button>
                        </form>
                        {/if}
                        <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" style="display:inline-block" data-confirm="{$lang.confirm_delete_cert|default:'Delete this certificate? Any load balancer service still using it will fail its TLS handshake.'}" data-confirm-variant="danger">
                            <input type="hidden" name="module_action" value="certDelete">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="cert_id" value="{$cert.id}">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt" aria-hidden="true"></i> {$lang.btn_delete|default:'Delete'}</button>
                        </form>
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="6">{$lang.no_certificates|default:'No certificates in this Project.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="6">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>
    </div>
</div>

{foreach from=$certificates item=cert}
<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-cert-rename-{$cert.id}" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'} &mdash; {$cert.name|escape}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}">
                <input type="hidden" name="module_action" value="certRename">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="cert_id" value="{$cert.id}">
                <div class="hcva-form-group">
                    <label for="hcva-cert-name-{$cert.id}">{$lang.col_name|default:'Name'}</label>
                    <input type="text" id="hcva-cert-name-{$cert.id}" name="name" class="form-control" value="{$cert.name|escape}" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save" aria-hidden="true"></i> {$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>
{/foreach}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-cert-create-modal" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_add_cert|default:'Add Certificate'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}">
                <input type="hidden" name="module_action" value="certCreate">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <div class="hcva-form-group">
                    <label for="hcva-cert-new-name">{$lang.col_name|default:'Name'}</label>
                    <input type="text" id="hcva-cert-new-name" name="name" class="form-control" maxlength="128" required>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-cert-new-type">{$lang.col_type|default:'Type'}</label>
                    <select id="hcva-cert-new-type" name="cert_type" class="form-control">
                        <option value="managed">{$lang.cert_managed|default:'Managed — the provider issues and renews it'}</option>
                        <option value="uploaded">{$lang.cert_uploaded|default:'Uploaded — you supply the chain and key'}</option>
                    </select>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-cert-new-domains">{$lang.label_domains|default:'Domain names (managed only, one per line)'}</label>
                    <textarea id="hcva-cert-new-domains" name="domain_names" class="form-control" rows="3" placeholder="example.com&#10;www.example.com"></textarea>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-cert-new-chain">{$lang.label_chain|default:'Certificate chain, PEM (uploaded only)'}</label>
                    <textarea id="hcva-cert-new-chain" name="certificate" class="form-control" rows="4" placeholder="-----BEGIN CERTIFICATE-----"></textarea>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-cert-new-key">{$lang.label_key|default:'Private key, PEM (uploaded only)'}</label>
                    <textarea id="hcva-cert-new-key" name="private_key" class="form-control" rows="4" placeholder="-----BEGIN PRIVATE KEY-----" autocomplete="off"></textarea>
                    <p class="hcva-rate-note">{$lang.key_note|default:'Sent to the provider and never stored or logged here. The provider does not return it again.'}</p>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_create|default:'Create'}</button>
            </form>
        </div>
    </div>
</div>

{/if}
{if $section == 'placementgroups'}
<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-layer-group" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_placement_groups|default:'Placement Groups'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.placement_note|default:'A placement group keeps its member servers on separate physical hosts. Membership is changed from the server itself, which must be powered off.'}</p>
        <div class="hcva-table-toolbar">
            <button type="button" class="btn btn-primary" data-hcva-modal-open="hcva-pg-create-modal">
                <i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_add_pg|default:'Add Placement Group'}
            </button>
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-pg-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-pg-table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_type|default:'Type'}</th>
                    <th>{$lang.col_servers|default:'Servers'}</th>
                    <th>{$lang.col_created|default:'Created'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$placementGroups item=pg}
                <tr data-hcva-row>
                    <td>{$pg.name|escape}</td>
                    <td>{$pg.type|escape}</td>
                    <td>{$pg.servers}</td>
                    <td>{$pg.created}</td>
                    <td>
                        <button type="button" class="btn btn-default btn-sm" data-hcva-modal-open="hcva-pg-rename-{$pg.id}">
                            <i class="fas fa-pencil-alt" aria-hidden="true"></i> {$lang.btn_rename|default:'Rename'}
                        </button>
                        <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}" style="display:inline-block" data-confirm="{$lang.confirm_delete_pg|default:'Delete this placement group? It must be empty first.'}" data-confirm-variant="danger">
                            <input type="hidden" name="module_action" value="pgDelete">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="pg_id" value="{$pg.id}">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt" aria-hidden="true"></i> {$lang.btn_delete|default:'Delete'}</button>
                        </form>
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="5">{$lang.no_placement_groups|default:'No placement groups in this Project.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="5">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>
    </div>
</div>

{foreach from=$placementGroups item=pg}
<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-pg-rename-{$pg.id}" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'} &mdash; {$pg.name|escape}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}">
                <input type="hidden" name="module_action" value="pgRename">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="pg_id" value="{$pg.id}">
                <div class="hcva-form-group">
                    <label for="hcva-pg-name-{$pg.id}">{$lang.col_name|default:'Name'}</label>
                    <input type="text" id="hcva-pg-name-{$pg.id}" name="name" class="form-control" value="{$pg.name|escape}" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save" aria-hidden="true"></i> {$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>
{/foreach}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-pg-create-modal" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_add_pg|default:'Add Placement Group'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=resources&account_id={$selectedAccountId}">
                <input type="hidden" name="module_action" value="pgCreate">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <div class="hcva-form-group">
                    <label for="hcva-pg-new-name">{$lang.col_name|default:'Name'}</label>
                    <input type="text" id="hcva-pg-new-name" name="name" class="form-control" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_create|default:'Create'}</button>
            </form>
        </div>
    </div>
</div>

{/if}

{include file=$inventoryTemplate}