{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage|escape}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-certificate" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_license|default:'License'}</span>
        </div>
    </div>
    <div class="panel-body">
        {if !$hasKey}
            <p class="text-muted">
                {$lang.license_setup_intro|default:'Enter the license key you received when you purchased this module to activate it. The admin pages will not be usable until a valid, active license key is entered.'}
            </p>
        {elseif !$isActive}
            <div class="hcva-highlight-box hcva-highlight-box--danger">
                <i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i>
                <span>
                    <strong>{$lang.license_status_label|default:'Status'}:</strong>
                    <span class="hcva-status hcva-status--{$statusVariant}">{$status|escape}</span><br>
                    {$message|escape}
                </span>
            </div>
        {else}
            <div class="hcva-highlight-box hcva-highlight-box--success">
                <i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i>
                <span>
                    <strong>{$lang.license_status_label|default:'Status'}:</strong>
                    <span class="hcva-status hcva-status--{$statusVariant}">{$status|escape}</span> &mdash; {$message|escape}
                </span>
            </div>
        {/if}

        {if $hasKey}
        <h4>{$lang.license_details_heading|default:'License Details'}</h4>
        <div class="hcva-table-wrap">
        <table class="table">
            <tbody>
                <tr>
                    <th>{$lang.license_key_label|default:'License Key'}</th>
                    <td><code>{$maskedKey|escape}</code></td>
                </tr>
                <tr>
                    <th>{$lang.license_registered_name|default:'Registered Name'}</th>
                    <td>{if $registeredName}{$registeredName|escape}{else}&mdash;{/if}</td>
                </tr>
                <tr>
                    <th>{$lang.license_valid_domain|default:'Valid Domain'}</th>
                    <td>{if $validDomain}{$validDomain|escape}{else}&mdash;{/if}</td>
                </tr>
                <tr>
                    <th>{$lang.license_valid_ip|default:'License IP'}</th>
                    <td>{if $validIp}{$validIp|escape}{else}&mdash;{/if}</td>
                </tr>
                <tr>
                    <th>{$lang.license_path_label|default:'License Path'}</th>
                    <td>{if $validDirectory}{$validDirectory|escape}{else}&mdash;{/if}</td>
                </tr>
                <tr>
                    <th>{$lang.license_next_check|default:'Next Check Date'}</th>
                    <td>{if $nextCheckDate}{$nextCheckDate|escape}{else}&mdash;{/if}</td>
                </tr>
                <tr>
                    <th>{$lang.license_last_check|default:'Last Checked'}</th>
                    <td>{if $lastCheck}{$lastCheck|escape}{else}&mdash;{/if}</td>
                </tr>
            </tbody>
        </table>
        </div>

        <form method="post" action="{$modulelink}&action=license" style="display:inline-block; margin-bottom: 20px;" data-confirm="{$lang.license_recheck_confirm|default:'Contact the license server now for a fresh verification?'}" data-confirm-title="{$lang.license_recheck_action|default:'Recheck License'}" data-confirm-variant="primary">
            <input type="hidden" name="module_action" value="recheck">
            <input type="hidden" name="csrf_token" value="{$csrfToken}">
            <button type="submit" class="btn btn-default">
                <i class="fas fa-sync" aria-hidden="true"></i> {$lang.license_recheck_action|default:'Recheck License'}
            </button>
        </form>
        {/if}

        <h4>{if $hasKey}{$lang.license_update_heading|default:'Update License Key'}{else}{$lang.license_activate_heading|default:'Activate License'}{/if}</h4>
        <form method="post" action="{$modulelink}&action=license" class="form-inline">
            <input type="hidden" name="module_action" value="save_key">
            <input type="hidden" name="csrf_token" value="{$csrfToken}">
            <div class="hcva-form-group" style="display:inline-block; margin-right: 8px;">
                <label for="hcva-license-key" class="sr-only">{$lang.license_key_label|default:'License Key'}</label>
                <input type="text" id="hcva-license-key" name="license_key" class="form-control" style="min-width: 320px;" placeholder="{$lang.license_key_placeholder|default:'Paste your license key here'}" value="" autocomplete="off">
            </div>
            <button type="submit" class="btn btn-primary">
                {if $hasKey}<i class="fas fa-save" aria-hidden="true"></i> {$lang.license_update_action|default:'Update Key'}{else}<i class="fas fa-check-circle" aria-hidden="true"></i> {$lang.license_activate_action|default:'Activate'}{/if}
            </button>
        </form>
    </div>
</div>
