{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage nofilter}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-exchange-alt" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_migration|default:'Migrate From The Legacy Module'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.migration_note|default:'Products still running on the older HetznerCloud module are listed here. Migrating one switches it to this module, rebuilds its configurable options, and relinks every existing service to the server it already has. No server is created, deleted or restarted.'}</p>

        {if $accounts|@count == 0}
            <div class="hcva-highlight-box hcva-highlight-box--warning">
                <i class="fas fa-exclamation-triangle hcva-highlight-icon" aria-hidden="true"></i>
                <span>{$lang.migration_no_accounts|default:'Add a Hetzner Cloud account first. Migration needs to know which Project each product provisions into.'}</span>
            </div>
        {/if}

        {if $products|@count == 0}
            <div class="hcva-empty-state">
                <i class="fas fa-check-circle" aria-hidden="true"></i>
                <p>{$lang.migration_none|default:'No products are using the legacy module. There is nothing to migrate.'}</p>
            </div>
        {else}
            <div class="hcva-table-toolbar">
                <div class="hcva-table-search">
                    <i class="fas fa-search" aria-hidden="true"></i>
                    <input type="text" data-hcva-table-search="hcva-migration-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
                </div>
            </div>

            <div class="hcva-table-wrap">
            <table class="table table-striped" id="hcva-migration-table">
                <thead>
                    <tr>
                        <th>{$lang.col_product|default:'Product'}</th>
                        <th>{$lang.col_legacy|default:'Legacy Settings'}</th>
                        <th>{$lang.col_services|default:'Services'}</th>
                        <th>{$lang.col_migrate_to|default:'Migrate To'}</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                {foreach $products as $row}
                    <tr>
                        <td>
                            <a href="configproducts.php?action=edit&amp;id={$row.id}" target="_blank" rel="noopener">{$row.name|escape}</a>
                            <div class="hcva-muted">#{$row.id}</div>
                        </td>
                        <td class="hcva-muted">
                            {$lang.col_project|default:'Project'}: {$row.legacyProject|escape}<br>
                            {$lang.col_type|default:'Type'}: {$row.legacyType|escape}<br>
                            {$lang.col_location|default:'Location'}: {$row.legacyLocation|escape}
                        </td>
                        <td>{$row.services}</td>
                        <td>
                            <form method="post" action="" id="hcva-migrate-{$row.id}">
                                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                                <input type="hidden" name="module_action" value="migrate">
                                <input type="hidden" name="product_id" value="{$row.id}">

                                <div class="hcva-form-group">
                                    <label for="hcva-account-{$row.id}">{$lang.label_account|default:'Account'}</label>
                                    <select class="form-control" id="hcva-account-{$row.id}" name="account_id" required>
                                        <option value="">{$lang.select_account|default:'Select an account'}</option>
                                        {foreach $accounts as $account}
                                            <option value="{$account.id}">{$account.name|escape}</option>
                                        {/foreach}
                                    </select>
                                </div>

                                <div class="hcva-form-group">
                                    <label for="hcva-location-{$row.id}">{$lang.label_location|default:'Location'}</label>
                                    {if $locations|@count > 0}
                                        <select class="form-control" id="hcva-location-{$row.id}" name="location" required>
                                            <option value="">{$lang.select_location|default:'Select a location'}</option>
                                            {foreach $locations as $code => $label}
                                                <option value="{$code|escape}"{if $code == $row.legacyLocation} selected{/if}>{$label|escape}</option>
                                            {/foreach}
                                        </select>
                                    {else}
                                        <input type="text" class="form-control" id="hcva-location-{$row.id}" name="location" value="{$row.legacyLocation|escape}" placeholder="nbg1" required>
                                    {/if}
                                </div>

                                <div class="hcva-form-group">
                                    <label for="hcva-type-{$row.id}">{$lang.label_server_type|default:'Server Type'}</label>
                                    {if $serverTypes|@count > 0}
                                        <select class="form-control" id="hcva-type-{$row.id}" name="server_type" required>
                                            <option value="">{$lang.select_server_type|default:'Select a server type'}</option>
                                            {foreach $serverTypes as $code => $label}
                                                <option value="{$code|escape}"{if $code == $row.legacyType} selected{/if}>{$label|escape}</option>
                                            {/foreach}
                                        </select>
                                    {else}
                                        <input type="text" class="form-control" id="hcva-type-{$row.id}" name="server_type" value="{$row.legacyType|escape}" placeholder="cx22" required>
                                    {/if}
                                </div>

                                <div class="hcva-form-group">
                                    <label for="hcva-markup-{$row.id}">{$lang.label_markup|default:'Price Markup (%)'}</label>
                                    <input type="text" class="form-control" id="hcva-markup-{$row.id}" name="markup" value="0">
                                </div>
                            </form>
                        </td>
                        <td>
                            <button type="submit" form="hcva-migrate-{$row.id}" class="btn btn-primary btn-sm"
                                data-confirm="{$lang.confirm_migrate|default:'Switch this product to Hetzner Cloud Manager and relink its services? No server is created, deleted or restarted.'}"
                                data-confirm-title="{$lang.heading_migration|default:'Migrate From The Legacy Module'}">
                                <i class="fas fa-exchange-alt" aria-hidden="true"></i> {$lang.btn_migrate|default:'Migrate'}
                            </button>
                        </td>
                    </tr>
                {/foreach}
                </tbody>
            </table>
            </div>
        {/if}
    </div>
</div>
