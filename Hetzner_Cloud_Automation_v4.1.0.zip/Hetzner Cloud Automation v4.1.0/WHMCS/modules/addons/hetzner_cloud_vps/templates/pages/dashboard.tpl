{if $apiError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-triangle hcva-highlight-icon" aria-hidden="true"></i><span>{$apiError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-chart-pie" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_estate|default:'Project Estate'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-estate-tiles">
            <div class="hcva-estate-tile hcva-estate-tile--blue">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_servers|default:'Servers'}</span>
                    <span class="hcva-estate-value">{$totals.servers}</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-server" aria-hidden="true"></i></span>
            </div>
            <div class="hcva-estate-tile hcva-estate-tile--green">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_running|default:'Running'}</span>
                    <span class="hcva-estate-value">{$totals.running}</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-circle-play" aria-hidden="true"></i></span>
            </div>
            <div class="hcva-estate-tile hcva-estate-tile--gray">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_off|default:'Powered off'}</span>
                    <span class="hcva-estate-value">{$totals.off}</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-circle-stop" aria-hidden="true"></i></span>
            </div>
            <div class="hcva-estate-tile hcva-estate-tile--purple">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_volumes|default:'Block storage'}</span>
                    <span class="hcva-estate-value">{$totals.volumeGb} GB</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-hdd" aria-hidden="true"></i></span>
            </div>
            <div class="hcva-estate-tile hcva-estate-tile--orange">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_snapshots|default:'Snapshot storage'}</span>
                    <span class="hcva-estate-value">{$totals.snapshotGb|string_format:"%.1f"} GB</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-camera" aria-hidden="true"></i></span>
            </div>
            <div class="hcva-estate-tile hcva-estate-tile--blue">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_floating|default:'Floating IPs'}</span>
                    <span class="hcva-estate-value">{$totals.floatingIps|escape}</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-map-marker-alt" aria-hidden="true"></i></span>
            </div>
            <div class="hcva-estate-tile hcva-estate-tile--green">
                <div class="hcva-estate-text">
                    <span class="hcva-estate-label">{$lang.estate_monthly|default:'Server cost / month (net)'}</span>
                    <span class="hcva-estate-value">{$totals.monthlyNet|string_format:"%.2f"} {$totals.currency|escape}</span>
                </div>
                <span class="hcva-estate-icon"><i class="fas fa-coins" aria-hidden="true"></i></span>
            </div>
        </div>
        <p class="hcva-rate-note">{$lang.estate_note|default:'Server cost is the provider list price for the running plans. Storage, IPs and traffic are billed separately by the provider.'}</p>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-unlink" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_orphans|default:'Orphan Report'}</span>
        </div>
    </div>
    <div class="panel-body">
        <p class="hcva-rate-note">{$lang.orphans_note|default:'Drift in either direction costs money quietly: a server nobody is billed for, or a service pointing at a server that no longer exists.'}</p>

        <h5 class="hcva-subhead">{$lang.orphans_unmanaged|default:'Servers with no WHMCS service'}</h5>
        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-orphan-unmanaged" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>
        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-orphan-unmanaged">
            <thead>
                <tr>
                    <th>{$lang.col_account|default:'Account'}</th>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_type|default:'Type'}</th>
                    <th>{$lang.col_location|default:'Location'}</th>
                    <th>{$lang.col_status|default:'Status'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$orphanUnmanaged item=row}
                <tr>
                    <td>{$row.account|escape}</td>
                    <td>{$row.name|escape} <span class="hcva-muted">#{$row.id}</span></td>
                    <td>{$row.type|escape}</td>
                    <td>{$row.location|escape}</td>
                    <td><span class="hcva-status hcva-status--{$row.statusVariant}">{$row.status|escape|replace:'_':' '}</span></td>
                </tr>
            {foreachelse}
                <tr><td colspan="5">{$lang.orphans_none_unmanaged|default:'Every server maps to a WHMCS service.'}</td></tr>
            {/foreach}
            </tbody>
        </table>
        </div>
        {include file="partials/pagination.tpl" pagerUrl="`$modulelink`&action=dashboard&size=`$pageSize`&missing_page=`$orphanMissingPage`" pagerParam="orphan_page" pagerPage=$orphanUnmanagedPage pagerTotalPages=$orphanUnmanagedTotalPages pagerSummary=$orphanUnmanagedSummary}

        <h5 class="hcva-subhead">{$lang.orphans_missing|default:'Services whose server no longer exists'}</h5>
        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-orphan-missing" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>
        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-orphan-missing">
            <thead>
                <tr>
                    <th>{$lang.col_service|default:'Service'}</th>
                    <th>{$lang.col_domain|default:'Domain'}</th>
                    <th>{$lang.col_status|default:'Status'}</th>
                    <th>{$lang.col_server_id|default:'Server ID'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$orphanMissing item=row}
                <tr>
                    <td><a href="clientsservices.php?userid={$row.clientId}&amp;id={$row.serviceId}" target="_blank" rel="noopener">#{$row.serviceId}</a></td>
                    <td>{$row.domain|escape}</td>
                    <td><span class="hcva-status hcva-status--{$row.statusVariant}">{$row.status|escape}</span></td>
                    <td>{$row.serverId}</td>
                </tr>
            {foreachelse}
                <tr><td colspan="4">{$lang.orphans_none_missing|default:'Every service points at a server that exists.'}</td></tr>
            {/foreach}
            </tbody>
        </table>
        </div>
        {include file="partials/pagination.tpl" pagerUrl="`$modulelink`&action=dashboard&size=`$pageSize`&orphan_page=`$orphanUnmanagedPage`" pagerParam="missing_page" pagerPage=$orphanMissingPage pagerTotalPages=$orphanMissingTotalPages pagerSummary=$orphanMissingSummary}
    </div>
</div>

<div class="hcva-estate-tiles">
    <div class="hcva-estate-tile hcva-estate-tile--blue">
        <div class="hcva-estate-text">
            <span class="hcva-estate-label">{$lang.stat_accounts|default:'Accounts'}</span>
            <span class="hcva-estate-value">{$accountCount}</span>
        </div>
        <span class="hcva-estate-icon"><i class="fas fa-key" aria-hidden="true"></i></span>
    </div>
    <div class="hcva-estate-tile hcva-estate-tile--green">
        <div class="hcva-estate-text">
            <span class="hcva-estate-label">{$lang.stat_active_accounts|default:'Active Accounts'}</span>
            <span class="hcva-estate-value">{$activeAccountCount}</span>
        </div>
        <span class="hcva-estate-icon"><i class="fas fa-circle-check" aria-hidden="true"></i></span>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-database" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.panel_table_health|default:'Database Tables'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_status|default:'Status'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$tableHealth item=row}
                <tr>
                    <td><code>{$row.table}</code></td>
                    <td>
                        {if $row.exists}
                            <span class="hcva-status hcva-status--success">{$lang.table_present|default:'Present'}</span>
                        {else}
                            <span class="hcva-status hcva-status--danger">{$lang.table_missing|default:'Missing'}</span>
                        {/if}
                    </td>
                </tr>
            {/foreach}
            </tbody>
        </table>
        </div>
    </div>
</div>
