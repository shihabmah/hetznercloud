{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage|escape}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-key" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_accounts|default:'Accounts'}</span>
        </div>
    </div>
    <div class="panel-body">
        <div class="hcva-table-toolbar">
            <button type="button" class="btn btn-primary" data-hcva-modal-open="hcva-add-account-modal">
                <i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_add_account|default:'Add Account'}
            </button>
        </div>

        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-accounts-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-accounts-table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_api_key|default:'API Token'}</th>
                    <th>{$lang.col_active|default:'Active'}</th>
                    <th>{$lang.col_action|default:'Action'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$accounts item=row}
                <tr data-hcva-row>
                    <td>{$row.name|escape}</td>
                    <td><code>{$row.maskedKey|escape}</code></td>
                    <td>
                        {if $row.is_active}
                            <span class="hcva-status hcva-status--success">{$lang.word_yes|default:'Yes'}</span>
                        {else}
                            <span class="hcva-status hcva-status--neutral">{$lang.word_no|default:'No'}</span>
                        {/if}
                    </td>
                    <td>
                        <button type="button" class="btn btn-default btn-sm" data-hcva-modal-open="hcva-edit-account-{$row.id}">
                            <i class="fas fa-pencil-alt" aria-hidden="true"></i> {$lang.btn_edit|default:'Edit'}
                        </button>

                        <form method="post" action="{$modulelink}&action=accounts" style="display:inline-block">
                            <input type="hidden" name="module_action" value="test">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="account_id" value="{$row.id}">
                            <button type="submit" class="btn btn-default btn-sm">
                                <i class="fas fa-plug" aria-hidden="true"></i> {$lang.btn_test_connection|default:'Test Connection'}
                            </button>
                        </form>

                        <form method="post" action="{$modulelink}&action=accounts" style="display:inline-block" data-confirm="{$lang.confirm_delete_account|default:'This will remove the account. Any product still using it will lose the ability to manage its servers.'}" data-confirm-variant="danger">
                            <input type="hidden" name="module_action" value="delete">
                            <input type="hidden" name="csrf_token" value="{$csrfToken}">
                            <input type="hidden" name="account_id" value="{$row.id}">
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash-alt" aria-hidden="true"></i> {$lang.btn_delete|default:'Delete'}
                            </button>
                        </form>
                    </td>
                </tr>

                <div class="hcva-modal-overlay hcva-plain-modal" id="hcva-edit-account-{$row.id}" aria-hidden="true">
                    <div class="hcva-modal-box">
                        <div class="hcva-modal-header">
                            <h4 class="hcva-modal-title">{$lang.btn_edit|default:'Edit'} &mdash; {$row.name|escape}</h4>
                            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
                        </div>
                        <div class="hcva-modal-body">
                            <form method="post" action="{$modulelink}&action=accounts">
                                <input type="hidden" name="module_action" value="update">
                                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                                <input type="hidden" name="account_id" value="{$row.id}">
                                <div class="hcva-form-group">
                                    <label for="hcva-edit-name-{$row.id}">{$lang.label_account_name|default:'Account Name'}</label>
                                    <input type="text" class="form-control" id="hcva-edit-name-{$row.id}" name="name" value="{$row.name|escape}" required>
                                </div>
                                <div class="hcva-form-group">
                                    <label for="hcva-edit-key-{$row.id}">{$lang.label_api_key|default:'Project API Token'}</label>
                                    <input type="text" class="form-control" id="hcva-edit-key-{$row.id}" name="api_key" placeholder="{$row.maskedKey|escape}">
                                    <div class="hcva-form-hint">{$lang.label_api_key_edit_hint|default:'Leave blank to keep the current token unchanged.'}</div>
                                </div>
                                <div class="hcva-form-group">
                                    <label class="hcva-switch">
                                        <input type="checkbox" name="is_active" {if $row.is_active}checked{/if}>
                                        <span class="hcva-switch-track"><span class="hcva-switch-thumb"></span></span>
                                        <span class="hcva-switch-text">{$lang.label_is_active|default:'Active'}</span>
                                    </label>
                                </div>
                                <div class="hcva-modal-footer" style="padding:0;border-top:none;">
                                    <button type="button" class="btn btn-default" data-hcva-dismiss>
                                        <i class="fas fa-times" aria-hidden="true"></i> {$lang.btn_cancel|default:'Cancel'}
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save" aria-hidden="true"></i> {$lang.btn_save|default:'Save'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            {foreachelse}
                <tr><td colspan="4">{$lang.no_accounts_configured|default:'No accounts configured yet.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="4">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-add-account-modal" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_add_account|default:'Add Account'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=accounts">
                <input type="hidden" name="module_action" value="create">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <div class="hcva-form-group">
                    <label for="hcva-add-name">{$lang.label_account_name|default:'Account Name'}</label>
                    <input type="text" class="form-control" id="hcva-add-name" name="name" required>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-add-key">{$lang.label_api_key|default:'Project API Token'}</label>
                    <input type="text" class="form-control" id="hcva-add-key" name="api_key" required>
                </div>
                <div class="hcva-form-group">
                    <label class="hcva-switch">
                        <input type="checkbox" name="is_active" checked>
                        <span class="hcva-switch-track"><span class="hcva-switch-thumb"></span></span>
                        <span class="hcva-switch-text">{$lang.label_is_active|default:'Active'}</span>
                    </label>
                </div>
                <div class="hcva-modal-footer" style="padding:0;border-top:none;">
                    <button type="button" class="btn btn-default" data-hcva-dismiss>
                        <i class="fas fa-times" aria-hidden="true"></i> {$lang.btn_cancel|default:'Cancel'}
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save" aria-hidden="true"></i> {$lang.btn_save|default:'Save'}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
