{if $actionMessage}
    <div class="hcva-highlight-box hcva-highlight-box--success"><i class="fas fa-check-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionMessage|escape}</span></div>
{/if}
{if $actionError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-circle hcva-highlight-icon" aria-hidden="true"></i><span>{$actionError|escape}</span></div>
{/if}
{if $apiError}
    <div class="hcva-highlight-box hcva-highlight-box--danger"><i class="fas fa-exclamation-triangle hcva-highlight-icon" aria-hidden="true"></i><span>{$apiError|escape}</span></div>
{/if}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas fa-server" aria-hidden="true"></i></span>
            <span class="panel-title">{$lang.heading_servers|default:'Servers'}</span>
        </div>
    </div>
    <div class="panel-body">
        <form method="get" action="addonmodules.php" class="hcva-table-toolbar" style="justify-content:flex-start;gap:8px;">
            <input type="hidden" name="module" value="hetzner_cloud_vps">
            <input type="hidden" name="action" value="servers">
            <label for="hcva-account-select" style="align-self:center;margin-right:4px;">{$lang.label_select_account|default:'Account'}</label>
            <select id="hcva-account-select" name="account_id" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$accounts item=account}
                    <option value="{$account.id}"{if $selectedAccountId == $account.id} selected{/if}>{$account.name|escape}</option>
                {/foreach}
            </select>
            <label for="hcva-page-size" style="align-self:center;margin:0 4px 0 12px;">{$lang.label_per_page|default:'Per page'}</label>
            <select id="hcva-page-size" name="size" class="form-control" style="width:auto;display:inline-block;" data-hcva-autosubmit>
                {foreach from=$pageSizes item=option}
                    <option value="{$option.value}"{if $option.selected} selected{/if}>{$option.value}</option>
                {/foreach}
            </select>
        </form>

        {if $servers|@count > 0}
        <div class="hcva-table-toolbar">
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-servers-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
        </div>
        {/if}

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-servers-table">
            <thead>
                <tr>
                    <th>{$lang.col_name|default:'Name'}</th>
                    <th>{$lang.col_status|default:'Status'}</th>
                    <th>{$lang.col_location|default:'Location'}</th>
                    <th>{$lang.col_ip|default:'IP Address'}</th>
                    <th>{$lang.col_service|default:'Service'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach from=$servers item=row}
                <tr data-hcva-row>
                    <td>{$row.name|escape} <span class="hcva-form-hint">#{$row.id}</span></td>
                    <td><span class="hcva-status hcva-status--{$row.statusVariant}">{$row.status|escape|replace:'_':' '}</span></td>
                    <td>{$row.location|escape}</td>
                    <td><code>{$row.ip|escape}</code></td>
                    <td>
                        {if $row.serviceId}
                            <a class="hcva-service-link" href="clientsservices.php?id={$row.serviceId}" target="_blank" rel="noopener" data-no-ajax>
                                <i class="fas fa-external-link-alt" aria-hidden="true"></i>
                                <span>{$lang.label_service|default:'Service'} #{$row.serviceId}</span>
                            </a>
                        {else}
                            <button type="button" class="btn btn-default btn-sm hcva-assign-open"
                                    data-server-id="{$row.id}" data-server-name="{$row.name|escape}">
                                <i class="fas fa-link" aria-hidden="true"></i> {$lang.btn_assign|default:'Assign to Service'}
                            </button>
                        {/if}
                    </td>
                </tr>
            {foreachelse}
                <tr><td colspan="5">{$lang.no_servers_found|default:'No servers found for this account.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="5">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>

        {include file="partials/pagination.tpl" pagerUrl="`$modulelink`&action=servers&account_id=`$selectedAccountId`&size=`$pageSize`" pagerParam="page" pagerPage=$page pagerTotalPages=$totalPages pagerSummary=$pagerSummary}
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-assign-modal" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_assign|default:'Assign to Service'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modulelink}&action=servers&account_id={$selectedAccountId}&size={$pageSize}&page={$page}">
                <input type="hidden" name="module_action" value="assign">
                <input type="hidden" name="csrf_token" value="{$csrfToken}">
                <input type="hidden" name="account_id" value="{$selectedAccountId}">
                <input type="hidden" name="server_id" id="hcva-assign-server-id" value="">

                <div class="hcva-highlight-box">
                    <i class="fas fa-server hcva-highlight-icon" aria-hidden="true"></i>
                    <span id="hcva-assign-server-name"></span>
                </div>

                <div class="hcva-form-group">
                    <label for="hcva-assign-client">{$lang.label_client|default:'Client'}</label>
                    <select class="form-control" id="hcva-assign-client" data-hcva-assign-services="{$assignServicesByClientJson|escape}" data-hcva-no-services="{$lang.no_eligible_services|default:'No eligible services for this client'|escape}">
                        <option value="">{$lang.label_select_client|default:'Select a client…'}</option>
                        {foreach from=$assignableClients item=client}
                            <option value="{$client.id}">{$client.label|escape}</option>
                        {/foreach}
                    </select>
                    <div class="hcva-form-hint">{$lang.assign_hint|default:'Only services on this module that are Pending or Active, and not already linked to a server, are listed.'}</div>
                </div>

                <div class="hcva-form-group">
                    <label for="hcva-assign-service">{$lang.label_service|default:'Service'}</label>
                    <select class="form-control" name="service_id" id="hcva-assign-service" required disabled>
                        <option value="">{$lang.label_select_client_first|default:'Select a client first'}</option>
                    </select>
                </div>

                <div class="hcva-modal-footer" style="padding:0;border-top:none;">
                    <button type="button" class="btn btn-default" data-hcva-dismiss>
                        <i class="fas fa-times" aria-hidden="true"></i> {$lang.btn_cancel|default:'Cancel'}
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-link" aria-hidden="true"></i> {$lang.btn_assign|default:'Assign to Service'}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
