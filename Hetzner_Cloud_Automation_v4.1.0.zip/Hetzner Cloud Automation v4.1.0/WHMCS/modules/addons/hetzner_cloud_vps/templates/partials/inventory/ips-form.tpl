{if $section == 'floatingips'}
    <input type="hidden" name="module_action" value="fipCreate">
    <div class="hcva-form-group">
        <label for="hcva-new-fip-type">{$lang.label_type|default:'Type'}</label>
        <select class="form-control" id="hcva-new-fip-type" name="ip_type">
            <option value="ipv4">IPv4</option>
            <option value="ipv6">IPv6</option>
        </select>
    </div>
    <div class="hcva-form-group">
        <label for="hcva-new-fip-server">{$lang.label_server|default:'Server'}</label>
        <select class="form-control" id="hcva-new-fip-server" name="server_id" required>
            <option value="">{$lang.select_server|default:'Select a server'}</option>
            {foreach from=$servers item=server}
                <option value="{$server.id}">{$server.name|escape} (#{$server.id})</option>
            {/foreach}
        </select>
    </div>
    <div class="hcva-form-hint">{$lang.fip_create_hint|default:'The server sets the home location and is assigned the address straight away.'}</div>
{else}
    <input type="hidden" name="module_action" value="pipCreate">
    <div class="hcva-form-group">
        <label for="hcva-new-pip-name">{$lang.label_name|default:'Name'}</label>
        <input type="text" class="form-control" id="hcva-new-pip-name" name="name" maxlength="128" required>
    </div>
    <div class="hcva-form-group">
        <label for="hcva-new-pip-type">{$lang.label_type|default:'Type'}</label>
        <select class="form-control" id="hcva-new-pip-type" name="ip_type">
            <option value="ipv4">IPv4</option>
            <option value="ipv6">IPv6</option>
        </select>
    </div>
    <div class="hcva-form-group">
        <label for="hcva-new-pip-location">{$lang.label_location|default:'Location'}</label>
        <select class="form-control" id="hcva-new-pip-location" name="location" required>
            {foreach from=$locations item=loc}
                <option value="{$loc|escape}">{$loc|escape}</option>
            {/foreach}
        </select>
    </div>
    <div class="hcva-form-hint">{$lang.pip_create_hint|default:'A primary IP is billed from the moment it exists, assigned or not.'}</div>
{/if}
