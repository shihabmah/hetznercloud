<td>{$row.name|escape}<div class="hcva-muted">#{$row.id}</div></td>
<td><code>{$row.fingerprint|escape}</code></td>
<td>{$row.created|escape}</td>
<td class="hcva-row-actions">
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-ssh-rename" data-id="{$row.id}" data-name="{$row.name|escape}" title="{$lang.btn_rename|default:'Rename'}">
        <i class="fas fa-pen" aria-hidden="true"></i>
    </button>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="sshDelete">
        <input type="hidden" name="ssh_id" value="{$row.id}">
        <button type="submit" class="btn btn-danger btn-sm"
                data-confirm="{$lang.confirm_ssh_delete|default:'Delete this SSH key? Servers already built with it keep working; new builds can no longer use it.'}"
                data-confirm-variant="danger" title="{$lang.btn_delete|default:'Delete'}">
        <i class="fas fa-trash" aria-hidden="true"></i>
    </button>
    </form>
</td>
