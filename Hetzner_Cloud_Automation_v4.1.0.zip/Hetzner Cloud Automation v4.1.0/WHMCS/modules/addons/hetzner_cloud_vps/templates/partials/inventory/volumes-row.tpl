<td>{$row.name|escape}<div class="hcva-muted">#{$row.id}</div></td>
<td>{$row.size} GB<div class="hcva-muted">{$row.format|escape}</div></td>
<td>{$row.location|escape}</td>
<td>
    {if $row.serverId}
        <span class="hcva-badge hcva-badge--success">#{$row.serverId}</span>
    {else}
        <span class="hcva-badge">{$lang.word_none|default:'None'}</span>
    {/if}
</td>
<td>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="volProtect">
        <input type="hidden" name="volume_id" value="{$row.id}">
        <input type="hidden" name="enabled" value="{if $row.protected}0{else}1{/if}">
        <button type="submit" class="btn btn-default btn-sm">
            {if $row.protected}{$lang.word_on|default:'On'}{else}{$lang.word_off|default:'Off'}{/if}
        </button>
    </form>
</td>
<td class="hcva-row-actions">
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-vol-rename" data-id="{$row.id}" data-name="{$row.name|escape}" title="{$lang.btn_rename|default:'Rename'}">
        <i class="fas fa-pen" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-vol-labels" data-id="{$row.id}" data-labels="{$row.labels|escape}" title="{$lang.btn_label|default:'Add labels'}">
        <i class="fas fa-tags" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-vol-resize" data-id="{$row.id}" data-size="{$row.size}" title="{$lang.btn_resize|default:'Resize'}">
        <i class="fas fa-expand" aria-hidden="true"></i>
    </button>
    {if $row.serverId}
        <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
            <input type="hidden" name="module_action" value="volDetach">
            <input type="hidden" name="volume_id" value="{$row.id}">
            <button type="submit" class="btn btn-default btn-sm"
                    data-confirm="{$lang.confirm_vol_detach|default:'Detach this volume? Unmount it inside the server first or you risk losing data.'}" title="{$lang.btn_detach|default:'Detach'}">
        <i class="fas fa-unlink" aria-hidden="true"></i>
    </button>
        </form>
    {else}
        <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
                data-form="hcva-vol-attach" data-id="{$row.id}" title="{$lang.btn_attach|default:'Attach'}">
        <i class="fas fa-link" aria-hidden="true"></i>
    </button>
    {/if}
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="volDelete">
        <input type="hidden" name="volume_id" value="{$row.id}">
        <button type="submit" class="btn btn-danger btn-sm"
                data-confirm="{$lang.confirm_vol_delete|default:'Delete this volume? Everything stored on it is destroyed and cannot be recovered.'}"
                data-confirm-variant="danger" title="{$lang.btn_delete|default:'Delete'}">
        <i class="fas fa-trash" aria-hidden="true"></i>
    </button>
    </form>
</td>
