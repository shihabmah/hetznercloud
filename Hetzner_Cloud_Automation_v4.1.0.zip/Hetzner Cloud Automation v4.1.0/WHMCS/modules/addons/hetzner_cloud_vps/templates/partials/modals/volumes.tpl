{assign var=modalBase value="`$modulelink`&action=resources&account_id=`$selectedAccountId`&size=`$pageSize`&res=`$section`&page=`$page`"}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-vol-rename" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="volRename">
                <input type="hidden" name="volume_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-vol-rename-name">{$lang.label_name|default:'Name'}</label>
                    <input type="text" class="form-control" id="hcva-vol-rename-name" name="name" data-hcva-fill="name" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-vol-resize" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_resize|default:'Resize'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="volResize">
                <input type="hidden" name="volume_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-vol-resize-size">{$lang.label_size_gb|default:'Size (GB)'}</label>
                    <input type="number" class="form-control" id="hcva-vol-resize-size" name="size" data-hcva-fill="size" min="10" max="10240" required>
                </div>
                <div class="hcva-form-hint">{$lang.vol_resize_hint|default:'A volume can only grow. Extend the filesystem inside the server afterwards.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-vol-attach" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_attach|default:'Attach'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="volAttach">
                <input type="hidden" name="volume_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-vol-attach-server">{$lang.label_server|default:'Server'}</label>
                    <select class="form-control" id="hcva-vol-attach-server" name="server_id" required>
                        <option value="">{$lang.select_server|default:'Select a server'}</option>
                        {foreach from=$servers item=server}
                            <option value="{$server.id}">{$server.name|escape} (#{$server.id})</option>
                        {/foreach}
                    </select>
                </div>
                <div class="hcva-form-hint">{$lang.vol_attach_hint|default:'The volume must be in the same location as the server.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_attach|default:'Attach'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-vol-labels" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_label|default:'Add labels'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="volLabels">
                <input type="hidden" name="volume_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group hcva-form-group--wide">
                    <label for="hcva-vol-labels-value">{$lang.label_labels|default:'Labels'}</label>
                    <input type="text" class="form-control" id="hcva-vol-labels-value" name="labels" data-hcva-fill="labels" placeholder="owner=support, tier=gold">
                </div>
                <div class="hcva-form-hint">{$lang.hint_labels|default:'Use key=value pairs separated by commas. Labels are notes at the provider and do not rename the resource.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>
