<input type="hidden" name="module_action" value="volCreate">
<div class="hcva-form-group">
    <label for="hcva-new-vol-name">{$lang.label_name|default:'Name'}</label>
    <input type="text" class="form-control" id="hcva-new-vol-name" name="name" maxlength="128" required>
</div>
<div class="hcva-form-group">
    <label for="hcva-new-vol-size">{$lang.label_size_gb|default:'Size (GB)'}</label>
    <input type="number" class="form-control" id="hcva-new-vol-size" name="size" min="10" max="10240" value="10" required>
</div>
<div class="hcva-form-group">
    <label for="hcva-new-vol-format">{$lang.label_format|default:'Filesystem'}</label>
    <select class="form-control" id="hcva-new-vol-format" name="format">
        <option value="xfs">xfs</option>
        <option value="ext4">ext4</option>
    </select>
</div>
<div class="hcva-form-group">
    <label for="hcva-new-vol-location">{$lang.label_location|default:'Location'}</label>
    <select class="form-control" id="hcva-new-vol-location" name="location">
        <option value="">{$lang.select_location|default:'Choose a location'}</option>
        {foreach from=$locations item=loc}
            <option value="{$loc|escape}">{$loc|escape}</option>
        {/foreach}
    </select>
</div>
<div class="hcva-form-group">
    <label for="hcva-new-vol-server">{$lang.label_attach_to|default:'Or attach to server'}</label>
    <select class="form-control" id="hcva-new-vol-server" name="server_id">
        <option value="">{$lang.word_none|default:'None'}</option>
        {foreach from=$servers item=server}
            <option value="{$server.id}">{$server.name|escape} (#{$server.id})</option>
        {/foreach}
    </select>
</div>
