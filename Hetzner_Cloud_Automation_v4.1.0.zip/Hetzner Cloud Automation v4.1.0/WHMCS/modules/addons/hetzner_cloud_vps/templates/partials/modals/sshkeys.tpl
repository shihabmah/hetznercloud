{assign var=modalBase value="`$modulelink`&action=resources&account_id=`$selectedAccountId`&size=`$pageSize`&res=`$section`&page=`$page`"}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-ssh-rename" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="sshRename">
                <input type="hidden" name="ssh_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-ssh-rename-name">{$lang.label_name|default:'Name'}</label>
                    <input type="text" class="form-control" id="hcva-ssh-rename-name" name="name" data-hcva-fill="name" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>
