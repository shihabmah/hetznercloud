    <th>{$lang.col_name|default:'Name'}</th>
    <th>{$lang.col_ip|default:'IP Address'}</th>
    <th>{$lang.col_type|default:'Type'}</th>
    <th>{$lang.col_location|default:'Location'}</th>
    <th>{$lang.col_assigned_to|default:'Assigned to'}</th>
    <th>{$lang.col_rdns|default:'Reverse DNS'}</th>
    <th>{$lang.col_action|default:'Action'}</th>
