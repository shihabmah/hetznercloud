<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/dTD5Tx8OsO0csXT5Qx4hsaL5UDDO5QzUP2FNDLnpPl4Vc01WRC2E1j6fgbo3Fa5HD3FLLe
pi0LD4Av7TulOvrErZqgNY1tt5VxRARLQiGoA0pbLIq1IM1/y4/XfNLfsngqIUFn2Ju59XALyD9j
CAAfHsWZy+5zb1kaqyZYbv8lpC3KfmCoXsYd6/krr0QA0sVoBG3ODn7G5Bg7KJwLmLFRhq0ISLRp
BMZSM0NSJi83Jm735cslauV1hdtuB0LIzXMeKoqo3Vm8Ha/vA09wQdSnyfBlO9v6WnelHqvABHIe
7JZ+5F/jsMQ73GHJl6gCG7vquzYt3JZ54Knu6vTP5ADvmnD/Rr6KrddruK+wYnoQhoavei9fiUR6
JhsrJjU49P9iG7Fa7Z2SOQ1J52XJDNE3O/VH9rXKQB4nn0xY86b+T9yrXFbczJlXQ16ukBr3eKMc
ZwsXl9Ol3331TfVrmut8gMmQ6OMTjG51sjYumXZiTZD8P2q9H3v375mlgfkQ/MRyOlzSCYnalNmj
cJwR7iZVIoF/scAngANoGY1gd5KsFyS9jcQNZeXlT3isCcliftuulKzS7P9veaTpiin6hpfUgCvj
hs5TJR3yFzP3ecIDvTzxabw4nKNuxs27E2FghU89LcqfKWXUZ/JV5egOFNU+R2RvjGdRPHoJtoK7
U+jwvFXnkXVQK00Jj5xQzPVVG+D9YmkzDrEOPmm9cbZs/hPeu79HtoTdDOFmpy0FugoWmngtlztc
vSo9YbHQn8/jn5gD/yTJT/kewDnnBXp9lEf7WzAFlQn6pJImO+WYEjeX+6zMNuV+QBK06RzHBhyn
rRaezPnp168TBUaiXV0VJ3OWPxIhmJZ8WAGohF5gpdEjnTAkBKuYkU3RmIu=