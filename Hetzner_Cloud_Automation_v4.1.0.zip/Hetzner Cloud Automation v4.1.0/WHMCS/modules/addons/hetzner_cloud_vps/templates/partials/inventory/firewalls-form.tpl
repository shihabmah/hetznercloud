<input type="hidden" name="module_action" value="fwCreate">
<div class="hcva-form-group">
    <label for="hcva-new-fw-name">{$lang.label_name|default:'Name'}</label>
    <input type="text" class="form-control" id="hcva-new-fw-name" name="name" maxlength="128" required>
</div>
<div class="hcva-form-hint">{$lang.fw_create_hint|default:'A new firewall has no inbound rules, and the provider drops all inbound traffic in that state - including SSH. Add the rules you need before applying it to a server.'}</div>
