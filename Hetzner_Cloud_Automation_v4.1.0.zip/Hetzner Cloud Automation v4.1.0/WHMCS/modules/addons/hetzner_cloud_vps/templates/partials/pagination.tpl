<div class="hcva-pagination">
    {if $pagerPage > 1}
        <a class="btn btn-default" href="{$pagerUrl}&{$pagerParam}=1" title="{$lang.pagination_first|default:'First'}"><i class="fas fa-angle-double-left" aria-hidden="true"></i></a>
        <a class="btn btn-default" href="{$pagerUrl}&{$pagerParam}={$pagerPage-1}" title="{$lang.pagination_previous|default:'Previous'}"><i class="fas fa-angle-left" aria-hidden="true"></i></a>
    {else}
        <button type="button" class="btn btn-default" disabled title="{$lang.pagination_first|default:'First'}"><i class="fas fa-angle-double-left" aria-hidden="true"></i></button>
        <button type="button" class="btn btn-default" disabled title="{$lang.pagination_previous|default:'Previous'}"><i class="fas fa-angle-left" aria-hidden="true"></i></button>
    {/if}

    <span class="hcva-pagination-summary">{$pagerSummary|escape}</span>

    {if $pagerPage < $pagerTotalPages}
        <a class="btn btn-default" href="{$pagerUrl}&{$pagerParam}={$pagerPage+1}" title="{$lang.pagination_next|default:'Next'}"><i class="fas fa-angle-right" aria-hidden="true"></i></a>
        <a class="btn btn-default" href="{$pagerUrl}&{$pagerParam}={$pagerTotalPages}" title="{$lang.pagination_last|default:'Last'}"><i class="fas fa-angle-double-right" aria-hidden="true"></i></a>
    {else}
        <button type="button" class="btn btn-default" disabled title="{$lang.pagination_next|default:'Next'}"><i class="fas fa-angle-right" aria-hidden="true"></i></button>
        <button type="button" class="btn btn-default" disabled title="{$lang.pagination_last|default:'Last'}"><i class="fas fa-angle-double-right" aria-hidden="true"></i></button>
    {/if}
</div>
