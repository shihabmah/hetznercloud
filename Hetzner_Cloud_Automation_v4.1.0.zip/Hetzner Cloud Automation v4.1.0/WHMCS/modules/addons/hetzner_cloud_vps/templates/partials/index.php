<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/6e/qRjS8h4mWqOQixMcmhdfLSxQAVCtzmDntjeb/3y/n4nuHeAZFoJfVzrDZ/gBySroI+Z
3LOGgzdsJbc6LGUhmZ9vp5OtaUsPU1nYuP1ycB8zZfBB+nCPqRYopbDKz/eQmxXLcxzJr0oRd0R9
bbSfxnCxoH2YeHNlkrK2tITaYA8G0VoBYXfGGjHmfotkRHpQq7+5ZKVT+ggCRHUVMRKKXtM44TNj
qOHysdB1LG1EGA6qxyU9jkXWETtXgHPuxUgX798jCWty24PF+IW2UcftCVAIqstJnLd3qpHfeBEi
K26HtcJ/UC9abhK0nCH7GHmQsf7ZPe5PC0QwzCOiLZFO3m0Bb3cznZGMjVCsXCmAict91B8Svvrf
qnmNM2jL2i2P9xBO1MMVynJ66vu7iD0fEAJyLtdSipRj/B7Aj1SMskOauysSRl9+wnujB3t/eBWG
GH0gMJ8F24INuzFb0aqbavnBlQvlI1TIPTkWU6KswqI35bZrtcaMPeFKkHDQdCLi4dfTRd8efFHL
DDIAIW0Myx2PSLB9qUn1kWOmQAiY18GE+SBCdZqKQONsj2SJQ50mQ7j+2grtNEUimml5Q6ArrAvn
ZGXdLr0VIozuB3GNEPcurxMUiJGRMUNYrJ0F52lRz+QyNgmGoOoQqHaeEX0jPh93zfcQ8OeLis9p
/pJUnswH9odAcZvJZf03Vhcq1RxcBRZmnhOJ3biZKBAg1u3cEPlaQByof8FkWwtaif/j+v4Lo7B+
lVBtOSAh63iEtiSPK/aaDkOCCu1cymdEQCbELcu+Bm2HIg9tDOi39ZQb5fqjQamhTHlw5OG1nVnH
OMP14PW7JxzRYnqMr9r828FnqDG51IsVxCPgc5JepUmJPlvwhEhBZ+O=