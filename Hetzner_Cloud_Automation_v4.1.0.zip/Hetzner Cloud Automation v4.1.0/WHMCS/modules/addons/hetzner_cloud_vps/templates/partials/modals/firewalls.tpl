{assign var=modalBase value="`$modulelink`&action=resources&account_id=`$selectedAccountId`&size=`$pageSize`&res=`$section`&page=`$page`"}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-fw-rename" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="fwRename">
                <input type="hidden" name="firewall_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-fw-rename-name">{$lang.label_name|default:'Name'}</label>
                    <input type="text" class="form-control" id="hcva-fw-rename-name" name="name" data-hcva-fill="name" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-fw-rule" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_add_rule|default:'Add Rule'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="fwRuleAdd">
                <input type="hidden" name="firewall_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-fw-rule-direction">{$lang.label_direction|default:'Direction'}</label>
                    <select class="form-control" id="hcva-fw-rule-direction" name="direction">
                        {foreach from=$ruleDirections item=direction}
                            <option value="{$direction}">{$direction}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-fw-rule-protocol">{$lang.label_protocol|default:'Protocol'}</label>
                    <select class="form-control" id="hcva-fw-rule-protocol" name="protocol">
                        {foreach from=$ruleProtocols item=protocol}
                            <option value="{$protocol}">{$protocol}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-fw-rule-port">{$lang.label_port|default:'Port'}</label>
                    <input type="text" class="form-control" id="hcva-fw-rule-port" name="port" placeholder="443">
                </div>
                <div class="hcva-form-group hcva-form-group--wide">
                    <label for="hcva-fw-rule-ips">{$lang.label_cidrs|default:'Source / destination CIDRs'}</label>
                    <input type="text" class="form-control" id="hcva-fw-rule-ips" name="ips" placeholder="0.0.0.0/0, ::/0" required>
                </div>
                <div class="hcva-form-hint">{$lang.fw_rule_hint|default:'Separate several ranges with commas. Each must be network-aligned, so 10.0.0.0/8 rather than 10.0.0.1/8.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_add_rule|default:'Add Rule'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-fw-apply" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_apply|default:'Apply'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="fwApply">
                <input type="hidden" name="firewall_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-fw-apply-server">{$lang.label_server|default:'Server'}</label>
                    <select class="form-control" id="hcva-fw-apply-server" name="server_id" required>
                        <option value="">{$lang.select_server|default:'Select a server'}</option>
                        {foreach from=$servers item=server}
                            <option value="{$server.id}">{$server.name|escape} (#{$server.id})</option>
                        {/foreach}
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">{$lang.btn_apply|default:'Apply'}</button>
            </form>
        </div>
    </div>
</div>
