<div id="hcva-page-content" data-modulelink="{$modulelink}">
{if $updateAvailable}
    <div class="hcva-highlight-box hcva-highlight-box--warning">
        <i class="fas fa-arrow-circle-up hcva-highlight-icon" aria-hidden="true"></i>
        <span>{$lang.license_update_available|default:'A newer version (%latest%) is available — you are running %current%.'|replace:'%latest%':$latestVersion|replace:'%current%':$assetsVersion}</span>
    </div>
{/if}
{if !$hideNav}
    <nav class="hcva-topnav" aria-label="{$moduleTitle|escape} navigation">
        <a class="hcva-nav-link{if $activePage == 'dashboard'} active{/if}" href="{$modulelink}">
            <i class="fas fa-tachometer-alt" aria-hidden="true"></i><span>{$lang.nav_dashboard|default:'Dashboard'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'accounts'} active{/if}" href="{$modulelink}&action=accounts">
            <i class="fas fa-key" aria-hidden="true"></i><span>{$lang.nav_accounts|default:'Accounts'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'server-list'} active{/if}" href="{$modulelink}&action=servers">
            <i class="fas fa-server" aria-hidden="true"></i><span>{$lang.nav_servers|default:'Servers'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'products'} active{/if}" href="{$modulelink}&action=products">
            <i class="fas fa-box" aria-hidden="true"></i><span>{$lang.nav_products|default:'Products'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'resources'} active{/if}" href="{$modulelink}&action=resources">
            <i class="fas fa-network-wired" aria-hidden="true"></i><span>{$lang.nav_resources|default:'Resources'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'snapshots'} active{/if}" href="{$modulelink}&action=snapshots">
            <i class="fas fa-camera" aria-hidden="true"></i><span>{$lang.nav_snapshots|default:'Snapshots'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'migration'} active{/if}" href="{$modulelink}&action=migration">
            <i class="fas fa-exchange-alt" aria-hidden="true"></i><span>{$lang.nav_migration|default:'Migration'}</span>
        </a>
        <a class="hcva-nav-link{if $activePage == 'license'} active{/if}" href="{$modulelink}&action=license">
            <i class="fas fa-certificate" aria-hidden="true"></i><span>{$lang.nav_license|default:'License'}</span>
        </a>
    </nav>

    {if $activePage == 'accounts'}{assign var=crumbIcon value='fa-key'}{assign var=crumbLabel value=$lang.nav_accounts|default:'Accounts'}
    {elseif $activePage == 'server-list'}{assign var=crumbIcon value='fa-server'}{assign var=crumbLabel value=$lang.nav_servers|default:'Servers'}
    {elseif $activePage == 'products'}{assign var=crumbIcon value='fa-box'}{assign var=crumbLabel value=$lang.nav_products|default:'Products'}
    {elseif $activePage == 'resources'}{assign var=crumbIcon value='fa-network-wired'}{assign var=crumbLabel value=$lang.nav_resources|default:'Resources'}
    {elseif $activePage == 'snapshots'}{assign var=crumbIcon value='fa-camera'}{assign var=crumbLabel value=$lang.nav_snapshots|default:'Snapshots'}
    {elseif $activePage == 'migration'}{assign var=crumbIcon value='fa-exchange-alt'}{assign var=crumbLabel value=$lang.nav_migration|default:'Migration'}
    {elseif $activePage == 'license'}{assign var=crumbIcon value='fa-certificate'}{assign var=crumbLabel value=$lang.nav_license|default:'License'}
    {else}{assign var=crumbIcon value='fa-tachometer-alt'}{assign var=crumbLabel value=$lang.nav_dashboard|default:'Dashboard'}
    {/if}

    <nav class="hcva-breadcrumb" aria-label="{$lang.breadcrumb_aria|default:'Breadcrumb'}">
        <a class="hcva-breadcrumb-link" href="{$modulelink}">
            <i class="fas fa-home" aria-hidden="true"></i><span>{$moduleTitle|escape}</span>
        </a>
        <i class="fas fa-chevron-right hcva-breadcrumb-sep" aria-hidden="true"></i>
        <span class="hcva-breadcrumb-current" aria-current="page">
            <i class="fas {$crumbIcon}" aria-hidden="true"></i><span>{$crumbLabel|escape}</span>
        </span>
    </nav>
{/if}

<div class="hcva-main">
    {include file=$contentTemplate}
</div>
</div>
