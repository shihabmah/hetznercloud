    <th>{$lang.col_name|default:'Name'}</th>
    <th>{$lang.col_size|default:'Size'}</th>
    <th>{$lang.col_location|default:'Location'}</th>
    <th>{$lang.col_attached_to|default:'Attached to'}</th>
    <th>{$lang.col_protection|default:'Protection'}</th>
    <th>{$lang.col_action|default:'Action'}</th>
