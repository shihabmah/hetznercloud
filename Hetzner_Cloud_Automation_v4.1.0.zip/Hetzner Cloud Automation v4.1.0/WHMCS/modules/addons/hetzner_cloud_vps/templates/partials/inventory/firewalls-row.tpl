<td>{$row.name|escape}<div class="hcva-muted">#{$row.id}</div></td>
<td>
    {if $row.ruleCount > 0}
        <ul class="hcva-rule-list">
        {foreach from=$row.rules item=rule key=ruleIndex}
            <li>
                <span class="hcva-badge">{$rule.direction|escape}</span>
                {$rule.protocol|escape}{if $rule.port} :{$rule.port|escape}{/if}
                <span class="hcva-muted">{$rule.ips|escape}</span>
                <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
                    <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                    <input type="hidden" name="module_action" value="fwRuleDelete">
                    <input type="hidden" name="firewall_id" value="{$row.id}">
                    <input type="hidden" name="rule_index" value="{$ruleIndex}">
                    <button type="submit" class="btn btn-link btn-sm"
                            data-confirm="{$lang.confirm_fw_rule_delete|default:'Remove this rule? Traffic it allowed will start being dropped immediately.'}">
                        <i class="fas fa-times" aria-hidden="true"></i>
                    </button>
                </form>
            </li>
        {/foreach}
        </ul>
    {else}
        <span class="hcva-muted">{$lang.no_rules|default:'No rules - applying this firewall drops all inbound traffic.'}</span>
    {/if}
</td>
<td>{$row.appliedTo}</td>
<td class="hcva-row-actions">
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-fw-rename" data-id="{$row.id}" data-name="{$row.name|escape}" title="{$lang.btn_rename|default:'Rename'}">
        <i class="fas fa-pen" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-fw-rule" data-id="{$row.id}" title="{$lang.btn_add_rule|default:'Add Rule'}">
        <i class="fas fa-plus" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-fw-apply" data-id="{$row.id}" title="{$lang.btn_apply|default:'Apply'}">
        <i class="fas fa-server" aria-hidden="true"></i>
    </button>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="fwDelete">
        <input type="hidden" name="firewall_id" value="{$row.id}">
        <button type="submit" class="btn btn-danger btn-sm"
                data-confirm="{$lang.confirm_fw_delete|default:'Delete this firewall? Every server it protects loses those rules at once.'}"
                data-confirm-variant="danger" title="{$lang.btn_delete|default:'Delete'}">
        <i class="fas fa-trash" aria-hidden="true"></i>
    </button>
    </form>
</td>
