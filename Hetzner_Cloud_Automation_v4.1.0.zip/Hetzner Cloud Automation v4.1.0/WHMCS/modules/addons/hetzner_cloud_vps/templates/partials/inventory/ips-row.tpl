{if $section == 'floatingips'}
    {assign var=idField value='fip_id'}
    {assign var=prefix value='fip'}
{else}
    {assign var=idField value='pip_id'}
    {assign var=prefix value='pip'}
{/if}
<td>{$row.name|escape}<div class="hcva-muted">#{$row.id}</div></td>
<td><code>{$row.ip|escape}</code></td>
<td><span class="hcva-badge">{$row.type|escape}</span></td>
<td>{$row.location|escape}</td>
<td>
    {if $row.serverId}
        <span class="hcva-badge hcva-badge--success">#{$row.serverId}</span>
    {else}
        <span class="hcva-badge">{$lang.word_none|default:'None'}</span>
    {/if}
</td>
<td>
    {if $row.block}
        {if $row.ptrRecords}
            <ul class="hcva-ptr-list">
                {foreach from=$row.ptrRecords item=record}
                    <li>
                        <code>{$record.ip|escape}</code>
                        <span>{$record.dnsPtr|escape}</span>
                        <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
                            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                            <input type="hidden" name="module_action" value="{$prefix}Rdns">
                            <input type="hidden" name="{$idField}" value="{$row.id}">
                            <input type="hidden" name="ip" value="{$record.ip|escape}">
                            <input type="hidden" name="hostname" value="">
                            <button type="submit" class="btn btn-link btn-sm" title="{$lang.btn_remove|default:'Remove'}"
                                    data-confirm="{$lang.confirm_rdns_remove|default:'Remove the reverse DNS record for this address?'}">
                                <i class="fas fa-times" aria-hidden="true"></i>
                            </button>
                        </form>
                    </li>
                {/foreach}
            </ul>
        {else}
            <span class="hcva-muted">{$lang.rdns_none|default:'No entries'}</span>
        {/if}
        <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form hcva-ptr-add">
            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
            <input type="hidden" name="module_action" value="{$prefix}Rdns">
            <input type="hidden" name="{$idField}" value="{$row.id}">
            <input type="text" class="form-control" name="ip" value="{$row.suggestion|escape}" aria-label="{$lang.label_ip_address|default:'Address inside the block'}">
            <input type="text" class="form-control" name="hostname" placeholder="hostname.example.com" aria-label="{$lang.label_hostname|default:'Hostname'}">
            <button type="submit" class="btn btn-default btn-sm" title="{$lang.btn_add|default:'Add'}">
                <i class="fas fa-plus" aria-hidden="true"></i>
            </button>
        </form>
    {elseif $row.dnsPtr}
        {$row.dnsPtr|escape}
    {else}
        <span class="hcva-muted">&mdash;</span>
    {/if}
</td>
<td class="hcva-row-actions">
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-{$prefix}-rename" data-id="{$row.id}" data-name="{$row.name|escape}" title="{$lang.btn_rename|default:'Rename'}">
        <i class="fas fa-pen" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-{$prefix}-labels" data-id="{$row.id}" data-labels="{$row.labels|escape}" title="{$lang.btn_label|default:'Add labels'}">
        <i class="fas fa-tags" aria-hidden="true"></i>
    </button>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="{$prefix}RdnsReset">
        <input type="hidden" name="{$idField}" value="{$row.id}">
        <input type="hidden" name="ip" value="{$row.ip|escape}">
        <button type="submit" class="btn btn-default btn-sm"
                data-confirm="{$lang.confirm_rdns_reset|default:'Reset reverse DNS for this address back to the provider default?'}" title="{$lang.btn_rdns_reset|default:'Reset reverse DNS'}">
        <i class="fas fa-undo" aria-hidden="true"></i>
    </button>
    </form>
    {if !$row.block}
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit" title="{$lang.btn_rdns|default:'Reverse DNS'}"
            data-form="hcva-{$prefix}-rdns" data-id="{$row.id}" data-ip="{$row.ip|escape}" data-hostname="{$row.dnsPtr|escape}">
        <i class="fas fa-globe" aria-hidden="true"></i>
    </button>
    {/if}
    {if $row.serverId}
        <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
            <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
            <input type="hidden" name="module_action" value="{$prefix}Unassign">
            <input type="hidden" name="{$idField}" value="{$row.id}">
            <button type="submit" class="btn btn-default btn-sm"
                    data-confirm="{$lang.confirm_ip_unassign|default:'Unassign this address? The server loses it immediately, and it keeps being billed until deleted.'}" title="{$lang.btn_unassign|default:'Unassign'}">
        <i class="fas fa-unlink" aria-hidden="true"></i>
    </button>
        </form>
    {else}
        <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
                data-form="hcva-{$prefix}-assign" data-id="{$row.id}" title="{$lang.btn_assign_ip|default:'Assign'}">
        <i class="fas fa-link" aria-hidden="true"></i>
    </button>
    {/if}
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="{$prefix}Protect">
        <input type="hidden" name="{$idField}" value="{$row.id}">
        <input type="hidden" name="enabled" value="{if $row.protected}0{else}1{/if}">
        <button type="submit" class="btn btn-default btn-sm">
            <i class="fas fa-shield-alt" aria-hidden="true"></i>
            {if $row.protected}{$lang.word_on|default:'On'}{else}{$lang.word_off|default:'Off'}{/if}
        </button>
    </form>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="{$prefix}Delete">
        <input type="hidden" name="{$idField}" value="{$row.id}">
        <button type="submit" class="btn btn-danger btn-sm"
                data-confirm="{$lang.confirm_ip_delete|default:'Delete this address? It is released back to Hetzner and cannot be recovered.'}"
                data-confirm-variant="danger" title="{$lang.btn_delete|default:'Delete'}">
        <i class="fas fa-trash" aria-hidden="true"></i>
    </button>
    </form>
</td>
