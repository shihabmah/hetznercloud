{if $inventoryKind}
{assign var=inventoryBase value="`$modulelink`&action=resources&account_id=`$selectedAccountId`&size=`$pageSize`&res=`$section`"}

<div class="panel panel-default">
    <div class="panel-heading">
        <div class="hcva-panel-heading">
            <span class="hcva-panel-icon"><i class="fas {$sectionIcon}" aria-hidden="true"></i></span>
            <span class="panel-title">{$sectionLabel|escape}</span>
            {if $totalEntries > 0}<span class="hcva-count-pill">{$totalEntries}</span>{/if}
        </div>
    </div>
    <div class="panel-body">

        <div class="hcva-table-toolbar">
            <button type="button" class="btn btn-primary" data-hcva-modal-open="hcva-inventory-create">
                <i class="fas fa-plus" aria-hidden="true"></i> {$sectionAddLabel|escape}
            </button>
            {if $rows|@count > 0}
            <div class="hcva-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" data-hcva-table-search="hcva-inventory-table" placeholder="{$lang.search_placeholder|default:'Search this page&hellip;'}" aria-label="{$lang.search_aria|default:'Search this page'}">
            </div>
            {/if}
        </div>

        <div class="hcva-table-wrap">
        <table class="table table-striped" id="hcva-inventory-table">
            <thead>
                <tr>
                    {include file="partials/inventory/`$inventoryKind`-head.tpl"}
                </tr>
            </thead>
            <tbody>
            {foreach from=$rows item=row}
                <tr data-hcva-row>
                    {include file="partials/inventory/`$inventoryKind`-row.tpl"}
                </tr>
            {foreachelse}
                <tr><td colspan="7">{$lang.no_inventory_rows|default:'Nothing of this kind exists in the Project yet.'}</td></tr>
            {/foreach}
            <tr class="hcva-no-results"><td colspan="7">{$lang.no_search_results|default:'No rows on this page match your search.'}</td></tr>
            </tbody>
        </table>
        </div>

        {include file="partials/pagination.tpl" pagerUrl=$inventoryBase pagerParam="page" pagerPage=$page pagerTotalPages=$totalPages pagerSummary=$pagerSummary}
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-inventory-create" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$sectionAddLabel|escape}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$inventoryBase}&page={$page}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                {include file="partials/inventory/`$inventoryKind`-form.tpl"}
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus" aria-hidden="true"></i> {$lang.btn_create|default:'Create'}</button>
            </form>
        </div>
    </div>
</div>

{include file="partials/modals/`$inventoryKind`.tpl"}
{/if}
