<td>{$row.name|escape}<div class="hcva-muted">#{$row.id}</div></td>
<td><code>{$row.ipRange|escape}</code></td>
<td>
    {foreach from=$row.subnets item=subnet}
        <div>
            <code>{$subnet.ipRange|escape}</code>
            <span class="hcva-muted">{$subnet.zone|escape}</span>
            <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="netSubnetDelete">
                <input type="hidden" name="network_id" value="{$row.id}">
                <input type="hidden" name="ip_range" value="{$subnet.ipRange|escape}">
                <button type="submit" class="btn btn-link btn-sm"
                        data-confirm="{$lang.confirm_subnet_delete|default:'Remove this subnet? Servers using it lose their private address.'}">
                    <i class="fas fa-times" aria-hidden="true"></i>
                </button>
            </form>
        </div>
    {foreachelse}
        <span class="hcva-muted">{$lang.no_subnets|default:'No subnets yet.'}</span>
    {/foreach}
</td>
<td>{$row.serverCount}</td>
<td>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="netProtect">
        <input type="hidden" name="network_id" value="{$row.id}">
        <input type="hidden" name="enabled" value="{if $row.protected}0{else}1{/if}">
        <button type="submit" class="btn btn-default btn-sm">
            {if $row.protected}{$lang.word_on|default:'On'}{else}{$lang.word_off|default:'Off'}{/if}
        </button>
    </form>
</td>
<td class="hcva-row-actions">
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-net-rename" data-id="{$row.id}" data-name="{$row.name|escape}" title="{$lang.btn_rename|default:'Rename'}">
        <i class="fas fa-pen" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-net-subnet" data-id="{$row.id}" title="{$lang.btn_add_subnet|default:'Add Subnet'}">
        <i class="fas fa-plus" aria-hidden="true"></i>
    </button>
    <button type="button" class="btn btn-default btn-sm hcva-inv-edit"
            data-form="hcva-net-route" data-id="{$row.id}" title="{$lang.btn_add_route|default:'Add Route'}">
        <i class="fas fa-route" aria-hidden="true"></i>
    </button>
    <form method="post" action="{$inventoryBase}&page={$page}" class="hcva-inline-form">
        <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
        <input type="hidden" name="module_action" value="netDelete">
        <input type="hidden" name="network_id" value="{$row.id}">
        <button type="submit" class="btn btn-danger btn-sm"
                data-confirm="{$lang.confirm_net_delete|default:'Delete this network? Servers attached to it lose their private connectivity.'}"
                data-confirm-variant="danger" title="{$lang.btn_delete|default:'Delete'}">
        <i class="fas fa-trash" aria-hidden="true"></i>
    </button>
    </form>
</td>
