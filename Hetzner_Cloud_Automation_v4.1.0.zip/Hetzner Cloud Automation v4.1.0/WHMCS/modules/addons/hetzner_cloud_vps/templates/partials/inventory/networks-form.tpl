<input type="hidden" name="module_action" value="netCreate">
<div class="hcva-form-group">
    <label for="hcva-new-net-name">{$lang.label_name|default:'Name'}</label>
    <input type="text" class="form-control" id="hcva-new-net-name" name="name" maxlength="128" required>
</div>
<div class="hcva-form-group">
    <label for="hcva-new-net-range">{$lang.label_ip_range|default:'IP Range'}</label>
    <input type="text" class="form-control" id="hcva-new-net-range" name="ip_range" placeholder="10.0.0.0/16" required>
</div>
<div class="hcva-form-hint">{$lang.net_create_hint|default:'Use a private range. Add a subnet afterwards before servers can join.'}</div>
