<input type="hidden" name="module_action" value="sshCreate">
<div class="hcva-form-group">
    <label for="hcva-new-ssh-name">{$lang.label_name|default:'Name'}</label>
    <input type="text" class="form-control" id="hcva-new-ssh-name" name="name" maxlength="128" required>
</div>
<div class="hcva-form-group hcva-form-group--wide">
    <label for="hcva-new-ssh-key">{$lang.label_public_key|default:'Public Key'}</label>
    <textarea class="form-control" id="hcva-new-ssh-key" name="public_key" rows="3" placeholder="ssh-ed25519 AAAA..." required></textarea>
</div>
