    <th>{$lang.col_name|default:'Name'}</th>
    <th>{$lang.col_fingerprint|default:'Fingerprint'}</th>
    <th>{$lang.col_created|default:'Created'}</th>
    <th>{$lang.col_action|default:'Action'}</th>
