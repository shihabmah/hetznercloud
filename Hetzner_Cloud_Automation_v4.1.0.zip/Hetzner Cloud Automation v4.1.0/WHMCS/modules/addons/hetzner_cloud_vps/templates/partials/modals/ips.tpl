{assign var=modalBase value="`$modulelink`&action=resources&account_id=`$selectedAccountId`&size=`$pageSize`&res=`$section`&page=`$page`"}

{if $section == 'floatingips'}
    {assign var=ipPrefix value='fip'}
    {assign var=ipField value='fip_id'}
{else}
    {assign var=ipPrefix value='pip'}
    {assign var=ipField value='pip_id'}
{/if}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-{$ipPrefix}-rename" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="{$ipPrefix}Rename">
                <input type="hidden" name="{$ipField}" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-{$ipPrefix}-rename-name">{$lang.label_name|default:'Name'}</label>
                    <input type="text" class="form-control" id="hcva-{$ipPrefix}-rename-name" name="name" data-hcva-fill="name" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-{$ipPrefix}-assign" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_assign_ip|default:'Assign'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="{$ipPrefix}Assign">
                <input type="hidden" name="{$ipField}" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-{$ipPrefix}-assign-server">{$lang.label_server|default:'Server'}</label>
                    <select class="form-control" id="hcva-{$ipPrefix}-assign-server" name="server_id" required>
                        <option value="">{$lang.select_server|default:'Select a server'}</option>
                        {foreach from=$servers item=server}
                            <option value="{$server.id}">{$server.name|escape} (#{$server.id})</option>
                        {/foreach}
                    </select>
                </div>
                {if $section == 'primaryips'}
                    <div class="hcva-form-hint">{$lang.pip_assign_hint|default:'The server must be powered off before its primary IP can change.'}</div>
                {/if}
                <button type="submit" class="btn btn-primary">{$lang.btn_assign_ip|default:'Assign'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-{$ipPrefix}-rdns" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rdns|default:'Reverse DNS'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="{$ipPrefix}Rdns">
                <input type="hidden" name="{$ipField}" data-hcva-fill="id" value="">
                <input type="hidden" name="ip" data-hcva-fill="ip" value="">
                <div class="hcva-form-group hcva-form-group--wide">
                    <label for="hcva-{$ipPrefix}-rdns-hostname">{$lang.label_hostname|default:'Hostname'}</label>
                    <input type="text" class="form-control" id="hcva-{$ipPrefix}-rdns-hostname" name="hostname" data-hcva-fill="hostname" maxlength="253">
                </div>
                <div class="hcva-form-hint">{$lang.rdns_hint|default:'Leave blank to clear the record. The forward DNS must already point back at this address.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-{$ipPrefix}-labels" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_label|default:'Add labels'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="{$ipPrefix}Labels">
                <input type="hidden" name="{$ipField}" data-hcva-fill="id" value="">
                <div class="hcva-form-group hcva-form-group--wide">
                    <label for="hcva-{$ipPrefix}-labels-value">{$lang.label_labels|default:'Labels'}</label>
                    <input type="text" class="form-control" id="hcva-{$ipPrefix}-labels-value" name="labels" data-hcva-fill="labels" placeholder="owner=support, tier=gold">
                </div>
                <div class="hcva-form-hint">{$lang.hint_labels|default:'Use key=value pairs separated by commas. Labels are notes at the provider and do not rename the resource.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>
