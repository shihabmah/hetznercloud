    <th>{$lang.col_name|default:'Name'}</th>
    <th>{$lang.col_rules|default:'Rules'}</th>
    <th>{$lang.col_applied_to|default:'Applied to'}</th>
    <th>{$lang.col_action|default:'Action'}</th>
