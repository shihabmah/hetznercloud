{assign var=modalBase value="`$modulelink`&action=resources&account_id=`$selectedAccountId`&size=`$pageSize`&res=`$section`&page=`$page`"}

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-net-rename" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_rename|default:'Rename'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="netRename">
                <input type="hidden" name="network_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-net-rename-name">{$lang.label_name|default:'Name'}</label>
                    <input type="text" class="form-control" id="hcva-net-rename-name" name="name" data-hcva-fill="name" maxlength="128" required>
                </div>
                <button type="submit" class="btn btn-primary">{$lang.btn_save|default:'Save'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-net-subnet" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_add_subnet|default:'Add Subnet'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="netSubnetAdd">
                <input type="hidden" name="network_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-net-subnet-range">{$lang.label_ip_range|default:'IP Range'}</label>
                    <input type="text" class="form-control" id="hcva-net-subnet-range" name="ip_range" placeholder="10.0.1.0/24" required>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-net-subnet-zone">{$lang.label_network_zone|default:'Network Zone'}</label>
                    <input type="text" class="form-control" id="hcva-net-subnet-zone" name="network_zone" placeholder="eu-central" required>
                </div>
                <div class="hcva-form-hint">{$lang.subnet_hint|default:'The subnet must sit inside the network range and the zone must match where your servers are.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_add_subnet|default:'Add Subnet'}</button>
            </form>
        </div>
    </div>
</div>

<div class="hcva-modal-overlay hcva-plain-modal" id="hcva-net-route" aria-hidden="true">
    <div class="hcva-modal-box">
        <div class="hcva-modal-header">
            <h4 class="hcva-modal-title">{$lang.btn_add_route|default:'Add Route'}</h4>
            <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
        </div>
        <div class="hcva-modal-body">
            <form method="post" action="{$modalBase}">
                <input type="hidden" name="csrf_token" value="{$csrfToken|escape}">
                <input type="hidden" name="module_action" value="netRouteAdd">
                <input type="hidden" name="network_id" data-hcva-fill="id" value="">
                <div class="hcva-form-group">
                    <label for="hcva-net-route-destination">{$lang.label_destination|default:'Destination'}</label>
                    <input type="text" class="form-control" id="hcva-net-route-destination" name="destination" placeholder="0.0.0.0/0" required>
                </div>
                <div class="hcva-form-group">
                    <label for="hcva-net-route-gateway">{$lang.label_gateway|default:'Gateway'}</label>
                    <input type="text" class="form-control" id="hcva-net-route-gateway" name="gateway" placeholder="10.0.1.1" required>
                </div>
                <div class="hcva-form-hint">{$lang.route_hint|default:'The gateway must be an address inside the network, and cannot be the first address of a subnet.'}</div>
                <button type="submit" class="btn btn-primary">{$lang.btn_add_route|default:'Add Route'}</button>
            </form>
        </div>
    </div>
</div>
