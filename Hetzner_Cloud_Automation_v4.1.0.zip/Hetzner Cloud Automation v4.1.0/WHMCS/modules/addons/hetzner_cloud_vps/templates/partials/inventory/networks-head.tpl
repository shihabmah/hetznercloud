    <th>{$lang.col_name|default:'Name'}</th>
    <th>{$lang.col_ip_range|default:'IP Range'}</th>
    <th>{$lang.col_subnets|default:'Subnets'}</th>
    <th>{$lang.col_servers|default:'Servers'}</th>
    <th>{$lang.col_protection|default:'Protection'}</th>
    <th>{$lang.col_action|default:'Action'}</th>
