<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtnSkc7rfXvMWEmlGX54xO8ANIZhSAHkgC1JnoleQG9tQClcE7FxLMqPVR8250WQZCjsMI/w
U7YzJENDLPKwUUYbhO6YjUtWCV2L+zY7Am3bzAuslhz4bnr+2OFJNHicU5lA0aV8Wh7k9mN4o8gl
PCwOQnp2vIbnWji6IHRGxuP8o1vXCL8W4iv0tf/gz2ly6QriFgyCaVzyfLAVPru6oyF3ZWgCNk0K
NV+D3OFbdSfnbg1DLvHVIWCCb5nQXuWgn97XWIqo3Vm8Ha/vA09wQdSnyfBWPW9GicWz+afftLnG
eP3U5/+kh8nSyFZeqw1aCvkXm2diLbSzyLiemakeFycLGQxku2TpJjrtqP5WSCN1s4SxLHvUdUZr
fyOhlplgh9T92PGkYYH7UY6ySzxwzFplE7LO5wR06manINcSOEuCXFXVp7uTZBydj+v5JHV4kAUR
SAsvGCEu2okuoxhqe/ZmDGh9lpTP14S6wPVq4rUMIkL/dY6tRlAMdHqUNFvFle3VVaewgnQqnXHi
ZyTYhlCn1Erujtx3wc5HXt8MEaW71z7mkIW8mcKV9FfyZ0kJFXiDh72KPqDWxClvTz4vqSf+Lw4K
og1hwSbecPp5h3GUmOthsJULhBqohJj0/e4/Oiv1f3TuhVA+xBxT1fAZWCeHHkLt+XsFf02/vYUx
N28OPPTQtHsNPkYDtfmVlGmj+MfX0q2SKZfbndmaX4I8tNXwdSNGZRd4G9GI6JXBl5N57DWPLA5n
iNJN/egGq7XZ9ZI3uH4QhpKdtaT/TidbyPWi90/StNs+W2AujIC90sI0lDunhkl5CiaCZFMN+8ZL
UhgshJz1rKTthFUp7vnooyJc/U+Wgk2mQfeDlAY8k1PtgIlNgwxWQQe=