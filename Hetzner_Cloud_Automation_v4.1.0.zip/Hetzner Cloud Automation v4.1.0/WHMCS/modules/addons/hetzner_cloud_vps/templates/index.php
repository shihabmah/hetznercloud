<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz4pk4yj7m5WA8CjR3Fto+ElZuLJPzGoYPouGAGTnInPqxqqJ6DUIBHzJqpmid89ym1SvHXN
bCaTa6sPS/TnkDivppi8212MLGKpn5rhiu2PpBVQLfslwY1YVstP1KzTzWUqKAojuzaN4P5v8/LV
Qulphf9MWkLRDwYBDEsMQug+gkh2Ogd9qfQL/aX4qPTj4sKQzdgpW9R4hEmCwniGlyBdB5angcrW
wZritwM4D2DJO9Xul3STYxZgClyGy5TLv/QPBJ8D/0X6J/ae0dfgTp7oaYTeZKSGK05fahprOB2a
aDu71s3Ttb2kyvk7O9XWTlPDa8GSc5Lp0/KBQwLq+O/YWP2UUojBtxE/CigShx7j2YNXc9+InxJM
8/2S6Adg5xkBZKbUnvzyZeTR2cYwk8e7ZY+l3n/JJl9Lk0i/RlWPFcBwNg1fceJmowA4hzwTzC9C
fF31gUkOVKPYPRxBmiHvuWum/QQ7HeR89HW+xzS+KJQOPllg5KcIPDXj1rUdeTaH09YOJY+KZoet
g6TSFlDa6hYvKIV9ooiuOHzdJSoTPzyAs3iSWnz3OmmGRCJApOGPt5W/rbAiq7CxW8dgSUYuJBz0
uSJ79n17iQpKFOPDmK3ijx6tdqtZTeWmbmxfsUUpHu0zBh5fYzEspysMgy/vGSzF1DwoImnS4o7N
8gV3fY5aNpPcqV64aa0tPtB4dISRXMGVRo71Gmur8+ijfFG067wvwwAMWPuH5D328xRp7OK3Lzvb
bmnIIWM5zLv8eUTQsHAc5E5ZKwxmbQ7SOhmto0LDK1ECiYKVwHoXovyEmjdGw32v7CILFWuiLZfm
v/F5Yek9tJKWTRLNFuCKJSCQ1OnxEuT7AW6Ou6JUkdG4jx/LUjToXDkscDeDD0==