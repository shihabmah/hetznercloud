<link rel="stylesheet" href="{$assetsUrl|escape}/css/admin.css?v={$assetsVersion}">
<div class="hcva-admin">
    <div class="hcva-header">
        <div class="hcva-header-brand">
            <span class="hcva-header-icon"><i class="fas fa-cloud" aria-hidden="true"></i></span>
            <span class="hcva-header-title">{$moduleTitle|escape}</span>
        </div>
        <a class="hcva-header-logo" href="{$moduleCompanyUrl|escape}" target="_blank" rel="noopener">
            <img src="{$moduleLogoUrl|escape}" alt="{$moduleCompany}">
        </a>
    </div>

    {include file=$navAndContentTemplate}

    <div class="hcva-footer">
        {$moduleTitle|escape} &middot; v{$moduleVersion} &middot; &copy; {$currentYear} - <a href="{$moduleCompanyUrl|escape}" target="_blank" rel="noopener">{$moduleCompany}</a>
    </div>
</div>

<div class="hcva-admin">
    <div class="hcva-modal-overlay" id="hcva-confirm-modal" aria-hidden="true">
        <div class="hcva-modal-box" role="dialog" aria-modal="true" aria-labelledby="hcva-confirm-title">
            <div class="hcva-modal-header">
                <span class="hcva-modal-icon"><i class="fas fa-question" aria-hidden="true"></i></span>
                <h4 class="hcva-modal-title hcva-confirm-title" id="hcva-confirm-title">{$lang.modal_confirm_title|default:'Please Confirm'}</h4>
                <button type="button" class="hcva-modal-close" data-hcva-dismiss aria-label="{$lang.modal_close|default:'Close'}">&times;</button>
            </div>
            <div class="hcva-modal-body">
                <p class="hcva-confirm-message">{$lang.modal_confirm_message|default:'Are you sure?'}</p>
            </div>
            <div class="hcva-modal-footer">
                <button type="button" class="btn btn-default" data-hcva-dismiss>
                    <i class="fas fa-times" aria-hidden="true"></i> {$lang.modal_cancel|default:'Cancel'}
                </button>
                <button type="button" class="btn btn-primary hcva-confirm-button">
                    <i class="fas fa-check" aria-hidden="true"></i> {$lang.modal_confirm|default:'Confirm'}
                </button>
            </div>
        </div>
    </div>
</div>

<script src="{$assetsUrl|escape}/js/admin.js?v={$assetsVersion}"></script>
<script>

document.addEventListener('DOMContentLoaded', function () {
    var moduleTitle = '{$moduleTitle|escape:'javascript'}';
    var heading = document.querySelector('h1');
    if (heading && heading.textContent.indexOf(moduleTitle) !== -1) {
        heading.style.display = 'none';
    }
});
</script>
