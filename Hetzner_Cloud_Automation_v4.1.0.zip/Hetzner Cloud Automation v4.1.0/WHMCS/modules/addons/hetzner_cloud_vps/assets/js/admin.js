document.addEventListener('DOMContentLoaded', function () {
    var modal = document.getElementById('hcva-confirm-modal');

    if (!modal) {
        return;
    }

    var titleEl = modal.querySelector('.hcva-confirm-title');
    var messageEl = modal.querySelector('.hcva-confirm-message');
    var confirmButton = modal.querySelector('.hcva-confirm-button');
    var pendingForm = null;

    function openModal(form) {
        pendingForm = form;

        titleEl.textContent = form.getAttribute('data-confirm-title') || 'Please Confirm';
        messageEl.textContent = form.getAttribute('data-confirm') || 'Are you sure?';
        confirmButton.className = 'btn hcva-confirm-button btn-' + (form.getAttribute('data-confirm-variant') || 'primary');

        modal.classList.add('hcva-modal-open');
        modal.setAttribute('aria-hidden', 'false');
        confirmButton.focus();
    }

    function closeModal() {
        modal.classList.remove('hcva-modal-open');
        modal.setAttribute('aria-hidden', 'true');
        pendingForm = null;
    }

    document.addEventListener('submit', function (event) {
        var form = event.target;

        if (!form || form.nodeName !== 'FORM' || !form.hasAttribute('data-confirm')) {
            return;
        }

        event.preventDefault();
        openModal(form);
    });

    confirmButton.addEventListener('click', function () {
        var formToSubmit = pendingForm;
        closeModal();

        if (!formToSubmit) {
            return;
        }

        if (typeof window.hcvaSubmitForm === 'function') {
            window.hcvaSubmitForm(formToSubmit);
        } else {
            formToSubmit.submit();
        }
    });

    var dismissButtons = modal.querySelectorAll('[data-hcva-dismiss]');

    for (var i = 0; i < dismissButtons.length; i++) {
        dismissButtons[i].addEventListener('click', closeModal);
    }

    modal.addEventListener('click', function (event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal.classList.contains('hcva-modal-open')) {
            closeModal();
        }
    });
});

document.addEventListener('DOMContentLoaded', function () {
    var container = document.getElementById('hcva-page-content');

    if (!container || typeof window.fetch !== 'function') {
        return;
    }

    var modulelink = container.getAttribute('data-modulelink') || '';

    if (!modulelink) {
        return;
    }

    function isInternalLink(link) {
        if (!link || link.target || link.hasAttribute('data-no-ajax')) {
            return false;
        }

        var href = link.getAttribute('href') || '';

        return href.indexOf(modulelink) === 0;
    }

    function setLoading(isLoading) {
        container.classList.toggle('hcva-loading', isLoading);
    }

    function swap(html, url, pushState) {
        var parsed = new DOMParser().parseFromString(html, 'text/html');
        var freshContent = parsed.getElementById('hcva-page-content');

        if (!freshContent) {
            throw new Error('AJAX response did not contain #hcva-page-content.');
        }

        container.innerHTML = freshContent.innerHTML;
        setLoading(false);

        container.classList.remove('hcva-fade-in');
        void container.offsetWidth;
        container.classList.add('hcva-fade-in');

        if (pushState) {
            window.history.pushState({ hcvaUrl: url }, '', url);
        }

        container.scrollIntoView({ block: 'nearest' });
    }

    function request(url, options, fallback) {
        setLoading(true);

        var settings = options || {};
        settings.credentials = 'same-origin';
        settings.headers = settings.headers || {};
        settings.headers['X-HCVA-Ajax'] = '1';

        return fetch(url, settings).then(function (response) {
            if (!response.ok) {
                throw new Error('Request failed with status ' + response.status);
            }

            return response.text();
        }).catch(function (error) {
            setLoading(false);
            fallback();
            throw error;
        });
    }

    function navigate(url, pushState) {
        request(url, {}, function () {
            window.location.href = url;
        }).then(function (html) {
            swap(html, url, pushState);
        }).catch(function () {
        });
    }

    function submitForm(form) {
        var method = (form.getAttribute('method') || 'get').toUpperCase();
        var action = form.getAttribute('action') || window.location.href;
        var data = new FormData(form);

        if (method !== 'POST') {
            var query = new URLSearchParams();
            data.forEach(function (value, key) {
                query.append(key, value);
            });
            navigate(action + (action.indexOf('?') === -1 ? '?' : '&') + query.toString(), true);
            return;
        }

        request(action, { method: 'POST', body: data }, function () {
            form.submit();
        }).then(function (html) {
            closeOpenModals();
            swap(html, action, false);
        }).catch(function () {
        });
    }

    function closeOpenModals() {
        var open = document.querySelectorAll('.hcva-modal-overlay.hcva-modal-open');

        for (var i = 0; i < open.length; i++) {
            open[i].classList.remove('hcva-modal-open');
            open[i].setAttribute('aria-hidden', 'true');
        }
    }

    window.hcvaSubmitForm = submitForm;

    document.addEventListener('click', function (event) {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
            return;
        }

        var link = event.target.closest ? event.target.closest('a') : null;

        if (!link || !container.contains(link) || !isInternalLink(link)) {
            return;
        }

        event.preventDefault();
        navigate(link.getAttribute('href'), true);
    });

    document.addEventListener('submit', function (event) {
        var form = event.target;

        if (event.defaultPrevented || !form || form.nodeName !== 'FORM') {
            return;
        }

        if (!container.contains(form) || form.hasAttribute('data-no-ajax') || form.hasAttribute('data-confirm')) {
            return;
        }

        event.preventDefault();
        submitForm(form);
    });

    document.addEventListener('change', function (event) {
        var field = event.target;

        if (!field || !field.matches || !field.matches('[data-hcva-autosubmit]')) {
            return;
        }

        var form = field.form;

        if (form && container.contains(form)) {
            submitForm(form);
        }
    });

    window.addEventListener('popstate', function (event) {
        var url = (event.state && event.state.hcvaUrl) || window.location.href;
        navigate(url, false);
    });
});

document.addEventListener('input', function (event) {
    var input = event.target;

    if (!input || !input.matches || !input.matches('[data-hcva-table-search]')) {
        return;
    }

    var table = document.getElementById(input.getAttribute('data-hcva-table-search'));

    if (!table) {
        return;
    }

    var rows = table.querySelectorAll('tbody > tr[data-hcva-row]');

    if (!rows.length) {
        return;
    }

    var query = input.value.trim().toLowerCase();
    var visibleCount = 0;

    rows.forEach(function (row) {
        var matches = query === '' || row.textContent.toLowerCase().indexOf(query) !== -1;
        row.style.display = matches ? '' : 'none';

        if (matches) {
            visibleCount++;
        }
    });

    var emptyRow = table.querySelector('.hcva-no-results');

    if (emptyRow) {
        emptyRow.classList.toggle('hcva-visible', visibleCount === 0 && query !== '');
    }
});

document.addEventListener('click', function (event) {
    var assignOpener = event.target.closest ? event.target.closest('.hcva-assign-open') : null;

    if (assignOpener) {
        var modal = document.getElementById('hcva-assign-modal');
        var serverIdField = document.getElementById('hcva-assign-server-id');
        var nameLabel = document.getElementById('hcva-assign-server-name');
        var clientSelect = document.getElementById('hcva-assign-client');
        var serviceSelect = document.getElementById('hcva-assign-service');

        if (modal && serverIdField && clientSelect && serviceSelect) {
            serverIdField.value = assignOpener.getAttribute('data-server-id') || '';

            if (nameLabel) {
                nameLabel.textContent = assignOpener.getAttribute('data-server-name') || '';
            }

            clientSelect.value = '';
            serviceSelect.innerHTML = '';
            serviceSelect.disabled = true;

            modal.classList.add('hcva-modal-open');
            modal.setAttribute('aria-hidden', 'false');
        }

        return;
    }

    var importer = event.target.closest ? event.target.closest('[data-hcva-import-type]') : null;

    if (importer) {
        var serverType = importer.getAttribute('data-hcva-import-type') || '';
        var serverTypeField = document.getElementById('hcva-import-server-type');
        var nameField = document.getElementById('hcva-import-name');
        var importModal = document.getElementById('hcva-import-modal');

        if (serverTypeField && nameField && importModal) {
            serverTypeField.value = serverType;
            nameField.value = serverType;
            importModal.classList.add('hcva-modal-open');
            importModal.setAttribute('aria-hidden', 'false');
        }

        return;
    }

    var rowEditor = event.target.closest ? event.target.closest('.hcva-inv-edit') : null;

    if (rowEditor) {
        var rowModal = document.getElementById(rowEditor.getAttribute('data-form'));

        if (rowModal) {
            rowModal.querySelectorAll('[data-hcva-fill]').forEach(function (field) {
                var key = field.getAttribute('data-hcva-fill');
                var value = rowEditor.getAttribute('data-' + key);
                field.value = value === null ? '' : value;
            });

            rowModal.classList.add('hcva-modal-open');
            rowModal.setAttribute('aria-hidden', 'false');
        }

        return;
    }

    var opener = event.target.closest ? event.target.closest('[data-hcva-modal-open]') : null;

    if (opener) {
        var targetModal = document.getElementById(opener.getAttribute('data-hcva-modal-open'));
        if (targetModal) {
            targetModal.classList.add('hcva-modal-open');
            targetModal.setAttribute('aria-hidden', 'false');
        }
        return;
    }

    var plainModal = event.target.closest ? event.target.closest('.hcva-plain-modal') : null;
    var dismiss = event.target.closest ? event.target.closest('[data-hcva-dismiss]') : null;

    if (plainModal && (dismiss || event.target === plainModal)) {
        plainModal.classList.remove('hcva-modal-open');
        plainModal.setAttribute('aria-hidden', 'true');
    }
});

document.addEventListener('change', function (event) {
    var select = event.target;

    if (!select || !select.matches || !select.matches('[data-hcva-plan-location]')) {
        return;
    }

    var modulelink = select.getAttribute('data-hcva-modulelink') || '';
    var accountId = select.getAttribute('data-hcva-account-id') || '';
    var targetSelect = document.getElementById(select.getAttribute('data-hcva-plan-target') || '');

    if (!modulelink || !targetSelect || typeof window.fetch !== 'function') {
        return;
    }

    var url = modulelink + '&action=planlist&account_id=' + encodeURIComponent(accountId) + '&location=' + encodeURIComponent(select.value);

    fetch(url, { credentials: 'same-origin' }).then(function (response) {
        return response.json();
    }).then(function (data) {
        if (!data || typeof data !== 'object' || !data.options) {
            return;
        }

        targetSelect.innerHTML = '';

        Object.keys(data.options).forEach(function (key) {
            var option = document.createElement('option');
            option.value = key;
            option.textContent = data.options[key];
            targetSelect.appendChild(option);
        });
    }).catch(function () {
    });
});

document.addEventListener('change', function (event) {
    var clientSelect = event.target;

    if (!clientSelect || clientSelect.id !== 'hcva-assign-client') {
        return;
    }

    var serviceSelect = document.getElementById('hcva-assign-service');

    if (!serviceSelect) {
        return;
    }

    var byClient = {};

    try {
        byClient = JSON.parse(clientSelect.getAttribute('data-hcva-assign-services') || '{}');
    } catch (e) {
        byClient = {};
    }

    var services = byClient[clientSelect.value] || [];
    serviceSelect.innerHTML = '';

    if (!services.length) {
        var none = document.createElement('option');
        none.value = '';
        none.textContent = clientSelect.getAttribute('data-hcva-no-services') || '';
        serviceSelect.appendChild(none);
        serviceSelect.disabled = true;
        return;
    }

    services.forEach(function (service) {
        var option = document.createElement('option');
        option.value = service.id;
        option.textContent = service.label;
        serviceSelect.appendChild(option);
    });

    serviceSelect.disabled = false;
});

(function () {
    var COLUMN_HINTS = {
        'monthly (net)': 'Price before VAT, exactly as the provider charges it. Your own price is this plus the markup on the product.',
        'included traffic': 'Outbound traffic included in the plan each month. Anything beyond it is charged per TB.',
        'extra traffic (net/tb)': 'What the provider charges per terabyte once the included allowance is used up.',
        'health': 'Whether the load balancer can currently reach this target on its health check port.',
        'used by': 'The resources currently referencing this item. It cannot be deleted while anything still uses it.',
        'via': 'Which network interface the load balancer uses to reach the target: the public address, or the private network.',
        'api token': 'Stored encrypted and shown masked. Paste a new one to replace it; leaving the field blank keeps the current token.',
        'last synced': 'When the plan and pricing were last read from the provider. Save the product to refresh it.',
        'markup': 'Percentage added to the provider price when pricing is written to the product.',
        'services': 'Live services on this product. Cancelled and fraud services are not counted.',
        'published': 'A published snapshot appears in the rebuild picker for every service on this Project.'
    };

    function bubble(text) {
        var hint = document.createElement('span');
        hint.className = 'hcva-hint';
        hint.setAttribute('tabindex', '0');
        hint.setAttribute('role', 'note');
        hint.setAttribute('aria-label', text);
        var icon = document.createElement('i');
        icon.className = 'fas fa-info-circle';
        icon.setAttribute('aria-hidden', 'true');
        hint.appendChild(icon);

        var tip = document.createElement('span');
        tip.className = 'hcva-bubble';
        tip.textContent = text;
        hint.appendChild(tip);

        return hint;
    }

    function moveInto(target, source) {
        if (!target || !source || target.dataset.hcvaHint === '1') {
            return;
        }

        var text = source.textContent.trim();

        if (text.length < 4) {
            return;
        }

        target.dataset.hcvaHint = '1';
        target.appendChild(bubble(text));
        source.remove();
    }

    function run() {
        document.querySelectorAll('.hcva-form-group').forEach(function (group) {
            moveInto(group.querySelector('label'), group.querySelector('.hcva-form-hint'));
        });

        document.querySelectorAll('.panel').forEach(function (panel) {
            var title = panel.querySelector('.panel-title');
            var note = panel.querySelector('.hcva-rate-note');

            if (title && note && note.closest('.panel') === panel) {
                moveInto(title, note);
            }
        });

        document.querySelectorAll('th').forEach(function (cell) {
            if (cell.dataset.hcvaHint === '1') {
                return;
            }

            var text = COLUMN_HINTS[cell.textContent.trim().toLowerCase()];

            if (text) {
                cell.dataset.hcvaHint = '1';
                cell.appendChild(bubble(text));
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }

    document.addEventListener('hcva:content', run);
})();

(function () {
    function parts(root) {
        return {
            source: root.querySelector('[data-hcva-token-source]'),
            input: root.querySelector('[data-hcva-token-input]'),
            menu: root.querySelector('[data-hcva-token-menu]'),
            list: root.querySelector('[data-hcva-token-list]')
        };
    }

    function renderTokens(root) {
        var el = parts(root);

        if (!el.source || !el.list) {
            return;
        }

        el.list.innerHTML = '';

        Array.prototype.forEach.call(el.source.options, function (option) {
            if (!option.selected) {
                return;
            }

            var token = document.createElement('span');
            token.className = 'hcva-token';

            var text = document.createElement('span');
            text.textContent = option.textContent;

            var remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'hcva-token-remove';
            remove.setAttribute('data-hcva-token-remove', option.value);
            remove.setAttribute('aria-label', 'Remove ' + option.textContent);
            remove.innerHTML = '&times;';

            token.appendChild(text);
            token.appendChild(remove);
            el.list.appendChild(token);
        });
    }

    function renderMenu(root, open) {
        var el = parts(root);

        if (!el.source || !el.menu) {
            return;
        }

        if (!open) {
            el.menu.hidden = true;
            el.menu.innerHTML = '';
            return;
        }

        var needle = (el.input.value || '').trim().toLowerCase();
        var matches = Array.prototype.filter.call(el.source.options, function (option) {
            return !option.selected && option.textContent.toLowerCase().indexOf(needle) !== -1;
        });

        el.menu.innerHTML = '';
        el.menu.hidden = false;

        if (!matches.length) {
            var empty = document.createElement('div');
            empty.className = 'hcva-token-empty';
            empty.textContent = needle === '' ? 'Everything is already added' : 'No match';
            el.menu.appendChild(empty);
            return;
        }

        matches.forEach(function (option, index) {
            var row = document.createElement('div');
            row.className = 'hcva-token-option';
            row.setAttribute('data-hcva-token-add', option.value);
            row.textContent = option.textContent;

            if (index === 0) {
                row.setAttribute('data-hcva-token-active', '1');
            }

            el.menu.appendChild(row);
        });
    }

    function setSelected(root, value, selected) {
        var el = parts(root);

        Array.prototype.forEach.call(el.source.options, function (option) {
            if (option.value === value) {
                option.selected = selected;
            }
        });

        renderTokens(root);
    }

    function build(root) {
        if (root.hasAttribute('data-hcva-tokens-ready')) {
            return;
        }

        var source = root.querySelector('[data-hcva-token-source]');

        if (!source) {
            return;
        }

        var input = document.createElement('input');
        input.type = 'text';
        input.className = 'hcva-token-input';
        input.autocomplete = 'off';
        input.setAttribute('data-hcva-token-input', '1');
        input.setAttribute('placeholder', root.getAttribute('data-hcva-token-placeholder') || '');

        if (source.id) {
            input.setAttribute('aria-labelledby', source.id + '-label');
        }

        var menu = document.createElement('div');
        menu.className = 'hcva-token-menu';
        menu.setAttribute('data-hcva-token-menu', '1');
        menu.hidden = true;

        var list = document.createElement('div');
        list.className = 'hcva-token-list';
        list.setAttribute('data-hcva-token-list', '1');

        root.appendChild(input);
        root.appendChild(menu);
        root.appendChild(list);
        root.setAttribute('data-hcva-tokens-ready', '1');

        renderTokens(root);
    }

    function run() {
        document.querySelectorAll('[data-hcva-tokens]').forEach(build);
    }

    document.addEventListener('click', function (event) {
        var root = event.target.closest ? event.target.closest('[data-hcva-tokens]') : null;

        document.querySelectorAll('[data-hcva-tokens]').forEach(function (other) {
            if (other !== root) {
                renderMenu(other, false);
            }
        });

        if (!root) {
            return;
        }

        var remove = event.target.closest('[data-hcva-token-remove]');

        if (remove) {
            setSelected(root, remove.getAttribute('data-hcva-token-remove'), false);
            renderMenu(root, false);
            return;
        }

        var add = event.target.closest('[data-hcva-token-add]');

        if (add) {
            setSelected(root, add.getAttribute('data-hcva-token-add'), true);
            parts(root).input.value = '';
            renderMenu(root, true);
            parts(root).input.focus();
            return;
        }

        if (event.target.closest('[data-hcva-token-input]')) {
            renderMenu(root, true);
        }
    });

    document.addEventListener('input', function (event) {
        var root = event.target.closest ? event.target.closest('[data-hcva-tokens]') : null;

        if (root && event.target.matches('[data-hcva-token-input]')) {
            renderMenu(root, true);
        }
    });

    document.addEventListener('keydown', function (event) {
        var root = event.target.closest ? event.target.closest('[data-hcva-tokens]') : null;

        if (!root || !event.target.matches('[data-hcva-token-input]')) {
            return;
        }

        var el = parts(root);

        if (event.key === 'Escape') {
            renderMenu(root, false);
            return;
        }

        if (event.key === 'Backspace' && el.input.value === '') {
            var chosen = Array.prototype.filter.call(el.source.options, function (option) {
                return option.selected;
            });

            if (chosen.length) {
                setSelected(root, chosen[chosen.length - 1].value, false);
            }

            return;
        }

        if (event.key !== 'Enter') {
            return;
        }

        var active = el.menu.querySelector('[data-hcva-token-add]');

        if (!active) {
            return;
        }

        event.preventDefault();
        setSelected(root, active.getAttribute('data-hcva-token-add'), true);
        el.input.value = '';
        renderMenu(root, true);
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }

    document.addEventListener('hcva:content', run);
})();

(function () {
    var current = null;

    function place(hint) {
        var tip = hint.querySelector('.hcva-bubble');

        if (!tip) {
            return;
        }

        current = hint;
        tip.removeAttribute('data-hcva-bubble-below');
        tip.style.left = '0px';
        tip.style.top = '0px';

        var anchor = hint.getBoundingClientRect();
        var width = tip.offsetWidth;
        var height = tip.offsetHeight;
        var edge = 8;
        var left = anchor.left + (anchor.width / 2) - (width / 2);

        if (left < edge) {
            left = edge;
        }

        if (left + width > window.innerWidth - edge) {
            left = Math.max(edge, window.innerWidth - edge - width);
        }

        var top = anchor.top - height - 9;

        if (top < edge) {
            top = anchor.bottom + 9;
            tip.setAttribute('data-hcva-bubble-below', '1');
        }

        tip.style.left = left + 'px';
        tip.style.top = top + 'px';
        tip.style.setProperty('--hcva-arrow', (anchor.left + (anchor.width / 2) - left) + 'px');
    }

    function hintFrom(event) {
        return event.target && event.target.closest ? event.target.closest('.hcva-hint') : null;
    }

    document.addEventListener('mouseover', function (event) {
        var hint = hintFrom(event);

        if (hint) {
            place(hint);
        }
    });

    document.addEventListener('focusin', function (event) {
        var hint = hintFrom(event);

        if (hint) {
            place(hint);
        }
    });

    document.addEventListener('mouseout', function (event) {
        if (hintFrom(event) === current) {
            current = null;
        }
    });

    document.addEventListener('focusout', function (event) {
        if (hintFrom(event) === current) {
            current = null;
        }
    });

    window.addEventListener('scroll', function () {
        if (current && current.isConnected) {
            place(current);
        }
    }, true);

    window.addEventListener('resize', function () {
        if (current && current.isConnected) {
            place(current);
        }
    });
})();
