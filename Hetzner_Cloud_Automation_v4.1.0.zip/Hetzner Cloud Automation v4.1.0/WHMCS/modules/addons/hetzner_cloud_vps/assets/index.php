<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqmVpAwaupI1iQzPZIR8rMwjcX3a2vPp8xkuWDgxMbIOeYPKrcAEsSwVuOtLCBuGQQRGIrzx
0YH/n+vWNThOLQHPjhlEEoaky3MzEI929yjpU8vlvoXLr9wt1/mzaFqKYwibtGm51jmUkmVlH3/y
5DXsX9LjfHvGrTIE6Sg1ncSOd9/TMyU6Cv4uYFxMidCnT9/A2rn3mRkkmTFVcxYmq30XGzeAEeVT
FO2tik10I4ox04I66ZCP7RIBIBjdVUw5J/enBJ8D/0X6J/ae0dfgTp7oaWLet2YGhIdZmNI+5B2a
V+nQ/sTYhUIVUPZnvXA8Je51+UfQOpGwU4rseojW3J3AZZUTr/5AoM/cAOcjHYTYzyqstt/HMqzy
uwBTaK4GmrnXnCuKCiEfQwq7Mh7N3mHIvIBrX9ZNr0CRvddy8JjsQy3BUwVX1z73W97JsVIsP5gj
kP688K4E7NmdzWeVV8nj01gDqVtUE5GgS4HtvjgleELo2jskehX1dR5onB7lrSNAlhX5kVb04Fgd
IYc+hitaqo0BKepgICDnjSr9nSQOJhzYSz7VE+Lzp/uV+or7jMzxFtJ80N5UX8Qrgyf2OBLYN5NJ
m6K8ZNf2VUwiH7ibOCRNNKVvCwa5BlY6jX0FCa1CqtWDEhJwIs75wHy3zPq9vfYvQfwWnH/IVKdV
jLaH3CIZrTX3JVqW349R1XKQrgnH7BOzJwgZpSryM8iti5wPwmQM4Tt3nsd2hoYEsBqh++gLuNmK
oJXgsA6sxJ1o2otovCfjGZRUuZVilQvDIhlsfAmOvdd0fW7GxKUizAZ9X5qFtBIFsqtKGmSg9/gd
DbkqiikXZEu6UQXNGdE5L6O+1BfVK6vptyfyQ4UB+PTQ3O3O6BxwuGcs