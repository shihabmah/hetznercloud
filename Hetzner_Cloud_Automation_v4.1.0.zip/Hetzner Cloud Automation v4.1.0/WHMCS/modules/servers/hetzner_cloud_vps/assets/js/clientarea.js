(function () {
    'use strict';

    var ROOT = null;
    var ENDPOINT = '';
    var CSRF = '';
    var ASSETS = '/modules/servers/hetzner_cloud_vps/assets/';
    var IS_ADMIN = false;

    var POLL_INTERVAL_MS = 25000;
    var POST_ACTION_POLL_MS = 3000;
    var pollTimer = null;

    var trafficCanvas = null;
    var trafficChartData = null;
    var trafficResizeObserverAttached = false;
    var lastChartWidth = 0;
    var chartFrame = null;
    var trafficHitAreas = [];
    var currentRange = 'today';
    var currentMetric = 'network';
    var liveTimer = null;

    var selectedReinstallImage = null;
    var reinstallRebuildProtected = false;
    var selectedReinstallLabel = '';
    var lastReinstallImages = [];
    var recoveryPage = 1;
    var firewallRuleRows = [];
    var currentPassword = '';
    var passwordVisible = false;
    var currentServerName = '';
    var rescueEnabled = false;
    var rescuePassword = '';
    var backupsEnabled = false;

    function qs(selector, scope) {
        return (scope || document).querySelector(selector);
    }

    function qsa(selector, scope) {
        return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
    }

    function t(key, fallback) {
        return fallback;
    }

    function setHidden(el, hidden) {
        if (!el) {
            return;
        }
        if (hidden) {
            el.setAttribute('hidden', '');
        } else {
            el.removeAttribute('hidden');
        }
    }

    function api(vpsact, data) {
        var body = new URLSearchParams();
        body.set('vpsact', vpsact);
        Object.keys(data || {}).forEach(function (key) {
            body.set(key, data[key]);
        });
        body.set('hcv_csrf', CSRF);

        return fetch(ENDPOINT, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: body.toString()
        }).then(function (response) {
            return response.text().then(function (text) {
                return { status: response.status, ok: response.ok, text: text };
            });
        }).then(function (result) {
            try {
                return JSON.parse(result.text);
            } catch (e) {
                var err = new Error('unreadable-response');
                err.httpStatus = result.status;
                throw err;
            }
        });
    }

    function fatal(message) {
        var box = qs('#hcv-fatal');
        var target = qs('#hcv-fatal-message');

        if (!box || !target) {
            return;
        }

        target.textContent = message;
        setHidden(box, false);
    }

    function describeFailure(error) {
        if (!error || error.message !== 'unreadable-response') {
            return t('err_unreachable', 'The server did not respond. Check your connection and reload the page.');
        }

        if (error.httpStatus === 403 || error.httpStatus === 401) {
            return t('err_forbidden', 'The request was rejected. Sign out and back in, then reload this page.');
        }

        if (error.httpStatus === 404) {
            return t('err_notfound', 'The dashboard endpoint was not found at this address.');
        }

        return t('err_badresponse', 'The server returned an unexpected response instead of dashboard data.')
            + ' (HTTP ' + (error.httpStatus || '?') + ')';
    }

    function toast(message, variant) {
        var container = qs('#hcv-toasts');
        if (!container) {
            return;
        }
        var el = document.createElement('div');
        el.className = 'hcv-toast hcv-toast-' + (variant || 'success');
        el.textContent = message;
        container.appendChild(el);
        setTimeout(function () {
            el.classList.add('hcv-toast-out');
            setTimeout(function () {
                el.remove();
            }, 300);
        }, 5000);
    }

    function busy(btn, isBusy) {
        if (!btn) {
            return;
        }
        btn.disabled = isBusy;
        btn.classList.toggle('hcv-btn-busy', isBusy);
    }

    function emptyRow(colspan, text) {
        var tr = document.createElement('tr');
        var td = document.createElement('td');
        td.colSpan = colspan;
        td.className = 'hcv-empty-row';
        td.textContent = text;
        tr.appendChild(td);
        return tr;
    }

    function smallBtn(label, className, onClick, iconClass, iconOnly) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'hcv-btn hcv-btn-sm' + (iconOnly ? ' hcv-btn-icon' : '') + (className ? ' ' + className : '');
        btn.title = label;
        var icon = document.createElement('i');
        icon.className = iconClass || 'fas fa-circle';
        icon.setAttribute('aria-hidden', 'true');
        var span = document.createElement('span');
        span.textContent = label;
        btn.appendChild(icon);
        btn.appendChild(span);
        btn.addEventListener('click', onClick);
        return btn;
    }

    function pagerButton(label, disabled, onClick) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'hcv-btn hcv-btn-sm';
        btn.textContent = label;
        btn.disabled = disabled;
        btn.addEventListener('click', onClick);
        return btn;
    }

    function mountTable(config) {
        var tbody = qs(config.body);

        if (!tbody) {
            return;
        }

        var perPage = config.perPage || 10;
        var rows = config.rows || [];
        var page = 1;
        var query = '';

        function matches(row) {
            if (query === '') {
                return true;
            }
            return String(config.search ? config.search(row) : '').toLowerCase().indexOf(query) !== -1;
        }

        function draw() {
            var visible = rows.filter(matches);
            var totalPages = Math.max(1, Math.ceil(visible.length / perPage));
            page = Math.min(page, totalPages);

            tbody.innerHTML = '';

            if (!visible.length) {
                tbody.appendChild(emptyRow(config.columns, query === ''
                    ? config.emptyText
                    : t('no_search_results', 'No rows match your search.')));
            } else {
                visible.slice((page - 1) * perPage, page * perPage).forEach(function (row) {
                    tbody.appendChild(config.render(row));
                });
            }

            var pager = qs(config.pager);
            if (pager) {
                setHidden(pager, false);
                renderPager(config.pager, page, totalPages, function (next) {
                    page = next;
                    draw();
                }, visible.length, perPage);
            }

            var toolbar = qs(config.searchWrap);
            if (toolbar) {
                setHidden(toolbar, false);
            }
        }

        var input = qs(config.searchInput);
        if (input) {
            input.oninput = function () {
                query = input.value.trim().toLowerCase();
                page = 1;
                draw();
            };
            query = input.value.trim().toLowerCase();
        }

        draw();
    }

    function pagerSummary(page, totalPages, total, perPage) {
        var size = Number(perPage) || 0;
        var entries = Number(total);

        if (!size || !isFinite(entries) || entries <= 0) {
            return page + ' / ' + totalPages;
        }

        var values = [
            ((page - 1) * size) + 1,
            Math.min(page * size, entries),
            entries,
            page,
            totalPages
        ];

        return String(t('pager_summary', '%1$s-%2$s of %3$s — page %4$s of %5$s'))
            .replace(/%(\d+)\$s/g, function (match, index) { return values[index - 1]; });
    }

    function renderPager(selector, page, totalPages, loader, total, perPage) {
        var container = qs(selector);
        if (!container) {
            return;
        }
        container.innerHTML = '';
        container.appendChild(pagerButton(t('pager_first', 'First'), page <= 1, function () { loader(1); }));
        container.appendChild(pagerButton(t('pager_prev', 'Prev'), page <= 1, function () { loader(page - 1); }));
        var indicator = document.createElement('span');
        indicator.className = 'hcv-pager-indicator';
        indicator.textContent = pagerSummary(page, totalPages, total, perPage);
        container.appendChild(indicator);
        container.appendChild(pagerButton(t('pager_next', 'Next'), page >= totalPages, function () { loader(page + 1); }));
        container.appendChild(pagerButton(t('pager_last', 'Last'), page >= totalPages, function () { loader(totalPages); }));
    }

    function formatBytes(bytes) {
        var units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
        var value = Number(bytes) || 0;
        var i = 0;
        while (value >= 1024 && i < units.length - 1) {
            value = value / 1024;
            i++;
        }
        return value.toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
    }

    function iconKey(name) {
        return String(name || '').split(/[\s-]+/)[0].toLowerCase().replace(/[^a-z0-9]/g, '');
    }

    function iconChain(name) {
        var key = iconKey(name) || 'os';
        return [
            ASSETS + 'images/' + key + '.svg',
            ASSETS + 'images/os.svg'
        ];
    }

    function attachIconChain(img, candidates) {
        var idx = 0;
        var fallback = img.nextElementSibling && img.nextElementSibling.classList.contains('hcv-icon-fallback')
            ? img.nextElementSibling
            : null;

        function tryNext() {
            if (idx >= candidates.length) {
                setHidden(img, true);
                setHidden(fallback, false);
                return;
            }
            img.src = candidates[idx++];
        }

        img.onerror = tryNext;
        setHidden(img, false);
        setHidden(fallback, true);
        tryNext();
    }

    function promptDialog(opts) {
        return new Promise(function (resolve) {
            var modal = qs('#hcv-prompt-modal');

            if (!modal) {
                resolve(null);
                return;
            }

            setText('#hcv-prompt-title', opts.title || '');
            setText('#hcv-prompt-message', opts.message || '');

            var hint = qs('#hcv-prompt-hint');
            setText('#hcv-prompt-hint', opts.hint || '');
            setHidden(hint, !opts.hint);

            var wrap = qs('#hcv-prompt-fields');
            wrap.innerHTML = '';

            var inputs = {};

            (opts.fields || []).forEach(function (field) {
                var group = document.createElement('div');
                group.className = 'hcv-prompt-field';

                var label = document.createElement('label');
                label.className = 'hcv-detail-label';
                label.textContent = field.label;
                group.appendChild(label);

                var input = document.createElement('input');
                input.type = field.type || 'text';
                input.className = 'hcv-input';
                input.value = field.value === undefined ? '' : String(field.value);

                if (field.placeholder) {
                    input.placeholder = field.placeholder;
                }

                if (field.min !== undefined) {
                    input.min = String(field.min);
                }

                if (field.max !== undefined) {
                    input.max = String(field.max);
                }

                group.appendChild(input);
                wrap.appendChild(group);
                inputs[field.name] = input;
            });

            setHidden(modal, false);
            modal.setAttribute('aria-hidden', 'false');

            var first = wrap.querySelector('input');
            if (first) {
                first.focus();
                first.select();
            }

            function close(value) {
                setHidden(modal, true);
                modal.setAttribute('aria-hidden', 'true');
                resolve(value);
            }

            qsa('.hcv-prompt-cancel', modal).forEach(function (btn) {
                btn.onclick = function () { close(null); };
            });

            qs('.hcv-prompt-submit', modal).onclick = function () {
                var out = {};
                var name;

                for (name in inputs) {
                    if (Object.prototype.hasOwnProperty.call(inputs, name)) {
                        out[name] = inputs[name].value.trim();
                    }
                }

                close(out);
            };
        });
    }

    function resourceActionsDialog(kind, resourceId, title) {
        instructionsDialog({
            title: title,
            intro: t('actions_loading', 'Reading the action history…'),
            steps: []
        });

        api('resourceActions', { resourceKind: kind, resourceId: resourceId }).then(function (res) {
            var steps = qs('#hcv-instructions-steps');

            if (!steps) {
                return;
            }

            if (res.status !== 'success') {
                setText('#hcv-instructions-intro', res.message || t('err_generic', 'Something went wrong.'));
                return;
            }

            var rows = res.data.rows || [];
            setText('#hcv-instructions-intro', rows.length
                ? t('actions_intro', 'What the provider has done to this resource, newest last.')
                : t('actions_empty', 'The provider has no recorded actions for this resource.'));

            steps.innerHTML = '';

            rows.forEach(function (row) {
                var block = document.createElement('div');
                block.className = 'hcv-instruction-step';

                var label = document.createElement('span');
                label.className = 'hcv-detail-label';
                label.textContent = row.command + ' — ' + row.status;
                block.appendChild(label);

                var detail = document.createElement('div');
                detail.className = 'hcv-meta';
                detail.textContent = (row.started || '') + (row.finished ? ' → ' + row.finished : '')
                    + (row.error ? ' — ' + row.error : '');
                block.appendChild(detail);

                steps.appendChild(block);
            });
        }).catch(function () {
            setText('#hcv-instructions-intro', t('err_network', 'Network error.'));
        });
    }

    function instructionsDialog(opts) {
        var modal = qs('#hcv-instructions-modal');

        if (!modal) {
            return;
        }

        setText('#hcv-instructions-title', opts.title || t('instructions_title', 'Configure this resource'));
        setText('#hcv-instructions-intro', opts.intro || '');

        var steps = qs('#hcv-instructions-steps');
        steps.innerHTML = '';

        (opts.steps || []).forEach(function (step) {
            var block = document.createElement('div');
            block.className = 'hcv-instruction-step';

            var label = document.createElement('span');
            label.className = 'hcv-detail-label';
            label.textContent = step.label;
            block.appendChild(label);

            var row = document.createElement('div');
            row.className = 'hcv-instruction-command';

            var code = document.createElement('code');
            code.textContent = step.command;
            row.appendChild(code);

            row.appendChild(smallBtn(t('btn_copy', 'Copy'), '', function () {
                copyText(step.command);
            }, 'fas fa-copy', true));

            block.appendChild(row);
            steps.appendChild(block);
        });

        var footnote = qs('#hcv-instructions-footnote');
        setText('#hcv-instructions-footnote', opts.footnote || '');
        setHidden(footnote, !opts.footnote);

        setHidden(modal, false);
        modal.setAttribute('aria-hidden', 'false');

        qsa('.hcv-instructions-close', modal).forEach(function (btn) {
            btn.onclick = function () {
                setHidden(modal, true);
                modal.setAttribute('aria-hidden', 'true');
            };
        });
    }

    function floatingIpInstructions(row) {
        var address = row.kind === 'network' ? (row.suggestion || row.ip) : row.ip;

        instructionsDialog({
            title: t('instructions_floatingip_title', 'Configure Floating IP'),
            intro: t('instructions_floatingip_intro', 'The floating IP is assigned. Add it inside the server for it to work.'),
            steps: [{
                label: t('instructions_temporary', 'Command for temporary configuration'),
                command: 'sudo ip addr add ' + address + ' dev eth0'
            }],
            footnote: t('instructions_floatingip_note', 'A temporary configuration lasts until the next reboot. Make it permanent in the network configuration of your operating system.')
        });
    }

    function volumeInstructions(row) {
        var device = row.linuxDevice || ('/dev/disk/by-id/scsi-0HC_Volume_' + row.id);
        var mount = row.mountPoint || ('/mnt/' + (row.name || 'volume'));

        instructionsDialog({
            title: t('instructions_volume_title', 'Configure volume'),
            intro: t('instructions_volume_intro', 'To configure your volume, run the following on the server as a privileged user.'),
            steps: [
                { label: t('instructions_format', 'Format volume'), command: 'mkfs.' + (row.format || 'xfs') + ' -f ' + device },
                { label: t('instructions_mkdir', 'Create directory'), command: 'mkdir ' + mount },
                { label: t('instructions_mount', 'Mount volume'), command: 'mount -o discard,defaults ' + device + ' ' + mount },
                { label: t('instructions_fstab', 'Optional: add volume to fstab'), command: 'echo "' + device + ' ' + mount + ' ' + (row.format || 'xfs') + ' discard,nofail,defaults 0 0" >> /etc/fstab' }
            ],
            footnote: t('instructions_volume_note', 'Formatting erases everything already on the volume. Only format a volume the first time you attach it.')
        });
    }

    function confirmDialog(opts) {
        return new Promise(function (resolve) {
            var modal = qs('#hcv-confirm-modal');
            qs('.hcv-confirm-title', modal).textContent = opts.title || t('confirm_title', 'Please Confirm');
            qs('.hcv-confirm-message', modal).textContent = opts.message || t('confirm_message', 'Are you sure?');
            var confirmBtn = qs('.hcv-confirm-confirm', modal);
            var cancelBtns = qsa('.hcv-confirm-cancel', modal);
            var variant = opts.variant || 'primary';
            confirmBtn.className = 'hcv-btn hcv-confirm-confirm hcv-btn-' + variant;

            var box = qs('.hcv-modal-box', modal);
            if (box) {
                box.className = 'hcv-modal-box hcv-modal-' + variant;
            }

            var circle = qs('.hcv-modal-icon-circle', modal);
            if (circle) {
                circle.className = 'hcv-modal-icon-circle hcv-modal-icon-' + variant;
                var glyph = qs('i', circle);
                if (glyph) {
                    glyph.className = 'fas ' + (variant === 'danger'
                        ? 'fa-exclamation-triangle'
                        : (variant === 'success' ? 'fa-check' : 'fa-question'));
                }
            }

            setText('#hcv-confirm-eyebrow', opts.eyebrow || (variant === 'danger'
                ? t('modal_eyebrow_danger', 'This cannot be undone')
                : t('modal_eyebrow_confirm', 'Confirm this action')));

            var callout = qs('#hcv-confirm-callout');
            setHidden(callout, !opts.callout);
            if (opts.callout) {
                setText('#hcv-confirm-callout-text', opts.callout);
            }

            var confirmLabel = qs('span', confirmBtn);
            if (confirmLabel) {
                confirmLabel.textContent = opts.confirmLabel || t('modal_confirm', 'Confirm');
            }

            function cleanup(result) {
                setHidden(modal, true);
                confirmBtn.removeEventListener('click', onConfirm);
                cancelBtns.forEach(function (button) {
                    button.removeEventListener('click', onCancel);
                });
                modal.removeEventListener('click', onBackdrop);
                document.removeEventListener('keydown', onKey);
                resolve(result);
            }

            function onConfirm() { cleanup(true); }
            function onCancel() { cleanup(false); }

            function onBackdrop(event) {
                if (event.target === modal) {
                    cleanup(false);
                }
            }

            function onKey(event) {
                if (event.key === 'Escape') {
                    cleanup(false);
                }
            }

            confirmBtn.addEventListener('click', onConfirm);
            cancelBtns.forEach(function (button) {
                button.addEventListener('click', onCancel);
            });
            modal.addEventListener('click', onBackdrop);
            document.addEventListener('keydown', onKey);
            setHidden(modal, false);
            confirmBtn.focus();
        });
    }

    function bindConfirmedAction(selector, vpsact, message, variant) {
        var btn = qs(selector);
        if (!btn) {
            return;
        }
        btn.addEventListener('click', function () {
            confirmDialog({ message: message, variant: variant }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(btn, true);
                api(vpsact).then(function (res) {
                    busy(btn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    pokeAfterAction();
                }).catch(function () {
                    busy(btn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        });
    }

    function setConsoleState(connected) {
        setHidden(qs('#hcv-console-connect'), connected);
        setHidden(qs('#hcv-console-reconnect'), !connected);
        setHidden(qs('#hcv-console-disconnect'), !connected);
        setHidden(qs('#hcv-console-frame'), !connected);
        setHidden(qs('#hcv-console-placeholder'), connected);
    }

    function openConsole(token) {
        var frame = qs('#hcv-console-frame');
        if (!frame) {
            return;
        }
        var sep = ENDPOINT.indexOf('?') === -1 ? '?' : '&';
        frame.src = ENDPOINT + sep + 'vpsact=consoleview&token=' + encodeURIComponent(token);
        setConsoleState(true);
    }

    function closeConsole() {
        var frame = qs('#hcv-console-frame');
        if (frame) {
            frame.src = 'about:blank';
        }
        setConsoleState(false);
    }

    function requestConsole(btn) {
        return confirmDialog({
            title: t('confirm_console_title', 'Open Console'),
            message: t('confirm_console_message', 'Open a live remote console session to this server?'),
            variant: 'primary'
        }).then(function (ok) {
            if (!ok) {
                return;
            }
            busy(btn, true);
            closeConsole();

            return api('consoleRequest').then(function (res) {
                busy(btn, false);
                if (res.status !== 'success' || !res.data || !res.data.token) {
                    toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                    return;
                }
                openConsole(res.data.token);
            }).catch(function () {
                busy(btn, false);
                toast(t('err_network', 'Network error.'), 'error');
            });
        });
    }

    function wireConsole() {
        var connectBtn = qs('#hcv-console-connect');
        var reconnectBtn = qs('#hcv-console-reconnect');
        var disconnectBtn = qs('#hcv-console-disconnect');

        if (connectBtn) {
            connectBtn.addEventListener('click', function () {
                requestConsole(connectBtn);
            });
        }
        if (reconnectBtn) {
            reconnectBtn.addEventListener('click', function () {
                requestConsole(reconnectBtn);
            });
        }
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', closeConsole);
        }
    }

    function stateVariant(bucket) {
        switch (bucket) {
            case 'RUNNING': return 'success';
            case 'STARTING':
            case 'STOPPING': return 'warning';
            case 'STOPPED': return 'neutral';
            default: return 'neutral';
        }
    }

    function applyState(bucket) {
        var badge = qs('#hcv-state-badge');
        if (badge) {
            badge.textContent = bucket;
            badge.className = 'hcv-badge hcv-badge-' + stateVariant(bucket);
        }

        var start = qs('#hcv-btn-start');
        var stop = qs('#hcv-btn-stop');
        var reboot = qs('#hcv-btn-reboot');
        var resetpw = qs('#hcv-btn-resetpw');
        var shutdown = qs('#hcv-btn-shutdown');
        var hardReset = qs('#hcv-btn-reset');

        switch (bucket) {
            case 'RUNNING':
                setHidden(start, true); setHidden(stop, false); setHidden(reboot, false); setHidden(resetpw, false);
                setHidden(shutdown, false); setHidden(hardReset, false);
                break;
            case 'STOPPED':
                setHidden(start, false); setHidden(stop, true); setHidden(reboot, true); setHidden(resetpw, true);
                setHidden(shutdown, true); setHidden(hardReset, true);
                break;
            case 'STARTING':
            case 'STOPPING':
                setHidden(start, true); setHidden(stop, true); setHidden(reboot, true); setHidden(resetpw, true);
                setHidden(shutdown, true); setHidden(hardReset, true);
                break;
            default:
                setHidden(start, false); setHidden(stop, false); setHidden(reboot, false); setHidden(resetpw, false);
                setHidden(shutdown, false); setHidden(hardReset, false);
        }
    }

    function loadOverview(quiet) {
        if (!quiet) {
            panelBusy('overview', true);
        }

        return api('overview').then(function (res) {
            panelBusy('overview', false);

            if (res.status !== 'success') {
                fatal(res.message || t('err_generic', 'Something went wrong.'));
                stopPolling();
                return;
            }
            setHidden(qs('#hcv-fatal'), true);
            renderOverview(res.data);
        }).catch(function (error) {
            fatal(describeFailure(error));
            stopPolling();
        });
    }

    function renderOverview(data) {
        applyState(data.stateBucket);
        applyProtection(data);

        currentServerName = data.name || '';

        var title = qs('#hcv-hero-title');
        if (title) {
            title.textContent = data.name;
        }
        setHidden(qs('#hcv-name-edit'), qs('#hcv-name-editor') && !qs('#hcv-name-editor').hasAttribute('hidden'));

        var meta = [];
        if (IS_ADMIN && data.admin) {
            meta.push(t('meta_server_id', 'Server ID') + ': ' + data.admin.serverId);
        }
        if (data.ipv4) {
            meta.push(data.ipv4);
        }
        if (data.location && data.location.city) {
            meta.push(data.location.city + (data.location.country ? ', ' + data.location.country : ''));
        }
        if (data.iso) {
            meta.push(t('meta_iso', 'ISO') + ': ' + data.iso);
        }
        var metaEl = qs('#hcv-hero-meta');
        if (metaEl) {
            metaEl.textContent = meta.join(' · ');
        }

        setText('#hcv-stat-cpu-value', data.stats.cpuCores + ' vCPU');
        setText('#hcv-stat-memory-value', data.stats.memoryGb + ' GB');
        setText('#hcv-stat-storage-value', data.stats.diskGb + ' GB');
        setText('#hcv-stat-traffic-value', data.stats.traffic);

        setText('#hcv-cred-type', data.credentials.type || t('detail_unknown', 'Unknown'));
        setText('#hcv-cred-username', data.credentials.username);
        renderPassword();

        renderRegionMap(data.location);
        setText('#hcv-detail-created', data.created || t('detail_unknown', 'Unknown'));
        setText('#hcv-detail-iso', data.iso || t('detail_none', 'None'));

        if (IS_ADMIN && data.admin) {
            setText('#hcv-admin-serverid', String(data.admin.serverId));
            setText('#hcv-admin-servertype', data.admin.serverType || t('detail_unknown', 'Unknown'));
        }

        var icon = qs('#hcv-os-icon');
        if (icon) {
            attachIconChain(icon, iconChain(data.osIcon || ''));
        }
    }

    function countryFlag(code) {
        var iso = String(code || '').trim().toUpperCase();

        if (!/^[A-Z]{2}$/.test(iso)) {
            return '';
        }

        return String.fromCodePoint(
            0x1F1E6 + iso.charCodeAt(0) - 65,
            0x1F1E6 + iso.charCodeAt(1) - 65
        );
    }

    function renderRegionMap(location) {
        var wrap = qs('#hcv-region-map');

        if (!wrap) {
            return;
        }

        if (!location || !location.city) {
            setHidden(wrap, true);
            return;
        }

        var hasCoords = typeof location.latitude === 'number' && typeof location.longitude === 'number';

        setText('#hcv-region-flag', countryFlag(location.country));
        setText('#hcv-region-city', location.city + (location.country ? ', ' + location.country : ''));
        setText('#hcv-region-meta', location.description || location.name || '');
        setText('#hcv-region-datacenter', location.name || t('detail_unknown', 'Unknown'));
        setText('#hcv-region-lat', hasCoords ? location.latitude.toFixed(4) + '°' : '—');
        setText('#hcv-region-lon', hasCoords ? location.longitude.toFixed(4) + '°' : '—');

        var link = qs('#hcv-region-link');
        if (link) {
            if (hasCoords) {
                link.href = 'https://www.openstreetmap.org/?mlat=' + location.latitude
                    + '&mlon=' + location.longitude + '#map=6/' + location.latitude + '/' + location.longitude;
                setHidden(link, false);
            } else {
                setHidden(link, true);
            }
        }

        setHidden(wrap, false);
    }

    function setText(selector, value) {
        var el = qs(selector);
        if (el) {
            el.textContent = value;
        }
    }

    function renderPassword() {
        var cell = qs('#hcv-cred-password');
        var toggle = qs('#hcv-cred-toggle');

        if (!cell) {
            return;
        }

        if (!currentPassword) {
            cell.textContent = '••••••••';
            return;
        }

        cell.textContent = passwordVisible ? currentPassword : '••••••••';

        if (toggle) {
            var icon = qs('i', toggle);
            var label = qs('span', toggle);
            var text = passwordVisible ? t('btn_hide', 'Hide') : t('btn_show', 'Show');
            if (icon) {
                icon.className = passwordVisible ? 'fas fa-eye-slash' : 'fas fa-eye';
            }
            if (label) {
                label.textContent = text;
            }
            toggle.title = text;
        }
    }

    var consolePasswordVisible = false;

    function renderConsolePassword() {
        var cell = qs('#hcv-console-password');
        var toggle = qs('#hcv-console-password-toggle');

        if (!cell) {
            return;
        }

        cell.textContent = (consolePasswordVisible && currentPassword)
            ? currentPassword
            : '••••••••';

        if (toggle) {
            var icon = qs('i', toggle);
            var label = qs('span', toggle);
            var text = consolePasswordVisible ? t('btn_hide', 'Hide') : t('btn_show', 'Show');

            if (icon) {
                icon.className = consolePasswordVisible ? 'fas fa-eye-slash' : 'fas fa-eye';
            }

            if (label) {
                label.textContent = text;
            }

            toggle.title = text;
            toggle.disabled = !currentPassword;
        }

        var copyBtn = qs('#hcv-console-password-copy');
        if (copyBtn) {
            copyBtn.disabled = !currentPassword;
        }
    }

    function wireConsoleCredentials() {
        var toggle = qs('#hcv-console-password-toggle');
        var copyBtn = qs('#hcv-console-password-copy');

        if (toggle) {
            toggle.addEventListener('click', function () {
                if (currentPassword) {
                    consolePasswordVisible = !consolePasswordVisible;
                    renderConsolePassword();
                    return;
                }

                busy(toggle, true);
                api('credential').then(function (res) {
                    busy(toggle, false);

                    if (res.status !== 'success' || !res.data) {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }

                    currentPassword = res.data.password || '';
                    consolePasswordVisible = true;
                    renderConsolePassword();
                    renderPassword();
                }).catch(function () {
                    busy(toggle, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }

        if (copyBtn) {
            copyBtn.addEventListener('click', function () {
                if (currentPassword) {
                    copyText(currentPassword);
                }
            });
        }
    }

    function showCredential(username, password) {
        setText('#hcv-cred-username', username);
        currentPassword = password || '';
        passwordVisible = false;
        renderPassword();
        setText('#hcv-console-username', username || 'root');
        renderConsolePassword();

        setHidden(qs('#hcv-cred-copy'), !currentPassword);
    }

    function wireCredentialControls() {
        wireConsoleCredentials();
        var toggle = qs('#hcv-cred-toggle');
        var copyBtn = qs('#hcv-cred-copy');

        if (toggle) {
            toggle.addEventListener('click', function () {
                if (passwordVisible) {
                    passwordVisible = false;
                    renderPassword();
                    return;
                }

                if (currentPassword) {
                    passwordVisible = true;
                    renderPassword();
                    return;
                }

                confirmDialog({
                    title: t('credentials_heading', 'Credentials'),
                    message: t('confirm_credential_show', 'Reveal the root password on screen?'),
                    variant: 'primary'
                }).then(function (ok) {
                    if (!ok) {
                        return;
                    }
                    busy(toggle, true);
                    api('credential').then(function (res) {
                        busy(toggle, false);
                        if (res.status !== 'success' || !res.data) {
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        currentPassword = res.data.password || '';
                        passwordVisible = true;
                        renderPassword();
                        renderConsolePassword();
                        setHidden(qs('#hcv-cred-copy'), !currentPassword);
                    }).catch(function () {
                        busy(toggle, false);
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            });
        }

        if (copyBtn) {
            copyBtn.addEventListener('click', function () {
                if (!currentPassword) {
                    return;
                }
                copyText(currentPassword);
            });
        }
    }

    function copyText(value) {
        if (!value) {
            return;
        }

        if (navigator.clipboard) {
            navigator.clipboard.writeText(value);
        }

        toast(t('toast_copied', 'Copied.'), 'success');
    }

    function startPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
        }
        pollTimer = setInterval(function () {
            loadOverview(true);
            refreshLiveChart();
        }, POLL_INTERVAL_MS);
    }

    function stopPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    function followAction(actionId, options) {
        var opts = options || {};
        var panel = opts.panel || 'overview';
        var label = opts.label || t('action_running', 'Working…');
        var attempts = 0;

        if (!actionId) {
            if (opts.done) {
                opts.done();
            }
            return;
        }

        showActionProgress(panel, label, 0);

        function tick() {
            attempts++;

            api('actionStatus', { actionId: actionId }).then(function (res) {
                if (res.status !== 'success') {
                    hideActionProgress(panel);
                    if (opts.done) {
                        opts.done();
                    }
                    return;
                }

                var info = res.data;
                showActionProgress(panel, label, info.progress);

                if (info.finished) {
                    hideActionProgress(panel);

                    if (info.state === 'error') {
                        toast(info.error || t('err_action_failed', 'The provider reported that this action failed.'), 'error');
                    } else {
                        toast(t('action_finished', 'Finished.'), 'success');
                    }

                    if (opts.done) {
                        opts.done();
                    }
                    return;
                }

                if (attempts > 150) {
                    hideActionProgress(panel);
                    if (opts.done) {
                        opts.done();
                    }
                    return;
                }

                setTimeout(tick, 2000);
            }).catch(function () {
                hideActionProgress(panel);
                if (opts.done) {
                    opts.done();
                }
            });
        }

        setTimeout(tick, 1200);
    }

    function showActionProgress(panelName, label, progress) {
        var panel = qs('[data-hcv-panel="' + panelName + '"]');

        if (!panel) {
            return;
        }

        var bar = panel.querySelector(':scope > .hcv-action-progress');

        if (!bar) {
            bar = document.createElement('div');
            bar.className = 'hcv-action-progress';
            bar.innerHTML = '<span class="hcv-action-progress-label"></span>'
                + '<span class="hcv-action-progress-track"><span class="hcv-action-progress-fill"></span></span>'
                + '<span class="hcv-action-progress-value"></span>';
            panel.insertBefore(bar, panel.firstChild);
        }

        setHidden(bar, false);
        bar.querySelector('.hcv-action-progress-label').textContent = label;
        bar.querySelector('.hcv-action-progress-value').textContent = (progress || 0) + '%';
        bar.querySelector('.hcv-action-progress-fill').style.width = (progress || 0) + '%';
    }

    function hideActionProgress(panelName) {
        var panel = qs('[data-hcv-panel="' + panelName + '"]');
        var bar = panel ? panel.querySelector(':scope > .hcv-action-progress') : null;

        if (bar) {
            setHidden(bar, true);
        }
    }

    function pokeAfterAction() {
        setTimeout(function () {
            loadOverview(true);
        }, POST_ACTION_POLL_MS);
    }

    function applyProtection(data) {
        var map = [
            ['#hcv-protect-delete', '#hcv-protect-delete-text', !!(data.protection && data.protection.delete)],
            ['#hcv-protect-rebuild', '#hcv-protect-rebuild-text', !!(data.protection && data.protection.rebuild)]
        ];

        map.forEach(function (entry) {
            var input = qs(entry[0]);
            if (input) {
                input.checked = entry[2];
            }
            setText(entry[1], entry[2] ? t('word_on', 'On') : t('word_off', 'Off'));

            var badge = qs(entry[1].replace('-text', '-badge'));
            if (badge) {
                badge.textContent = entry[2] ? t('word_on', 'On') : t('word_off', 'Off');
                badge.className = 'hcv-badge ' + (entry[2] ? 'hcv-badge-success' : 'hcv-badge-neutral');
            }
        });

        if (typeof data.rescuePassword === 'string' && data.rescuePassword !== '') {
            rescuePassword = data.rescuePassword;
        }

        applyRescueState(data.rescueEnabled);
    }

    function applyRescueState(enabled) {
        var badge = qs('#hcv-rescue-state');

        if (badge) {
            badge.textContent = enabled ? t('word_on', 'On') : t('word_off', 'Off');
            badge.className = 'hcv-badge ' + (enabled ? 'hcv-badge-warning' : 'hcv-badge-neutral');
        }

        setText('#hcv-rescue-btn-text', enabled ? t('btn_disable', 'Disable') : t('btn_enable', 'Enable'));

        rescueEnabled = !!enabled;

        if (!rescueEnabled) {
            rescuePassword = '';
        }

        renderRescuePassword();
    }

    function settleRescue(btn, wanted, attempt) {
        panelBusy('overview', true);
        api('overview').then(function (res) {
            if (res.status === 'success') {
                if (typeof res.data.rescuePassword === 'string' && res.data.rescuePassword !== '') {
                    rescuePassword = res.data.rescuePassword;
                }

                applyRescueState(res.data.rescueEnabled);
                renderOverview(res.data);

                if (!!res.data.rescueEnabled === wanted || attempt >= 3) {
                    busy(btn, false);
                    return;
                }
            }

            if (attempt >= 3) {
                busy(btn, false);
                return;
            }

            window.setTimeout(function () {
                settleRescue(btn, wanted, attempt + 1);
            }, 1200);
        }).catch(function () {
            busy(btn, false);
        });
    }

    function renderRescuePassword() {
        var wrap = qs('#hcv-console-rescue');

        if (!wrap) {
            return;
        }

        setHidden(wrap, !(rescueEnabled && rescuePassword));
        setText('#hcv-console-rescue-password', rescuePassword || '—');
    }

    function wireRescuePasswordCopy() {
        var btn = qs('#hcv-console-rescue-copy');

        if (!btn) {
            return;
        }

        btn.addEventListener('click', function () {
            if (!rescuePassword) {
                return;
            }

            copyText(rescuePassword);
        });
    }

    function submitProtection() {
        var del = qs('#hcv-protect-delete');
        var rebuild = qs('#hcv-protect-rebuild');

        return api('protectionSet', {
            deleteProtection: del && del.checked ? '1' : '0',
            rebuildProtection: rebuild && rebuild.checked ? '1' : '0'
        });
    }

    function wireProtectionControls() {
        qsa('#hcv-protect-delete, #hcv-protect-rebuild').forEach(function (input) {
            input.addEventListener('change', function () {
                confirmDialog({
                    message: t('confirm_protection', 'Change protection for this server?'),
                    variant: 'primary'
                }).then(function (ok) {
                    if (!ok) {
                        input.checked = !input.checked;
                        return;
                    }
                    panelBusy('overview', true);
                    submitProtection().then(function (res) {
                        panelBusy('overview', false);
                        if (res.status !== 'success') {
                            input.checked = !input.checked;
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        toast(res.message || t('toast_ok', 'Done.'), 'success');
                        loadOverview();
                    }).catch(function () {
                        panelBusy('overview', false);
                        input.checked = !input.checked;
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            });
        });

        var rescueBtn = qs('#hcv-rescue-toggle');
        if (rescueBtn) {
            rescueBtn.addEventListener('click', function () {
                var enabling = !rescueEnabled;

                confirmDialog({
                    title: t('rescue_label', 'Rescue System'),
                    message: enabling
                        ? t('confirm_rescue_enable', 'Enable the rescue system? It boots on the next reset and issues its own root password.')
                        : t('confirm_rescue_disable', 'Disable the rescue system?'),
                    variant: enabling ? 'primary' : 'danger'
                }).then(function (ok) {
                    if (!ok) {
                        return;
                    }
                    busy(rescueBtn, true);
                    api(enabling ? 'rescueEnable' : 'rescueDisable').then(function (res) {
                        if (res.status !== 'success') {
                            busy(rescueBtn, false);
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        if (res.data && res.data.password) {
                            rescuePassword = res.data.password;
                            showCredential('root', res.data.password);
                            toast(t('toast_rescue_password', 'Rescue root password (shown once):') + ' ' + res.data.password, 'success');
                        } else {
                            rescuePassword = '';
                            toast(res.message || t('toast_ok', 'Done.'), 'success');
                        }

                        if (res.data && typeof res.data.rescueEnabled === 'boolean') {
                            applyRescueState(res.data.rescueEnabled);
                        }

                        renderRescuePassword();

                        settleRescue(rescueBtn, enabling, 0);
                    }).catch(function () {
                        busy(rescueBtn, false);
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            });
        }
    }

    function wireRename() {
        var editBtn = qs('#hcv-name-edit');
        var editor = qs('#hcv-name-editor');
        var title = qs('#hcv-hero-title');
        var input = qs('#hcv-name-input');
        var saveBtn = qs('#hcv-name-save');
        var cancelBtn = qs('#hcv-name-cancel');

        if (!editBtn || !editor || !title || !input) {
            return;
        }

        function stopEditing() {
            setHidden(editor, true);
            setHidden(title, false);
            setHidden(editBtn, false);
        }

        editBtn.addEventListener('click', function () {
            input.value = currentServerName;
            setHidden(title, true);
            setHidden(editBtn, true);
            setHidden(editor, false);
            input.focus();
            input.select();
        });

        if (cancelBtn) {
            cancelBtn.addEventListener('click', stopEditing);
        }

        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                var next = input.value.trim();

                if (!next || next === currentServerName) {
                    stopEditing();
                    return;
                }

                confirmDialog({
                    title: t('confirm_rename_title', 'Rename Server'),
                    message: t('confirm_rename', 'Rename this server at the provider?'),
                    variant: 'primary'
                }).then(function (ok) {
                    if (!ok) {
                        return;
                    }
                    busy(saveBtn, true);
                    api('serverRename', { serverName: next }).then(function (res) {
                        busy(saveBtn, false);
                        if (res.status !== 'success') {
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        stopEditing();
                        toast(res.message || t('toast_ok', 'Done.'), 'success');
                        loadOverview();
                    }).catch(function () {
                        busy(saveBtn, false);
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            });
        }
    }

    function wireHeroActions() {
        bindConfirmedAction('#hcv-btn-start', 'powerOn', t('confirm_start', 'Start this server?'), 'primary');
        bindConfirmedAction('#hcv-btn-stop', 'powerOff', t('confirm_stop', 'Stop this server? Running processes will end.'), 'danger');
        bindConfirmedAction('#hcv-btn-reboot', 'reboot', t('confirm_reboot', 'Reboot this server now?'), 'primary');
        bindConfirmedAction('#hcv-btn-shutdown', 'shutdown', t('confirm_shutdown', 'Send an ACPI shutdown request? The guest operating system decides whether to honour it.'), 'primary');
        bindConfirmedAction('#hcv-btn-reset', 'powerReset', t('confirm_reset', 'Hard-reset this server? This is equivalent to pulling the power cable and can lose unsaved data.'), 'danger');

        var resetBtn = qs('#hcv-btn-resetpw');
        if (resetBtn) {
            resetBtn.addEventListener('click', function () {
                confirmDialog({
                    title: t('confirm_resetpw_title', 'Reset Root Password'),
                    message: t('confirm_resetpw_message', 'This generates a brand-new root password and immediately invalidates the old one. Continue?'),
                    callout: t('callout_resetpw', 'Anything using the current password stops working immediately.'),
                    variant: 'danger'
                }).then(function (ok) {
                    if (!ok) {
                        return;
                    }
                    busy(resetBtn, true);
                    api('resetPassword').then(function (res) {
                        busy(resetBtn, false);
                        if (res.status !== 'success') {
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        showCredential(res.data.username, res.data.password);
                        toast(t('toast_resetpw', 'Password reset.'), 'success');
                    }).catch(function () {
                        busy(resetBtn, false);
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            });
        }

        var consoleBtn = qs('#hcv-btn-console');
        if (consoleBtn) {
            consoleBtn.addEventListener('click', function () {
                activateTab('console');
            });
        }
    }

    function loadNetwork() {
        panelBusy('network', true);
        api('network').then(function (res) {
            panelBusy('network', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderNetwork(res.data.rows);
            renderIpv6PtrAdd(res.data);
            renderPrimaryIpSwap(res.data);
            renderPrivateNetworkManage(res.data);
            renderFloatingIps(res.data);
            renderPrivateNetworks(res.data);
        }).catch(function () {
            panelBusy('network', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function networkAction(action, payload, confirmText, variant) {
        confirmDialog({ message: confirmText, variant: variant || 'primary' }).then(function (ok) {
            if (!ok) {
                return;
            }
            api(action, payload).then(function (res) {
                if (res.status !== 'success') {
                    toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                    return;
                }
                toast(res.message || t('toast_ok', 'Done.'), 'success');
                loadNetwork();
            }).catch(function () {
                toast(t('err_network', 'Network error.'), 'error');
            });
        });
    }

    function expandFloatingIpRows(rows) {
        var out = [];

        rows.forEach(function (row) {
            out.push(row);

            if (row.kind !== 'network') {
                return;
            }

            (row.ptrRecords || []).forEach(function (record) {
                out.push({
                    id: row.id,
                    ip: record.ip,
                    type: row.type,
                    kind: 'ptr',
                    name: '',
                    dnsPtr: record.dnsPtr,
                    protected: row.protected,
                    labels: row.labels
                });
            });
        });

        return out;
    }

    function renderFloatingIps(data) {
        mountTable({
            body: '#hcv-floatingip-body',
            pager: '#hcv-floatingip-pagination',
            searchInput: '#hcv-floatingip-search',
            searchWrap: '#hcv-floatingip-search-wrap',
            perPage: 5,
            columns: 4,
            rows: expandFloatingIpRows(data.floatingIps || []),
            emptyText: t('floatingip_empty', 'No floating IPs are assigned to this server.'),
            search: function (row) {
                return [row.ip, row.name, row.description, row.dnsPtr].join(' ');
            },
            render: function (row) {
                var tr = document.createElement('tr');

                var ipTd = document.createElement('td');
                ipTd.textContent = row.ip;
                tr.appendChild(ipTd);

                var infoTd = document.createElement('td');
                var typeBadge = document.createElement('span');
                typeBadge.className = 'hcv-badge hcv-badge-info';
                typeBadge.textContent = row.type;
                infoTd.appendChild(typeBadge);
                if (row.name) {
                    var nameSpan = document.createElement('span');
                    nameSpan.className = 'hcv-meta';
                    nameSpan.textContent = row.name;
                    infoTd.appendChild(nameSpan);
                }
                tr.appendChild(infoTd);

                var ptrTd = document.createElement('td');
                var actionTd = document.createElement('td');

                if (row.kind === 'ptr') {
                    tr.className = 'hcv-ptr-row';
                    buildEditableRdns(ptrTd, actionTd, row.dnsPtr || '', function (hostname) {
                        return api('floatingIpRdns', {
                            floatingIpId: row.id,
                            ptrIp: row.ip,
                            dnsPtr: hostname
                        });
                    }, loadNetwork);

                    tr.appendChild(ptrTd);
                    tr.appendChild(actionTd);
                    return tr;
                }

                if (row.kind === 'network') {
                    buildNetworkRdns(ptrTd, row);
                } else {
                    buildEditableRdns(ptrTd, actionTd, row.dnsPtr || '', function (hostname) {
                        return api('floatingIpRdns', {
                            floatingIpId: row.id,
                            ptrIp: row.ip,
                            dnsPtr: hostname
                        });
                    }, loadNetwork);
                }

                tr.appendChild(ptrTd);

                actionTd.appendChild(smallBtn(t('btn_instructions', 'Show instructions'), '', function () {
                    floatingIpInstructions(row);
                }, 'fas fa-info-circle', true));

                actionTd.appendChild(smallBtn(t('btn_actions_log', 'Action history'), '', function () {
                    resourceActionsDialog('floatingip', row.id, t('btn_actions_log', 'Action history'));
                }, 'fas fa-history', true));

                if (data.isAdmin) {
                    actionTd.appendChild(smallBtn(t('btn_label', 'Add labels'), 'hcv-btn-secondary', function () {
                        promptDialog({
                            title: t('btn_label', 'Add labels'),
                            message: t('prompt_floatingip_label', 'Labels for this floating IP:'),
                            hint: t('hint_labels', 'Use key=value pairs separated by commas. Labels are notes at the provider and do not rename the resource.'),
                            fields: [{ name: 'labels', label: t('label_labels', 'Labels'), value: row.labels || '', placeholder: 'owner=support, tier=gold' }]
                        }).then(function (values) {
                            if (!values) {
                                return;
                            }
                            networkAction('floatingIpLabels', {
                                floatingIpId: row.id,
                                labels: values.labels
                            }, t('confirm_floatingip_labels', 'Save labels on this floating IP?'));
                        });
                    }, 'fas fa-tags', true));

                    actionTd.appendChild(smallBtn(t('btn_protect', 'Protect'), '', function () {
                        networkAction('floatingIpProtection', {
                            floatingIpId: row.id,
                            enabled: row.protected ? '0' : '1'
                        }, row.protected
                            ? t('confirm_floatingip_unprotect', 'Disable delete protection on this floating IP?')
                            : t('confirm_floatingip_protect', 'Enable delete protection on this floating IP? Terminating the service clears it again so the address can be released.'));
                    }, 'fas fa-shield-alt', true));

                    if (!row.protected) {
                        actionTd.appendChild(smallBtn(t('btn_delete', 'Delete'), 'hcv-btn-danger', function () {
                            networkAction('floatingIpDelete', { floatingIpId: row.id },
                                t('confirm_floatingip_delete', 'Delete this floating IP? The address is released back to the provider and cannot be recovered.'),
                                'danger');
                        }, 'fas fa-trash-alt', true));
                    }

                    actionTd.appendChild(smallBtn(t('btn_unassign', 'Unassign'), 'hcv-btn-danger', function () {
                        networkAction('floatingIpUnassign', { floatingIpId: row.id },
                            t('confirm_floatingip_unassign', 'Unassign this floating IP from the server?'));
                    }, 'fas fa-unlink', true));
                }

                tr.appendChild(actionTd);
                return tr;
            }
        });
    }

    function loadResize() {
        var block = qs('#hcv-resize-block');

        if (!block) {
            return;
        }

        panelBusy('overview', true);
        api('resize').then(function (res) {
            panelBusy('overview', false);
            if (res.status !== 'success') {
                block.textContent = res.message || t('err_generic', 'Something went wrong.');
                return;
            }

            renderResize(res.data);
        }).catch(function () {
            panelBusy('overview', false);
            block.textContent = t('err_network', 'Network error.');
        });
    }

    function renderResize(data) {
        var block = qs('#hcv-resize-block');

        if (!block) {
            return;
        }

        block.innerHTML = '';

        var select = document.createElement('select');
        select.className = 'hcv-input';

        (data.rows || []).forEach(function (row) {
            if (row.current) {
                return;
            }

            var option = document.createElement('option');
            option.value = row.name;
            option.textContent = row.description + ' — ' + row.cores + ' vCPU, '
                + row.memory + ' GB RAM, ' + row.disk + ' GB'
                + (row.smallerDisk ? ' ' + t('resize_smaller_disk', '(smaller disk)') : '');
            option.disabled = row.smallerDisk;
            select.appendChild(option);
        });

        if (!select.options.length) {
            block.textContent = t('resize_none', 'No other plan is available in this location.');
            return;
        }

        var current = document.createElement('span');
        current.className = 'hcv-selection';
        current.textContent = t('resize_current', 'Current plan:') + ' ' + data.current;
        block.appendChild(current);
        block.appendChild(select);

        var keepDisk = document.createElement('label');
        keepDisk.className = 'hcv-switch';
        var keepInput = document.createElement('input');
        keepInput.type = 'checkbox';
        keepDisk.appendChild(keepInput);
        var track = document.createElement('span');
        track.className = 'hcv-switch-track';
        var thumb = document.createElement('span');
        thumb.className = 'hcv-switch-thumb';
        track.appendChild(thumb);
        keepDisk.appendChild(track);
        block.appendChild(keepDisk);

        var keepLabel = document.createElement('span');
        keepLabel.textContent = t('resize_grow_disk', 'Also grow the disk (permanent)');
        block.appendChild(keepLabel);

        var btn = smallBtn(t('btn_change_plan', 'Change Plan'), 'hcv-btn-danger', function () {
            confirmDialog({
                title: t('confirm_resize_title', 'Change Plan'),
                message: t('confirm_resize_message', 'Move this server to the selected plan? The server must be powered off, and growing the disk cannot be undone.'),
                variant: 'danger'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }

                busy(btn, true);
                api('resizeRun', {
                    serverType: select.value,
                    upgradeDisk: keepInput.checked ? '1' : '0'
                }).then(function (res) {
                    busy(btn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message, 'success');
                    loadOverview();
                    loadResize();
                }).catch(function () {
                    busy(btn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }, 'fas fa-exchange-alt');

        if (!data.poweredOff) {
            btn.disabled = true;
            btn.title = t('resize_needs_off', 'The server must be powered off to change its plan.');
        }

        block.appendChild(btn);
    }

    function renderPrivateNetworkManage(data) {
        var host = qs('#hcv-privatenet-manage');

        if (!host) {
            return;
        }

        host.innerHTML = '';

        if (!data.isAdmin) {
            return;
        }

        var createRow = document.createElement('div');
        createRow.className = 'hcv-inline-form';

        var nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.className = 'hcv-input';
        nameInput.placeholder = t('privatenet_name_placeholder', 'Network name');

        var rangeInput = document.createElement('input');
        rangeInput.type = 'text';
        rangeInput.className = 'hcv-input';
        rangeInput.placeholder = t('privatenet_range_placeholder', '10.0.0.0/16');

        createRow.appendChild(nameInput);
        createRow.appendChild(rangeInput);
        createRow.appendChild(smallBtn(t('btn_create_network', 'Create Network'), 'hcv-btn-primary', function () {
            networkAction('networkCreate', { name: nameInput.value, ipRange: rangeInput.value },
                t('confirm_network_create', 'Create this private network in the project?'));
        }, 'fas fa-plus'));

        host.appendChild(createRow);

        (data.privateNetworks || []).forEach(function (net) {
            var row = document.createElement('div');
            row.className = 'hcv-inline-form';

            var label = document.createElement('span');
            label.textContent = net.name || ('#' + net.id);
            row.appendChild(label);

            var subnet = document.createElement('input');
            subnet.type = 'text';
            subnet.className = 'hcv-input';
            subnet.placeholder = t('privatenet_subnet_placeholder', '10.0.1.0/24');
            row.appendChild(subnet);

            var zone = document.createElement('input');
            zone.type = 'text';
            zone.className = 'hcv-input';
            zone.placeholder = t('privatenet_zone_placeholder', 'eu-central');
            row.appendChild(zone);

            row.appendChild(smallBtn(t('btn_add_subnet', 'Add Subnet'), '', function () {
                networkAction('networkSubnetAdd',
                    { networkId: net.id, ipRange: subnet.value, networkZone: zone.value },
                    t('confirm_subnet_add', 'Add this subnet to the network?'));
            }, 'fas fa-plus'));

            var rename = document.createElement('input');
            rename.type = 'text';
            rename.className = 'hcv-input';
            rename.value = net.name || '';
            rename.placeholder = t('privatenet_name_placeholder', 'Network name');
            row.appendChild(rename);

            row.appendChild(smallBtn(t('btn_rename', 'Rename'), '', function () {
                networkAction('networkRename', { networkId: net.id, name: rename.value },
                    t('confirm_network_rename', 'Rename this private network?'));
            }, 'fas fa-pencil-alt'));

            row.appendChild(smallBtn(t('btn_delete_network', 'Delete Network'), 'hcv-btn-danger', function () {
                networkAction('networkDelete', { networkId: net.id },
                    t('confirm_network_delete', 'Delete this private network? Every server must be detached first.'));
            }, 'fas fa-trash-alt'));

            host.appendChild(row);
        });
    }

    function renderPrimaryIpSwap(data) {
        var wrap = qs('#hcv-primaryip-swap');

        if (!wrap) {
            return;
        }

        wrap.innerHTML = '';

        var pool = data.availablePrimaryIps || [];

        if (!data.isAdmin) {
            wrap.hidden = true;
            return;
        }

        wrap.hidden = false;

        if (!pool.length) {
            renderPrimaryIpCreate(wrap);
            return;
        }

        var label = document.createElement('span');
        label.textContent = t('primaryip_swap_label', 'Replace primary IP with');
        wrap.appendChild(label);

        var select = document.createElement('select');
        select.className = 'hcv-input';
        pool.forEach(function (item) {
            var option = document.createElement('option');
            option.value = String(item.id);
            option.setAttribute('data-hcv-iptype', item.type);
            option.textContent = item.ip + ' (' + item.type.toUpperCase()
                + (item.name ? ', ' + item.name : '') + ')';
            select.appendChild(option);
        });
        wrap.appendChild(select);

        var btn = smallBtn(t('btn_change', 'Change'), 'hcv-btn-primary', function () {
            var chosen = select.options[select.selectedIndex];
            networkAction('primaryIpSwap', {
                primaryIpId: select.value,
                ipType: chosen ? chosen.getAttribute('data-hcv-iptype') : ''
            }, t('confirm_primaryip_swap', 'Replace the server\'s primary IP with this one? The old address is released back to the project.'));
        }, 'fas fa-exchange-alt');

        if (!data.poweredOff) {
            btn.disabled = true;
            btn.title = t('primaryip_needs_off', 'The server must be powered off to change its primary IP.');
        }

        wrap.appendChild(btn);

        wrap.appendChild(smallBtn(t('btn_delete', 'Delete'), 'hcv-btn-danger', function () {
            networkAction('primaryIpDelete', { primaryIpId: select.value },
                t('confirm_primaryip_delete', 'Delete this unassigned primary IP? The address is released back to the provider.'));
        }, 'fas fa-trash-alt'));

        wrap.appendChild(smallBtn(t('btn_protect', 'Protect'), '', function () {
            networkAction('primaryIpProtection', { primaryIpId: select.value, enabled: '1' },
                t('confirm_primaryip_protect', 'Enable delete protection on this primary IP?'));
        }, 'fas fa-shield-alt'));

        wrap.appendChild(smallBtn(t('btn_unprotect', 'Unprotect'), '', function () {
            networkAction('primaryIpProtection', { primaryIpId: select.value, enabled: '0' },
                t('confirm_primaryip_unprotect', 'Disable delete protection on this primary IP?'));
        }, 'fas fa-shield-alt'));

        wrap.appendChild(smallBtn(t('btn_label', 'Add labels'), '', function () {
            var chosen = select.options[select.selectedIndex];

            promptDialog({
                title: t('btn_label', 'Add labels'),
                message: t('prompt_primaryip_label', 'Labels for this primary IP:'),
                hint: t('hint_labels', 'Use key=value pairs separated by commas. Labels are notes at the provider and do not rename the resource.'),
                fields: [{
                    name: 'labels',
                    label: t('label_labels', 'Labels'),
                    value: chosen ? (chosen.getAttribute('data-hcv-labels') || '') : '',
                    placeholder: 'owner=support, tier=gold'
                }]
            }).then(function (values) {
                if (!values) {
                    return;
                }
                networkAction('primaryIpLabels', { primaryIpId: select.value, labels: values.labels },
                    t('confirm_primaryip_labels', 'Save labels on this primary IP?'));
            });
        }, 'fas fa-tags'));

        renderPrimaryIpRdns(wrap, pool);
        renderPrimaryIpCreate(wrap);
    }

    function renderPrimaryIpRdns(wrap, pool) {
        var row = document.createElement('div');
        row.className = 'hcv-inline-form';

        var label = document.createElement('span');
        label.textContent = t('primaryip_rdns_label', 'Primary IP reverse DNS');
        row.appendChild(label);

        var select = document.createElement('select');
        select.className = 'hcv-input';
        pool.forEach(function (item) {
            var option = document.createElement('option');
            option.value = String(item.id);
            option.setAttribute('data-hcv-ip', item.ip);
            option.setAttribute('data-hcv-labels', item.labels || '');
            option.textContent = item.ip;
            select.appendChild(option);
        });
        row.appendChild(select);

        var host = document.createElement('input');
        host.type = 'text';
        host.className = 'hcv-input';
        host.placeholder = t('rdns_placeholder', 'hostname.example.com');
        row.appendChild(host);

        row.appendChild(smallBtn(t('btn_save', 'Save'), '', function () {
            var chosen = select.options[select.selectedIndex];
            networkAction('primaryIpRdns', {
                primaryIpId: select.value,
                ip: chosen ? chosen.getAttribute('data-hcv-ip') : '',
                hostname: host.value
            }, t('confirm_rdns', 'Update reverse DNS for this IP?'));
        }, 'fas fa-save'));

        row.appendChild(smallBtn(t('btn_rdns_reset', 'Reset reverse DNS'), 'hcv-btn-danger', function () {
            var chosen = select.options[select.selectedIndex];
            networkAction('primaryIpRdnsReset', {
                primaryIpId: select.value,
                ip: chosen ? chosen.getAttribute('data-hcv-ip') : ''
            }, t('confirm_rdns_reset', 'Reset reverse DNS for this address back to the provider default?'));
        }, 'fas fa-undo'));

        wrap.appendChild(row);
    }

    function renderPrimaryIpCreate(wrap) {
        var row = document.createElement('div');
        row.className = 'hcv-inline-form';

        var nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.className = 'hcv-input';
        nameInput.placeholder = t('primaryip_name_placeholder', 'New primary IP name');
        row.appendChild(nameInput);

        var typeSelect = document.createElement('select');
        typeSelect.className = 'hcv-input';
        ['ipv4', 'ipv6'].forEach(function (type) {
            var option = document.createElement('option');
            option.value = type;
            option.textContent = type.toUpperCase();
            typeSelect.appendChild(option);
        });
        row.appendChild(typeSelect);

        row.appendChild(smallBtn(t('btn_create_primaryip', 'Create Primary IP'), 'hcv-btn-primary', function () {
            networkAction('primaryIpCreate', { name: nameInput.value, ipType: typeSelect.value },
                t('confirm_primaryip_create', 'Create a spare primary IP in this datacenter? It is billed from creation, whether or not it is assigned.'));
        }, 'fas fa-plus'));

        wrap.appendChild(row);
    }

    function renderFloatingIpAssign(data) {
        var wrap = qs('#hcv-floatingip-assign');
        if (!wrap) {
            return;
        }
        wrap.innerHTML = '';

        var pool = data.availableFloatingIps || [];
        if (!data.isAdmin || !pool.length) {
            wrap.hidden = true;
            return;
        }
        wrap.hidden = false;

        var select = document.createElement('select');
        select.className = 'hcv-input';
        pool.forEach(function (item) {
            var option = document.createElement('option');
            option.value = String(item.id);
            option.textContent = item.ip + (item.name ? ' (' + item.name + ')' : '');
            select.appendChild(option);
        });
        wrap.appendChild(select);

        wrap.appendChild(smallBtn(t('btn_assign', 'Assign'), 'hcv-btn-primary', function () {
            networkAction('floatingIpAssign', { floatingIpId: select.value },
                t('confirm_floatingip_assign', 'Assign this floating IP to the server?'));
        }, 'fas fa-link'));
    }

    function renderPrivateNetworks(data) {
        mountTable({
            body: '#hcv-privatenet-body',
            pager: '#hcv-privatenet-pagination',
            searchInput: '#hcv-privatenet-search',
            searchWrap: '#hcv-privatenet-search-wrap',
            perPage: 5,
            columns: 4,
            rows: data.privateNetworks || [],
            emptyText: t('privatenet_empty', 'This server is not attached to a private network.'),
            search: function (row) {
                return [row.name, row.ipRange, row.serverIp].join(' ');
            },
            render: function (row) {
                var tr = document.createElement('tr');

                var nameTd = document.createElement('td');
                nameTd.textContent = row.name || ('#' + row.id);
                tr.appendChild(nameTd);

                var rangeTd = document.createElement('td');
                rangeTd.textContent = row.ipRange || '—';
                tr.appendChild(rangeTd);

                var ipTd = document.createElement('td');
                ipTd.textContent = row.ip || '—';
                tr.appendChild(ipTd);

                var actionTd = document.createElement('td');
                if (data.isAdmin) {
                    actionTd.appendChild(smallBtn(t('btn_detach', 'Detach'), 'hcv-btn-danger', function () {
                        networkAction('networkDetach', { networkId: row.id },
                            t('confirm_network_detach', 'Detach this server from the network?'));
                    }, 'fas fa-unlink', true));
                }
                tr.appendChild(actionTd);

                return tr;
            }
        });
    }

    function renderPrivateNetworkAttach(data) {
        var wrap = qs('#hcv-privatenet-attach');
        if (!wrap) {
            return;
        }
        wrap.innerHTML = '';

        var pool = data.availableNetworks || [];
        if (!data.isAdmin || !pool.length) {
            wrap.hidden = true;
            return;
        }
        wrap.hidden = false;

        var select = document.createElement('select');
        select.className = 'hcv-input';
        pool.forEach(function (item) {
            var option = document.createElement('option');
            option.value = String(item.id);
            option.textContent = (item.name || ('#' + item.id)) + (item.ipRange ? ' (' + item.ipRange + ')' : '');
            select.appendChild(option);
        });
        wrap.appendChild(select);

        wrap.appendChild(smallBtn(t('btn_attach', 'Attach'), 'hcv-btn-primary', function () {
            networkAction('networkAttach', { networkId: select.value },
                t('confirm_network_attach', 'Attach this server to the selected network?'));
        }, 'fas fa-link'));
    }

    function renderIpv6PtrAdd(data) {
        var wrap = qs('#hcv-rdns-add');

        if (!wrap) {
            return;
        }

        wrap.innerHTML = '';

        if (!data.ipv6Network) {
            setHidden(wrap, true);
            return;
        }

        setHidden(wrap, false);

        var label = document.createElement('label');
        label.textContent = t('rdns_add_label', 'Add IPv6 reverse DNS');
        wrap.appendChild(label);

        var ipInput = document.createElement('input');
        ipInput.type = 'text';
        ipInput.className = 'hcv-input';
        ipInput.value = data.ipv6Suggestion || '';
        ipInput.placeholder = t('rdns_ip_placeholder', 'Address inside ' + data.ipv6Network);
        wrap.appendChild(ipInput);

        var hostInput = document.createElement('input');
        hostInput.type = 'text';
        hostInput.className = 'hcv-input';
        hostInput.placeholder = t('rdns_placeholder', 'hostname.example.com');
        wrap.appendChild(hostInput);

        var addBtn = smallBtn(t('btn_add', 'Add'), 'hcv-btn-primary', function () {
            var ip = ipInput.value.trim();
            var hostname = hostInput.value.trim();

            if (!ip || !hostname) {
                toast(t('err_rdns_incomplete', 'Enter both an address and a hostname.'), 'error');
                return;
            }

            confirmDialog({
                title: t('confirm_rdns_title', 'Update Reverse DNS'),
                message: t('confirm_rdns', 'Update reverse DNS for this IP?'),
                variant: 'primary'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(addBtn, true);
                api('rdnsUpdate', { ip: ip, hostname: hostname }).then(function (res) {
                    busy(addBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    loadNetwork();
                }).catch(function () {
                    busy(addBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }, 'fas fa-plus');

        wrap.appendChild(addBtn);
    }

    function tableBusy(selector, on) {
        var body = qs(selector);
        var table = body ? body.closest('table') : null;

        if (table) {
            table.classList.toggle('hcv-table-busy', !!on);
        }
    }

    function buildNetworkRdns(cell, row) {
        var records = [];

        if (records.length) {
            var list = document.createElement('ul');
            list.className = 'hcv-ptr-list';

            records.forEach(function (record) {
                var item = document.createElement('li');

                var address = document.createElement('code');
                address.textContent = record.ip;
                item.appendChild(address);

                var host = document.createElement('span');
                host.textContent = record.dnsPtr;
                item.appendChild(host);

                item.appendChild(smallBtn(t('btn_remove', 'Remove'), 'hcv-btn-danger', function () {
                    var removeBtn = this;
                    confirmDialog({
                        title: t('confirm_rdns_title', 'Update Reverse DNS'),
                        message: t('confirm_rdns_remove', 'Remove the reverse DNS record for this address?'),
                        variant: 'danger'
                    }).then(function (ok) {
                        if (!ok) {
                            return;
                        }
                        busy(removeBtn, true);
                        api('floatingIpRdns', {
                            floatingIpId: row.id,
                            ptrIp: record.ip,
                            dnsPtr: ''
                        }).then(function (res) {
                            busy(removeBtn, false);
                            if (res.status !== 'success') {
                                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                                return;
                            }
                            toast(res.message || t('toast_ok', 'Done.'), 'success');
                            loadNetwork();
                        }).catch(function () {
                            busy(removeBtn, false);
                            toast(t('err_network', 'Network error.'), 'error');
                        });
                    });
                }, 'fas fa-times', true));

                list.appendChild(item);
            });

            cell.appendChild(list);
        } else {
            var none = document.createElement('span');
            none.className = 'hcv-meta';
            none.textContent = t('rdns_none', 'No entries');
            cell.appendChild(none);
        }

        var form = document.createElement('div');
        form.className = 'hcv-ptr-add';

        var ipInput = document.createElement('input');
        ipInput.type = 'text';
        ipInput.className = 'hcv-input';
        ipInput.value = row.suggestion || '';
        ipInput.placeholder = t('rdns_ip_placeholder_short', 'Address inside the block');
        form.appendChild(ipInput);

        var hostInput = document.createElement('input');
        hostInput.type = 'text';
        hostInput.className = 'hcv-input';
        hostInput.placeholder = t('rdns_placeholder', 'hostname.example.com');
        form.appendChild(hostInput);

        var addBtn = smallBtn(t('btn_add', 'Add'), 'hcv-btn-primary', function () {
            var ip = ipInput.value.trim();
            var hostname = hostInput.value.trim();

            if (!ip || !hostname) {
                toast(t('err_rdns_incomplete', 'Enter both an address and a hostname.'), 'error');
                return;
            }

            confirmDialog({
                title: t('confirm_rdns_title', 'Update Reverse DNS'),
                message: t('confirm_rdns', 'Update reverse DNS for this IP?'),
                variant: 'primary'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(addBtn, true);
                api('floatingIpRdns', {
                    floatingIpId: row.id,
                    ptrIp: ip,
                    dnsPtr: hostname
                }).then(function (res) {
                    busy(addBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    loadNetwork();
                }).catch(function () {
                    busy(addBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }, 'fas fa-plus');

        form.appendChild(addBtn);
        cell.appendChild(form);
    }

    function buildEditableRdns(valueTd, actionTd, initialValue, save, reload) {
        var current = initialValue;

        var text = document.createElement('span');
        text.className = 'hcv-rdns-value';

        var input = document.createElement('input');
        input.type = 'text';
        input.className = 'hcv-input';
        input.placeholder = t('rdns_placeholder', 'hostname.example.com');
        setHidden(input, true);

        valueTd.appendChild(text);
        valueTd.appendChild(input);

        var editBtn = smallBtn(t('btn_edit', 'Edit'), '', function () {
            input.value = current;
            setHidden(text, true);
            setHidden(input, false);
            setHidden(editBtn, true);
            setHidden(saveBtn, false);
            setHidden(cancelBtn, false);
            input.focus();
            input.select();
        }, 'fas fa-pencil-alt', true);

        var saveBtn = smallBtn(t('btn_save', 'Save'), 'hcv-btn-primary', function () {
            var next = input.value.trim();

            confirmDialog({
                title: t('confirm_rdns_title', 'Update Reverse DNS'),
                message: t('confirm_rdns', 'Update reverse DNS for this IP?'),
                variant: 'primary'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(saveBtn, true);
                save(next).then(function (res) {
                    busy(saveBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    current = next;
                    stopEditing();
                    toast(res.message || t('toast_ok', 'Done.'), 'success');

                    if (typeof reload === 'function') {
                        tableBusy('#hcv-network-body', true);
                        reload();
                    }
                }).catch(function () {
                    busy(saveBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }, 'fas fa-save', true);

        var cancelBtn = smallBtn(t('btn_cancel', 'Cancel'), '', function () {
            stopEditing();
        }, 'fas fa-times', true);

        function stopEditing() {
            text.textContent = current || '—';
            setHidden(text, false);
            setHidden(input, true);
            setHidden(editBtn, false);
            setHidden(saveBtn, true);
            setHidden(cancelBtn, true);
        }

        var resetBtn = smallBtn(t('btn_rdns_reset', 'Reset reverse DNS'), 'hcv-btn-danger', function () {
            var btn = this;

            confirmDialog({
                title: t('btn_rdns_reset', 'Reset reverse DNS'),
                message: t('confirm_rdns_reset', 'Reset reverse DNS for this address back to the provider default?'),
                variant: 'danger'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }

                busy(btn, true);
                save('').then(function (res) {
                    busy(btn, false);

                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }

                    toast(res.message || t('toast_ok', 'Done.'), 'success');

                    if (reload) {
                        reload();
                    }
                }).catch(function () {
                    busy(btn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }, 'fas fa-undo', true);

        actionTd.appendChild(editBtn);
        actionTd.appendChild(saveBtn);
        actionTd.appendChild(cancelBtn);
        actionTd.appendChild(resetBtn);
        stopEditing();
    }

    function renderNetwork(rows) {
        tableBusy('#hcv-network-body', false);

        mountTable({
            body: '#hcv-network-body',
            pager: '#hcv-network-pagination',
            searchInput: '#hcv-network-search',
            searchWrap: '#hcv-network-search-wrap',
            perPage: 5,
            columns: 4,
            rows: rows,
            emptyText: t('network_empty', 'No public IP addresses found.'),
            search: function (row) {
                return row.ip + ' ' + row.version + ' ' + (row.dnsPtr || '');
            },
            render: function (row) {
                var tr = document.createElement('tr');

                var ipTd = document.createElement('td');
                ipTd.textContent = row.ip;
                tr.appendChild(ipTd);

                var infoTd = document.createElement('td');
                var versionBadge = document.createElement('span');
                versionBadge.className = 'hcv-badge hcv-badge-info';
                versionBadge.textContent = row.version;
                infoTd.appendChild(versionBadge);

                if (row.kind === 'network') {
                    var netBadge = document.createElement('span');
                    netBadge.className = 'hcv-badge hcv-badge-neutral';
                    netBadge.textContent = t('badge_network', 'Network');
                    infoTd.appendChild(netBadge);
                } else {
                    var mainBadge = document.createElement('span');
                    mainBadge.className = 'hcv-badge ' + (row.main ? 'hcv-badge-success' : 'hcv-badge-neutral');
                    mainBadge.textContent = row.main ? t('badge_main', 'Main') : t('badge_secondary', 'Secondary');
                    infoTd.appendChild(mainBadge);
                }

                if (row.blocked) {
                    var blockedBadge = document.createElement('span');
                    blockedBadge.className = 'hcv-badge hcv-badge-danger';
                    blockedBadge.textContent = t('badge_blocked', 'Blocked');
                    infoTd.appendChild(blockedBadge);
                }
                tr.appendChild(infoTd);

                var ptrTd = document.createElement('td');
                var actionTd = document.createElement('td');

                if (row.kind === 'network') {
                    var note = document.createElement('span');
                    note.className = 'hcv-rdns-value';
                    note.textContent = t('rdns_network_note', 'Per-address — add an entry below');
                    ptrTd.appendChild(note);
                } else {
                    buildEditableRdns(ptrTd, actionTd, row.dnsPtr || '', function (hostname) {
                        return api('rdnsUpdate', { ip: row.ip, hostname: hostname });
                    }, loadNetwork);
                }

                tr.appendChild(ptrTd);
                tr.appendChild(actionTd);

                return tr;
            }
        });
    }

    function loadTraffic(range, customFrom, customTo, quiet) {
        currentRange = range;
        var isNetwork = currentMetric === 'network';
        var payload = { range: range };
        if (range === 'custom') {
            payload.customFrom = customFrom;
            payload.customTo = customTo;
        }
        if (!isNetwork) {
            payload.metric = currentMetric;
        }
        setHidden(qs('#hcv-traffic-totals'), !isNetwork);
        setHidden(qs('#hcv-traffic-live'), !isLiveRange(range));
        scheduleLiveTick();
        setHidden(qs('#hcv-traffic-spinner'), !!quiet);

        api(isNetwork ? 'traffic' : 'metrics', payload).then(function (res) {
            setHidden(qs('#hcv-traffic-spinner'), true);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            trafficChartData = res.data;
            if (isNetwork) {
                setText('#hcv-traffic-total-in', formatBytes(res.data.totalInBytes));
                setText('#hcv-traffic-total-out', formatBytes(res.data.totalOutBytes));
            }
            drawTrafficChart();
        }).catch(function () {
            setHidden(qs('#hcv-traffic-spinner'), true);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function isLiveRange(range) {
        return range === 'live' || range === 'today' || range === 'currentmonth';
    }

    function scheduleLiveTick() {
        if (liveTimer) {
            window.clearInterval(liveTimer);
            liveTimer = null;
        }

        if (currentRange !== 'live') {
            return;
        }

        liveTimer = window.setInterval(function () {
            var panel = qs('[data-hcv-panel="traffic"]');

            if (!panel || panel.hidden) {
                return;
            }

            loadTraffic('live', null, null, true);
        }, 5000);
    }

    function refreshLiveChart() {
        var panel = qs('[data-hcv-panel="traffic"]');

        if (!panel || panel.hidden || !isLiveRange(currentRange)) {
            return;
        }

        loadTraffic(currentRange, null, null, true);
    }

    function chartLabels() {
        return {
            out: (trafficChartData && trafficChartData.labelOut) || t('traffic_out', 'Outgoing'),
            in: trafficChartData && typeof trafficChartData.labelIn === 'string'
                ? trafficChartData.labelIn
                : t('traffic_in', 'Incoming')
        };
    }

    function formatChartValue(value) {
        var unit = trafficChartData && trafficChartData.unit;

        if (unit === 'percent') {
            return (Math.round(value * 10) / 10) + '%';
        }

        if (unit === 'ops' || unit === 'pps') {
            return formatCount(value) + (unit === 'ops' ? ' IO/s' : ' p/s');
        }

        return formatBytes(value);
    }

    function formatCount(value) {
        var units = ['', 'K', 'M', 'G'];
        var i = 0;

        while (value >= 1000 && i < units.length - 1) {
            value /= 1000;
            i++;
        }

        return (i === 0 ? Math.round(value) : value.toFixed(1)) + units[i];
    }

    function chartGeometry(w, h) {
        return { left: 58, right: w - 12, top: 14, bottom: h - 30 };
    }

    function chartSpanSeconds(data) {
        var points = data && data.points ? data.points : [];

        if (points.length < 2) {
            return 0;
        }

        return Math.abs(points[points.length - 1].t - points[0].t);
    }

    function formatAxisTime(seconds, span) {
        var d = new Date(seconds * 1000);
        var two = function (n) { return (n < 10 ? '0' : '') + n; };

        if (span > 0 && span <= 900) {
            return two(d.getHours()) + ':' + two(d.getMinutes()) + ':' + two(d.getSeconds());
        }

        if (span > 0 && span <= 172800) {
            return two(d.getHours()) + ':' + two(d.getMinutes());
        }

        return two(d.getDate()) + '/' + two(d.getMonth() + 1);
    }

    function drawTrafficChart() {
        if (!trafficCanvas || !trafficChartData) {
            return;
        }

        var parent = trafficCanvas.parentElement;
        var dpr = window.devicePixelRatio || 1;
        var w = parent.clientWidth;
        var h = 260;

        if (w <= 0) {
            return;
        }

        lastChartWidth = w;
        trafficCanvas.width = w * dpr;
        trafficCanvas.height = h * dpr;
        trafficCanvas.style.width = w + 'px';
        trafficCanvas.style.height = h + 'px';

        var ctx = trafficCanvas.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, w, h);
        ctx.font = '11px sans-serif';
        ctx.textBaseline = 'middle';

        var points = trafficChartData.points || [];
        var box = chartGeometry(w, h);

        if (!points.length) {
            ctx.fillStyle = '#7b8695';
            ctx.textAlign = 'center';
            ctx.fillText(t('traffic_no_data', 'No traffic data for this range.'), w / 2, h / 2);
            trafficHitAreas = [];
            return;
        }

        var max = 1;
        points.forEach(function (p) {
            max = Math.max(max, p.in, p.out);
        });

        var plotH = box.bottom - box.top;
        var plotW = box.right - box.left;

        ctx.strokeStyle = 'rgba(0,0,0,.08)';
        ctx.fillStyle = '#7b8695';
        ctx.lineWidth = 1;
        ctx.textAlign = 'right';

        for (var g = 0; g <= 4; g++) {
            var y = box.bottom - (g * plotH / 4);
            ctx.beginPath();
            ctx.moveTo(box.left, y);
            ctx.lineTo(box.right, y);
            ctx.stroke();
            ctx.fillText(formatChartValue(max * g / 4), box.left - 8, y);
        }

        var slot = plotW / points.length;
        var barWidth = Math.max(2, Math.min(14, slot * 0.35));
        var labelEvery = Math.max(1, Math.ceil(points.length / Math.max(2, Math.floor(plotW / 70))));

        trafficHitAreas = [];
        ctx.textAlign = 'center';

        var singleSeries = chartLabels().in === '';
        var span = chartSpanSeconds(trafficChartData);

        points.forEach(function (p, i) {
            var centre = box.left + (i * slot) + (slot / 2);
            var outH = (p.out / max) * plotH;
            var inH = (p.in / max) * plotH;

            ctx.fillStyle = '#337ab7';

            if (singleSeries) {
                ctx.fillRect(centre - (barWidth / 2), box.bottom - outH, barWidth, outH);
            } else {
                ctx.fillRect(centre - barWidth - 1, box.bottom - outH, barWidth, outH);
                ctx.fillStyle = '#e67e22';
                ctx.fillRect(centre + 1, box.bottom - inH, barWidth, inH);
            }

            if (i % labelEvery === 0) {
                ctx.fillStyle = '#7b8695';
                ctx.fillText(formatAxisTime(p.t, span), centre, box.bottom + 14);
            }

            trafficHitAreas.push({ x: centre, slot: slot, point: p });
        });

        ctx.save();
        ctx.translate(14, box.top + plotH / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.fillStyle = '#7b8695';
        ctx.textAlign = 'center';
        ctx.fillText(t('traffic_axis_usage', 'Usage'), 0, 0);
        ctx.restore();
    }

    function chartAxisLabel() {
        var unit = trafficChartData && trafficChartData.unit;

        if (unit === 'percent') {
            return t('traffic_axis_load', 'Load');
        }

        if (unit === 'ops') {
            return t('traffic_axis_iops', 'IOPS');
        }

        if (unit === 'pps') {
            return t('traffic_axis_pps', 'Packets/s');
        }

        return t('traffic_axis_usage', 'Usage');
    }

    function wireTrafficTooltip() {
        if (!trafficCanvas) {
            return;
        }

        var tip = qs('#hcv-traffic-tooltip');

        trafficCanvas.addEventListener('mousemove', function (event) {
            if (!tip || !trafficHitAreas.length) {
                return;
            }

            var rect = trafficCanvas.getBoundingClientRect();
            var x = event.clientX - rect.left;
            var nearest = null;
            var best = Infinity;

            trafficHitAreas.forEach(function (area) {
                var distance = Math.abs(area.x - x);
                if (distance < best) {
                    best = distance;
                    nearest = area;
                }
            });

            if (!nearest || best > nearest.slot) {
                setHidden(tip, true);
                return;
            }

            var labels = chartLabels();
            setText('#hcv-tooltip-time', formatTooltipTime(nearest.point.t));
            setText('#hcv-tooltip-out', labels.out + ': ' + formatChartValue(nearest.point.out));
            setText('#hcv-tooltip-in', labels.in === '' ? '' : labels.in + ': ' + formatChartValue(nearest.point.in));

            setHidden(tip, false);
            tip.style.left = Math.min(Math.max(nearest.x, 70), rect.width - 70) + 'px';
        });

        trafficCanvas.addEventListener('mouseleave', function () {
            setHidden(qs('#hcv-traffic-tooltip'), true);
        });
    }

    function formatTooltipTime(seconds) {
        var d = new Date(seconds * 1000);
        var two = function (n) { return (n < 10 ? '0' : '') + n; };

        return two(d.getDate()) + '/' + two(d.getMonth() + 1) + ' ' + two(d.getHours()) + ':' + two(d.getMinutes());
    }

    function setupTrafficResizeObserver() {
        if (trafficResizeObserverAttached || !trafficCanvas || typeof ResizeObserver === 'undefined') {
            return;
        }

        var ro = new ResizeObserver(function () {
            var width = trafficCanvas.parentElement.clientWidth;

            if (width <= 0 || width === lastChartWidth) {
                return;
            }

            lastChartWidth = width;

            if (chartFrame) {
                window.cancelAnimationFrame(chartFrame);
            }

            chartFrame = window.requestAnimationFrame(drawTrafficChart);
        });

        ro.observe(trafficCanvas.parentElement);
        trafficResizeObserverAttached = true;
    }

    function wireTrafficControls() {
        qsa('[data-hcv-metric]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                currentMetric = btn.getAttribute('data-hcv-metric');
                qsa('[data-hcv-metric]').forEach(function (b) {
                    b.classList.toggle('active', b === btn);
                });
                var from = qs('#hcv-traffic-from');
                var to = qs('#hcv-traffic-to');
                loadTraffic(currentRange, from ? from.value : '', to ? to.value : '');
            });
        });

        qsa('[data-hcv-range]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var range = btn.getAttribute('data-hcv-range');
                qsa('[data-hcv-range]').forEach(function (b) {
                    b.classList.toggle('active', b === btn);
                });
                setHidden(qs('#hcv-traffic-custom'), range !== 'custom');
                if (range !== 'custom') {
                    loadTraffic(range);
                }
            });
        });

        var applyBtn = qs('#hcv-traffic-apply');
        if (applyBtn) {
            applyBtn.addEventListener('click', function () {
                loadTraffic('custom', qs('#hcv-traffic-from').value, qs('#hcv-traffic-to').value);
            });
        }
    }

    function panelBusy(name, on) {
        var panel = qs('[data-hcv-panel="' + name + '"]');

        if (!panel) {
            return;
        }

        var overlay = panel.querySelector(':scope > .hcv-spinner-overlay');

        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'hcv-spinner-overlay';

            var spinner = document.createElement('span');
            spinner.className = 'hcv-spinner';
            spinner.setAttribute('aria-hidden', 'true');
            overlay.appendChild(spinner);

            var label = document.createElement('span');
            label.textContent = t('loading', 'Loading…');
            overlay.appendChild(label);

            panel.appendChild(overlay);
        }

        panel.classList.toggle('hcv-panel-busy', !!on);
        setHidden(overlay, !on);
    }

    function setPanelLoading(hostSelector, spinnerSelector, on) {
        var host = qs(hostSelector);

        if (host) {
            host.classList.toggle('hcv-is-loading', !!on);
        }

        setHidden(qs(spinnerSelector), !on);
    }

    function loadReinstall() {
        setPanelLoading('#hcv-reinstall-host', '#hcv-reinstall-spinner', true);

        api('reinstall').then(function (res) {
            setPanelLoading('#hcv-reinstall-host', '#hcv-reinstall-spinner', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            reinstallRebuildProtected = !!res.data.rebuildProtected;
            renderLockBar(res.data.locked);
            renderCurrentOs(res.data.currentImage);
            renderReinstallImages(res.data.images, res.data.locked);
        }).catch(function () {
            setPanelLoading('#hcv-reinstall-host', '#hcv-reinstall-spinner', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderLockBar(locked) {
        var toggle = qs('#hcv-lock-toggle');
        if (toggle) {
            toggle.checked = locked;
        }

        var bar = qs('#hcv-lock-bar');
        if (bar) {
            bar.classList.toggle('hcv-lock-active', locked);
        }

        var badge = qs('#hcv-lock-badge');
        if (badge) {
            badge.className = 'hcv-badge ' + (locked ? 'hcv-badge-warning' : 'hcv-badge-success');
            badge.textContent = locked ? t('word_on', 'On') : t('word_off', 'Off');
        }

        renderReinstallBlocked(locked);
    }

    function renderReinstallBlocked(locked) {
        var note = qs('#hcv-reinstall-blocked');
        if (!note) {
            return;
        }

        var reasons = [];
        if (locked) {
            reasons.push(t('blocked_lock', 'Action Protection is on.'));
        }
        if (reinstallRebuildProtected) {
            reasons.push(t('blocked_rebuild', 'Rebuild protection is on at the provider.'));
        }

        setHidden(note, reasons.length === 0);
        setText('#hcv-reinstall-blocked-text', reasons.join(' ') + ' '
            + t('blocked_suffix', 'Reinstalling is blocked until it is switched off.'));
    }

    function renderCurrentOs(name) {
        var row = qs('#hcv-reinstall-current');
        if (!row) {
            return;
        }

        setHidden(row, !name);
        setText('#hcv-reinstall-current-name', name || '');
    }

    function wireLockToggle() {
        var toggle = qs('#hcv-lock-toggle');
        if (!toggle) {
            return;
        }
        toggle.addEventListener('change', function () {
            var next = toggle.checked;
            confirmDialog({
                message: next
                    ? t('confirm_lock_on', 'Enable Action Protection? Reinstall/rebuild will be blocked until you disable it.')
                    : t('confirm_lock_off', 'Disable Action Protection?'),
                variant: next ? 'primary' : 'danger'
            }).then(function (ok) {
                if (!ok) {
                    toggle.checked = !next;
                    return;
                }
                busy(toggle, true);
                api('reinstallLockToggle', { locked: next ? '1' : '0' }).then(function (res) {
                    busy(toggle, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        toggle.checked = !next;
                        return;
                    }
                    renderLockBar(res.data.locked);
                    renderReinstallImages(lastReinstallImages, res.data.locked);
                    toast(t('toast_ok', 'Done.'), 'success');
                }).catch(function () {
                    busy(toggle, false);
                    toast(t('err_network', 'Network error.'), 'error');
                    toggle.checked = !next;
                });
            });
        });
    }

    function renderReinstallImages(images, locked) {
        lastReinstallImages = images;
        selectedReinstallImage = null;
        selectedReinstallLabel = '';
        var container = qs('#hcv-reinstall-images');
        if (!container) {
            return;
        }
        container.innerHTML = '';

        var families = {};
        images.forEach(function (img) {
            families[img.family] = families[img.family] || [];
            families[img.family].push(img);
        });

        var blocked = locked || reinstallRebuildProtected;

        buildOsPicker(container, families, function (img) {
            return buildOsCard(img, 'hcv-os-image', blocked, function () {
                selectedReinstallImage = img.name;
                selectedReinstallLabel = img.description || img.name;
                setText('#hcv-reinstall-selection',
                    t('select_chosen', 'Selected:') + ' ' + (img.description || img.name));
                var submitBtn = qs('#hcv-reinstall-submit');
                if (submitBtn) {
                    submitBtn.disabled = blocked;
                }
            });
        });

        setText('#hcv-reinstall-selection', t('select_nothing', 'Nothing selected yet.'));

        var submitBtn = qs('#hcv-reinstall-submit');
        if (submitBtn) {
            submitBtn.disabled = true;
        }
    }

    function buildOsPicker(container, families, buildCard) {
        container.innerHTML = '';

        var names = Object.keys(families).sort();

        if (!names.length) {
            return;
        }

        var chips = document.createElement('div');
        chips.className = 'hcv-os-families';

        var grid = document.createElement('div');
        grid.className = 'hcv-os-grid';

        function selectFamily(name) {
            qsa('.hcv-os-family', chips).forEach(function (chip) {
                chip.classList.toggle('active', chip.getAttribute('data-family') === name);
            });

            grid.innerHTML = '';
            families[name].forEach(function (item) {
                grid.appendChild(buildCard(item));
            });
        }

        names.forEach(function (name) {
            var chip = document.createElement('button');
            chip.type = 'button';
            chip.className = 'hcv-os-family';
            chip.setAttribute('data-family', name);

            var icon = document.createElement('img');
            icon.alt = '';
            attachIconChain(icon, iconChain(name));
            chip.appendChild(icon);

            var label = document.createElement('span');
            label.textContent = name;
            chip.appendChild(label);

            var count = document.createElement('em');
            count.textContent = families[name].length;
            chip.appendChild(count);

            chip.addEventListener('click', function () {
                selectFamily(name);
            });

            chips.appendChild(chip);
        });

        container.appendChild(chips);
        container.appendChild(grid);
        selectFamily(names[0]);
    }

    function isoFamily(label) {
        var name = String(label || '');
        var known = ['Ubuntu', 'Debian', 'CentOS', 'Rocky', 'Alma', 'Fedora', 'openSUSE', 'SUSE',
                     'Arch', 'Alpine', 'FreeBSD', 'Windows', 'Proxmox', 'Kali', 'Gentoo', 'Mint'];

        for (var i = 0; i < known.length; i++) {
            if (name.toLowerCase().indexOf(known[i].toLowerCase()) !== -1) {
                return known[i];
            }
        }

        var first = name.split(/[\s\-_]+/)[0];
        return first || t('group_other', 'Other');
    }

    function groupByFamily(items, familyOf) {
        var families = {};
        items.forEach(function (item) {
            var key = familyOf(item) || t('group_other', 'Other');
            families[key] = families[key] || [];
            families[key].push(item);
        });
        return families;
    }

    function buildOsCard(item, radioName, disabled, onSelect) {
        var label = document.createElement('label');
        label.className = 'hcv-os-card';
        var radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = radioName;
        radio.value = item.id !== undefined ? item.id : item.name;
        radio.disabled = !!disabled;
        radio.addEventListener('change', onSelect);
        var icon = document.createElement('img');
        icon.alt = '';
        attachIconChain(icon, iconChain(item.name));
        var span = document.createElement('span');
        span.textContent = item.description || item.name;
        label.appendChild(radio);
        label.appendChild(icon);
        label.appendChild(span);
        return label;
    }

    function wireReinstallSubmit() {
        var submitBtn = qs('#hcv-reinstall-submit');
        if (!submitBtn) {
            return;
        }
        submitBtn.addEventListener('click', function () {
            if (!selectedReinstallImage) {
                return;
            }
            confirmDialog({
                title: t('confirm_reinstall_title', 'Reinstall Server'),
                message: t('confirm_reinstall_message', 'This ERASES all data on the server and reinstalls the selected operating system. This cannot be undone. Continue?')
                    + ' ' + t('select_chosen', 'Selected:') + ' ' + selectedReinstallLabel,
                variant: 'danger'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(submitBtn, true);
                api('reinstallRun', { image: selectedReinstallImage }).then(function (res) {
                    busy(submitBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    followAction(res.data && res.data.actionId, {
                        panel: 'reinstall',
                        label: t('action_reinstall', 'Reinstalling…'),
                        done: loadReinstall
                    });
                    pokeAfterAction();
                }).catch(function () {
                    busy(submitBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        });
    }

    function loadRecovery(page) {
        recoveryPage = page;
        setPanelLoading('#hcv-iso-host', '#hcv-iso-spinner', true);

        api('recovery', { page: page }).then(function (res) {
            setPanelLoading('#hcv-iso-host', '#hcv-iso-spinner', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderRecovery(res.data);
        }).catch(function () {
            setPanelLoading('#hcv-iso-host', '#hcv-iso-spinner', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderRecovery(data) {
        var banner = qs('#hcv-iso-banner');
        if (banner) {
            if (data.attached) {
                setText('#hcv-iso-banner-name', data.attached.name);
                setHidden(banner, false);
            } else {
                setHidden(banner, true);
            }
        }

        renderPager('#hcv-iso-pagination', data.page, data.totalPages, loadRecovery, data.totalEntries, data.perPage);

        var container = qs('#hcv-iso-cards');
        var submitBtn = qs('#hcv-iso-attach-submit');
        var selected = null;
        if (container) {
            container.innerHTML = '';

            var families = groupByFamily(data.isos, function (iso) {
                return isoFamily(iso.description || iso.name);
            });

            buildOsPicker(container, families, function (iso) {
                return buildOsCard(iso, 'hcv-iso-select', false, function () {
                    selected = iso.id;
                    setText('#hcv-iso-selection',
                        t('select_chosen', 'Selected:') + ' ' + (iso.description || iso.name));
                    if (submitBtn) {
                        submitBtn.disabled = false;
                    }
                });
            });
        }

        setText('#hcv-iso-selection', t('select_nothing', 'Nothing selected yet.'));

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.onclick = function () {
                if (!selected) {
                    return;
                }
                confirmDialog({
                    message: t('confirm_iso_attach', 'Attach this ISO? The server will boot from it on next restart.'),
                    variant: 'primary'
                }).then(function (ok) {
                    if (!ok) {
                        return;
                    }
                    busy(submitBtn, true);
                    api('isoAttach', { iso: selected }).then(function (res) {
                        busy(submitBtn, false);
                        if (res.status !== 'success') {
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        toast(res.message || t('toast_ok', 'Done.'), 'success');
                        pokeAfterAction();
                        loadRecovery(recoveryPage);
                    }).catch(function () {
                        busy(submitBtn, false);
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            };
        }
    }

    function wireIsoDetach() {
        var detachBtn = qs('#hcv-iso-detach');
        if (!detachBtn) {
            return;
        }
        detachBtn.addEventListener('click', function () {
            confirmDialog({
                message: t('confirm_iso_detach', 'Detach the mounted ISO?'),
                variant: 'danger'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(detachBtn, true);
                api('isoDetach').then(function (res) {
                    busy(detachBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    pokeAfterAction();
                    loadRecovery(recoveryPage);
                }).catch(function () {
                    busy(detachBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        });
    }

    function loadSnapshots() {
        panelBusy('snapshots', true);
        api('snapshots').then(function (res) {
            panelBusy('snapshots', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderSnapshots(res.data.rows);
            renderSnapshotSchedule(res.data.schedule);
        }).catch(function () {
            panelBusy('snapshots', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderSnapshotSchedule(schedule) {
        var freq = qs('#hcv-schedule-frequency');
        var keep = qs('#hcv-schedule-keep');

        if (!freq || !keep) {
            return;
        }

        freq.value = schedule ? schedule.frequency : 'off';
        keep.value = schedule ? schedule.keep : 3;

        var status = schedule && schedule.last_run_at
            ? t('schedule_last_run', 'Last run:') + ' ' + schedule.last_run_at
                + (schedule.last_result ? ' — ' + schedule.last_result : '')
            : t('schedule_never_run', 'Not run yet.');

        setText('#hcv-schedule-status', schedule ? status : '');
    }

    function wireSnapshotSchedule() {
        var btn = qs('#hcv-schedule-save');

        if (!btn) {
            return;
        }

        btn.addEventListener('click', function () {
            var freq = qs('#hcv-schedule-frequency').value;
            var keep = qs('#hcv-schedule-keep').value;

            confirmDialog({
                message: freq === 'off'
                    ? t('confirm_schedule_off', 'Turn scheduled snapshots off?')
                    : t('confirm_schedule_on', 'Save this snapshot schedule? Snapshot storage is billed per GB by the provider.'),
                variant: 'primary'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }

                busy(btn, true);
                api('snapshotSchedule', { frequency: freq, keep: keep }).then(function (res) {
                    busy(btn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message, 'success');
                    loadSnapshots();
                }).catch(function () {
                    busy(btn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        });
    }

    function snapshotAction(action, payload, message, variant, extra) {
        var body = payload || {};
        var key;

        for (key in extra || {}) {
            if (Object.prototype.hasOwnProperty.call(extra, key)) {
                body[key] = extra[key];
            }
        }

        confirmDialog({ message: message, variant: variant || 'primary' }).then(function (ok) {
            if (!ok) {
                return;
            }

            panelBusy('snapshots', true);
            api(action, body).then(function (res) {
                panelBusy('snapshots', false);
                if (res.status !== 'success') {
                    toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                    return;
                }
                toast(res.message || t('toast_ok', 'Done.'), 'success');
                loadSnapshots();
            }).catch(function () {
                panelBusy('snapshots', false);
                toast(t('err_network', 'Network error.'), 'error');
            });
        });
    }

    function renderSnapshots(rows) {
        mountTable({
            body: '#hcv-snapshots-body',
            pager: '#hcv-snapshots-pagination',
            searchInput: '#hcv-snapshots-search',
            searchWrap: '#hcv-snapshots-search-wrap',
            perPage: 10,
            columns: 5,
            rows: rows,
            emptyText: t('snapshots_empty', 'No snapshots or backups yet.'),
            search: function (row) {
                return row.description + ' ' + row.type + ' ' + row.status + ' ' + row.created;
            },
            render: function (snap) {
                var tr = document.createElement('tr');

                var descTd = document.createElement('td');
                descTd.textContent = snap.description || '—';
                tr.appendChild(descTd);

                var typeTd = document.createElement('td');
                var typeBadge = document.createElement('span');
                typeBadge.className = 'hcv-badge ' + (snap.type === 'backup' ? 'hcv-badge-info' : 'hcv-badge-neutral');
                typeBadge.textContent = snap.type === 'backup'
                    ? t('image_type_backup', 'Backup')
                    : t('image_type_snapshot', 'Snapshot');
                typeTd.appendChild(typeBadge);
                tr.appendChild(typeTd);

                var sizeTd = document.createElement('td');
                sizeTd.textContent = snap.size || '—';
                tr.appendChild(sizeTd);

                var createdTd = document.createElement('td');
                createdTd.textContent = snap.created;
                tr.appendChild(createdTd);

                var actionTd = document.createElement('td');

                actionTd.appendChild(smallBtn(t('btn_restore', 'Restore'), 'hcv-btn-danger', function () {
                    var btn = this;
                    confirmDialog({
                        title: t('btn_restore', 'Restore'),
                        message: t('confirm_snapshot_restore', 'Restore this image? This overwrites the server’s current disk contents.'),
                        callout: t('callout_restore', 'Everything written since this image was taken is lost.'),
                        variant: 'danger'
                    }).then(function (ok) {
                        if (!ok) {
                            return;
                        }
                        busy(btn, true);
                        api('snapshotRestore', { snapshotId: snap.id }).then(function (res) {
                            busy(btn, false);
                            if (res.status !== 'success') {
                                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                                return;
                            }
                            toast(res.message || t('toast_ok', 'Done.'), 'success');
                            followAction(res.data && res.data.actionId, {
                                panel: 'snapshots',
                                label: t('action_restore', 'Restoring…'),
                                done: loadSnapshots
                            });
                            pokeAfterAction();
                        }).catch(function () {
                            busy(btn, false);
                            toast(t('err_network', 'Network error.'), 'error');
                        });
                    });
                }, 'fas fa-undo', true));

                if (IS_ADMIN) {
                    actionTd.appendChild(smallBtn(t('btn_label', 'Add labels'), '', function () {
                        promptDialog({
                            title: t('btn_label', 'Add labels'),
                            message: t('prompt_image_label', 'Labels for this image:'),
                            hint: t('hint_labels', 'Use key=value pairs separated by commas. Labels are notes at the provider and do not rename the resource.'),
                            fields: [{ name: 'labels', label: t('label_labels', 'Labels'), value: snap.labels || '', placeholder: 'owner=support, tier=gold' }]
                        }).then(function (values) {
                            if (!values) {
                                return;
                            }
                            snapshotAction('backupLabels', { snapshotId: snap.id },
                                t('confirm_image_labels', 'Save labels on this image?'), 'primary', { labels: values.labels });
                        });
                    }, 'fas fa-tags', true));

                    if (snap.type === 'backup') {
                        actionTd.appendChild(smallBtn(t('btn_convert', 'Convert to snapshot'), '', function () {
                            snapshotAction('backupConvert', { snapshotId: snap.id },
                                t('confirm_backup_convert', 'Convert this backup into a snapshot? It stops rotating with the backup schedule and is billed as snapshot storage until deleted.'),
                                'primary');
                        }, 'fas fa-camera', true));
                    }
                }

                if (snap.deletable && IS_ADMIN) {
                    actionTd.appendChild(smallBtn(t('btn_delete', 'Delete'), 'hcv-btn-danger', function () {
                        var btn = this;
                        confirmDialog({
                            message: t('confirm_snapshot_delete', 'Delete this snapshot? This cannot be undone.'),
                            variant: 'danger'
                        }).then(function (ok) {
                            if (!ok) {
                                return;
                            }
                            busy(btn, true);
                            api('snapshotDelete', { snapshotId: snap.id }).then(function (res) {
                                busy(btn, false);
                                if (res.status !== 'success') {
                                    toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                                    return;
                                }
                                toast(res.message || t('toast_ok', 'Done.'), 'success');
                                loadSnapshots();
                            }).catch(function () {
                                busy(btn, false);
                                toast(t('err_network', 'Network error.'), 'error');
                            });
                        });
                    }, 'fas fa-trash-alt', true));
                }

                tr.appendChild(actionTd);
                return tr;
            }
        });
    }

    function wireSnapshotCreate() {
        var createBtn = qs('#hcv-snapshot-create');
        if (!createBtn) {
            return;
        }
        createBtn.addEventListener('click', function () {
            var input = qs('#hcv-snapshot-description');
            confirmDialog({
                message: t('confirm_snapshot_create', 'Create a snapshot of this server now?'),
                variant: 'primary'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                busy(createBtn, true);
                api('snapshotCreate', { description: input.value.trim() }).then(function (res) {
                    busy(createBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    input.value = '';
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    loadSnapshots();
                }).catch(function () {
                    busy(createBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        });
    }

    function loadFirewall() {
        panelBusy('firewall', true);
        api('firewall').then(function (res) {
            panelBusy('firewall', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderFirewallList(res.data.firewalls);
            renderFirewallApply(res.data);
        }).catch(function () {
            panelBusy('firewall', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderFirewallApply(data) {
        var wrap = qs('#hcv-firewall-apply');

        if (!wrap) {
            return;
        }

        wrap.innerHTML = '';

        var pool = data.availableFirewalls || [];

        if (!data.isAdmin || !pool.length) {
            wrap.hidden = true;
            return;
        }

        wrap.hidden = false;

        var label = document.createElement('span');
        label.textContent = t('firewall_apply_label', 'Apply an existing firewall');
        wrap.appendChild(label);

        var select = document.createElement('select');
        select.className = 'hcv-input';
        pool.forEach(function (item) {
            var option = document.createElement('option');
            option.value = String(item.id);
            option.textContent = item.name + ' (' + item.rules + ')';
            select.appendChild(option);
        });
        wrap.appendChild(select);

        wrap.appendChild(smallBtn(t('btn_apply', 'Apply'), 'hcv-btn-primary', function () {
            var applyBtn = this;
            confirmDialog({
                message: t('confirm_firewall_apply', 'Apply this firewall to the server? Its rules take effect immediately.'),
                variant: 'primary'
            }).then(function (ok) {
                if (!ok) {
                    return;
                }

                busy(applyBtn, true);
                api('firewallApply', { firewallId: select.value }).then(function (res) {
                    busy(applyBtn, false);
                    if (res.status !== 'success') {
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }

                    toast(res.message, 'success');
                    loadFirewall();
                }).catch(function () {
                    busy(applyBtn, false);
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        }, 'fas fa-shield-alt'));
    }

    function renderFirewallList(rows) {
        mountTable({
            body: '#hcv-firewall-body',
            pager: '#hcv-firewall-pagination',
            searchInput: '#hcv-firewall-search',
            searchWrap: '#hcv-firewall-search-wrap',
            perPage: 10,
            columns: 3,
            rows: rows || [],
            emptyText: t('firewall_empty', 'No firewalls attached to this server.'),
            search: function (fw) {
                return fw.name;
            },
            render: function (fw) {
                var tr = document.createElement('tr');

                var nameTd = document.createElement('td');
                nameTd.textContent = fw.name;
                tr.appendChild(nameTd);

                var countTd = document.createElement('td');
                countTd.textContent = String(fw.rules.length);
                tr.appendChild(countTd);

                var actionTd = document.createElement('td');
                actionTd.appendChild(smallBtn(t('btn_edit', 'Edit'), 'hcv-btn-primary', function () {
                    openFirewallForm(fw);
                }, 'fas fa-pencil-alt', true));
                actionTd.appendChild(smallBtn(t('btn_delete', 'Delete'), 'hcv-btn-danger', function () {
                    var btn = this;
                    confirmDialog({
                        message: t('confirm_firewall_delete', 'Delete this firewall?'),
                        variant: 'danger'
                    }).then(function (ok) {
                        if (!ok) {
                            return;
                        }
                        busy(btn, true);
                        api('firewallDelete', { firewallId: fw.id }).then(function (res) {
                            busy(btn, false);
                            if (res.status !== 'success') {
                                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                                return;
                            }
                            toast(res.message || t('toast_ok', 'Done.'), 'success');
                            loadFirewall();
                        }).catch(function () {
                            busy(btn, false);
                            toast(t('err_network', 'Network error.'), 'error');
                        });
                    });
                }, 'fas fa-trash', true));
                tr.appendChild(actionTd);

                return tr;
            }
        });
    }

    function openFirewallForm(fw) {
        qs('#hcv-firewall-id').value = fw ? fw.id : '';
        qs('#hcv-firewall-name').value = fw ? fw.name : '';
        firewallRuleRows = fw ? fw.rules.slice() : [];
        renderFirewallRuleRows();
        setHidden(qs('#hcv-firewall-form'), false);
    }

    function renderFirewallRuleRows() {
        var container = qs('#hcv-firewall-rules');
        if (!container) {
            return;
        }
        container.innerHTML = '';
        firewallRuleRows.forEach(function (rule, index) {
            container.appendChild(buildFirewallRuleRow(rule, index));
        });
    }

    function buildFirewallRuleRow(rule, index) {
        var row = document.createElement('div');
        row.className = 'hcv-firewall-rule';

        var direction = document.createElement('select');
        direction.className = 'hcv-input';
        ['in', 'out'].forEach(function (v) {
            var opt = document.createElement('option');
            opt.value = v;
            opt.textContent = v;
            if (rule.direction === v) {
                opt.selected = true;
            }
            direction.appendChild(opt);
        });
        direction.addEventListener('change', function () {
            rule.direction = direction.value;
        });

        var protocol = document.createElement('select');
        protocol.className = 'hcv-input';
        ['tcp', 'udp', 'icmp', 'esp', 'gre'].forEach(function (v) {
            var opt = document.createElement('option');
            opt.value = v;
            opt.textContent = v;
            if (rule.protocol === v) {
                opt.selected = true;
            }
            protocol.appendChild(opt);
        });

        var portInput = document.createElement('input');
        portInput.type = 'text';
        portInput.className = 'hcv-input';
        portInput.placeholder = t('firewall_port_placeholder', 'port / range / any');
        portInput.value = rule.port || '';
        portInput.style.display = (rule.protocol === 'tcp' || rule.protocol === 'udp') ? '' : 'none';
        portInput.addEventListener('input', function () {
            rule.port = portInput.value.trim();
        });
        protocol.addEventListener('change', function () {
            rule.protocol = protocol.value;
            portInput.style.display = (rule.protocol === 'tcp' || rule.protocol === 'udp') ? '' : 'none';
        });

        var sourcesInput = document.createElement('input');
        sourcesInput.type = 'text';
        sourcesInput.className = 'hcv-input';
        sourcesInput.placeholder = t('firewall_sources_placeholder', 'CIDR list, comma separated');
        sourcesInput.value = (rule.sourceIps || []).join(', ');
        sourcesInput.addEventListener('input', function () {
            rule.sourceIps = sourcesInput.value.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        });

        var descInput = document.createElement('input');
        descInput.type = 'text';
        descInput.className = 'hcv-input';
        descInput.placeholder = t('firewall_description_placeholder', 'Description');
        descInput.value = rule.description || '';
        descInput.addEventListener('input', function () {
            rule.description = descInput.value;
        });

        var removeBtn = smallBtn(t('btn_remove', 'Remove'), 'hcv-btn-danger', function () {
            firewallRuleRows.splice(index, 1);
            renderFirewallRuleRows();
        }, 'fas fa-times', true);

        row.appendChild(direction);
        row.appendChild(protocol);
        row.appendChild(portInput);
        row.appendChild(sourcesInput);
        row.appendChild(descInput);
        row.appendChild(removeBtn);
        return row;
    }

    function wireFirewallForm() {
        var newBtn = qs('#hcv-firewall-new');
        if (newBtn) {
            newBtn.addEventListener('click', function () {
                openFirewallForm(null);
            });
        }

        var cancelBtn = qs('#hcv-firewall-cancel');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function () {
                setHidden(qs('#hcv-firewall-form'), true);
            });
        }

        var addRuleBtn = qs('#hcv-firewall-add-rule');
        if (addRuleBtn) {
            addRuleBtn.addEventListener('click', function () {
                firewallRuleRows.push({
                    direction: 'in',
                    protocol: 'tcp',
                    port: '',
                    sourceIps: ['0.0.0.0/0', '::/0'],
                    destinationIps: [],
                    description: ''
                });
                renderFirewallRuleRows();
            });
        }

        var saveBtn = qs('#hcv-firewall-save');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                var name = qs('#hcv-firewall-name').value.trim();
                if (!name) {
                    toast(t('firewall_name_required', 'Enter a firewall name.'), 'error');
                    return;
                }
                confirmDialog({
                    message: t('confirm_firewall_save', 'Save this firewall? Rules take effect immediately.'),
                    variant: 'primary'
                }).then(function (ok) {
                    if (!ok) {
                        return;
                    }
                    var payload = {
                        firewallId: qs('#hcv-firewall-id').value || '0',
                        name: name
                    };

                    firewallRuleRows.forEach(function (rule, i) {
                        var base = 'rules[' + i + ']';
                        payload[base + '[direction]'] = rule.direction || '';
                        payload[base + '[protocol]'] = rule.protocol || '';
                        payload[base + '[port]'] = rule.port || '';
                        payload[base + '[description]'] = rule.description || '';

                        (rule.sourceIps || []).forEach(function (ip, j) {
                            payload[base + '[sourceIps][' + j + ']'] = ip;
                        });

                        (rule.destinationIps || []).forEach(function (ip, j) {
                            payload[base + '[destinationIps][' + j + ']'] = ip;
                        });
                    });

                    busy(saveBtn, true);
                    api('firewallSave', payload).then(function (res) {
                        busy(saveBtn, false);
                        if (res.status !== 'success') {
                            toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                            return;
                        }
                        toast(res.message || t('toast_ok', 'Done.'), 'success');
                        setHidden(qs('#hcv-firewall-form'), true);
                        loadFirewall();
                    }).catch(function () {
                        busy(saveBtn, false);
                        toast(t('err_network', 'Network error.'), 'error');
                    });
                });
            });
        }
    }

    function loadTasks() {
        panelBusy('tasks', true);
        api('tasks', {}).then(function (res) {
            panelBusy('tasks', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderTasks(res.data);
        }).catch(function () {
            panelBusy('tasks', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderTasks(data) {
        mountTable({
            body: '#hcv-tasks-body',
            pager: '#hcv-tasks-pagination',
            searchInput: '#hcv-tasks-search',
            searchWrap: '#hcv-tasks-search-wrap',
            columns: 4,
            rows: data.rows || [],
            emptyText: t('tasks_empty', 'No provider tasks recorded for this server.'),
            search: function (row) {
                return [row.command.replace(/_/g, ' '), row.status, row.error,
                    formatDateTime(row.started), formatDateTime(row.finished)].join(' ');
            },
            render: function (row) {
                var tr = document.createElement('tr');

                var cmdTd = document.createElement('td');
                cmdTd.textContent = row.command.replace(/_/g, ' ');

                if (row.error) {
                    var err = document.createElement('div');
                    err.className = 'hcv-muted';
                    err.textContent = row.error;
                    cmdTd.appendChild(err);
                }

                tr.appendChild(cmdTd);

                var statusTd = document.createElement('td');
                var badge = document.createElement('span');
                badge.className = 'hcv-badge ' + taskBadgeClass(row.status);
                badge.textContent = row.status === 'running' ? row.status + ' ' + row.progress + '%' : row.status;
                statusTd.appendChild(badge);
                tr.appendChild(statusTd);

                var startedTd = document.createElement('td');
                startedTd.textContent = formatDateTime(row.started);
                tr.appendChild(startedTd);

                var finishedTd = document.createElement('td');
                finishedTd.textContent = formatDateTime(row.finished);
                tr.appendChild(finishedTd);

                return tr;
            }
        });

        var note = qs('#hcv-tasks-truncated');
        if (note) {
            setHidden(note, !data.truncated);
        }
    }

    function taskBadgeClass(status) {
        if (status === 'success') {
            return 'hcv-badge-success';
        }

        return status === 'error' ? 'hcv-badge-danger' : 'hcv-badge-warning';
    }

    function formatDateTime(iso) {
        if (!iso) {
            return '\u2014';
        }

        var d = new Date(iso);

        if (isNaN(d.getTime())) {
            return iso;
        }

        var two = function (n) { return (n < 10 ? '0' : '') + n; };

        return two(d.getDate()) + '/' + two(d.getMonth() + 1) + '/' + d.getFullYear()
            + ' ' + two(d.getHours()) + ':' + two(d.getMinutes());
    }

    function wireTasksRefresh() {
        var refreshBtn = qs('#hcv-tasks-refresh');

        if (refreshBtn) {
            refreshBtn.addEventListener('click', function () {
                loadTasks();
            });
        }
    }

    function loadBackups() {
        panelBusy('snapshots', true);
        api('backups').then(function (res) {
            panelBusy('snapshots', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderBackups(res.data);
        }).catch(function () {
            panelBusy('snapshots', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderBackups(data) {
        backupsEnabled = !!data.enabled;

        var toggle = qs('#hcv-backup-toggle');
        if (toggle) {
            toggle.checked = backupsEnabled;
        }

        var windowBadge = qs('#hcv-backup-window');

        if (windowBadge) {
            setHidden(windowBadge, !data.window);
            setText('#hcv-backup-window-value', data.window
                ? String(data.window).replace('-', ' – ')
                : '');
        }
    }

    function wireBackupToggle() {
        var toggle = qs('#hcv-backup-toggle');
        if (!toggle) {
            return;
        }

        toggle.addEventListener('change', function () {
            var enabling = toggle.checked;

            confirmDialog({
                title: t('tab_backups', 'Backups'),
                message: enabling
                    ? t('confirm_backup_enable', 'Enable automatic backups? The provider charges for this.')
                    : t('confirm_backup_disable', 'Disable automatic backups? Every existing backup is deleted.'),
                variant: enabling ? 'primary' : 'danger'
            }).then(function (ok) {
                if (!ok) {
                    toggle.checked = !enabling;
                    return;
                }
                busy(toggle, true);
                api('backupToggle', { enabled: enabling ? '1' : '0' }).then(function (res) {
                    busy(toggle, false);
                    if (res.status !== 'success') {
                        toggle.checked = !enabling;
                        toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                        return;
                    }
                    toast(res.message || t('toast_ok', 'Done.'), 'success');
                    followAction(res.data && res.data.actionId, {
                        panel: 'snapshots',
                        label: t('action_backups', 'Applying backup setting…'),
                        done: loadBackups
                    });
                    loadBackups();
                    loadSnapshots();
                }).catch(function () {
                    busy(toggle, false);
                    toggle.checked = !enabling;
                    toast(t('err_network', 'Network error.'), 'error');
                });
            });
        });
    }

    function loadVolumes() {
        panelBusy('volumes', true);
        api('volumes').then(function (res) {
            panelBusy('volumes', false);
            if (res.status !== 'success') {
                toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                return;
            }
            renderVolumes(res.data);
        }).catch(function () {
            panelBusy('volumes', false);
            toast(t('err_network', 'Network error.'), 'error');
        });
    }

    function renderVolumes(data) {
        mountTable({
            body: '#hcv-volumes-body',
            pager: '#hcv-volumes-pagination',
            searchInput: '#hcv-volumes-search',
            searchWrap: '#hcv-volumes-search-wrap',
            perPage: 10,
            columns: 4,
            rows: data.rows,
            emptyText: t('volumes_empty', 'No volumes are attached to this server.'),
            search: function (row) {
                return row.name + ' ' + row.linuxDevice + ' ' + row.size;
            },
            render: function (row) {
                var tr = document.createElement('tr');

                [row.name, row.size + ' GB', row.linuxDevice || '—'].forEach(function (text) {
                    var td = document.createElement('td');
                    td.textContent = text;
                    tr.appendChild(td);
                });

                var actionTd = document.createElement('td');

                actionTd.appendChild(smallBtn(t('btn_instructions', 'Show instructions'), '', function () {
                    volumeInstructions(row);
                }, 'fas fa-info-circle', true));

                actionTd.appendChild(smallBtn(t('btn_actions_log', 'Action history'), '', function () {
                    resourceActionsDialog('volume', row.id, t('btn_actions_log', 'Action history'));
                }, 'fas fa-history', true));

                if (data.isAdmin) {
                    actionTd.appendChild(smallBtn(t('btn_resize', 'Resize'), '', function () {
                        promptDialog({
                            title: t('btn_resize', 'Resize'),
                            message: t('prompt_volume_size', 'New size in GB:'),
                            hint: t('hint_volume_resize', 'A volume can only be made larger. Extend the filesystem inside the server afterwards.'),
                            fields: [{ name: 'size', label: t('label_size_gb', 'Size (GB)'), type: 'number', value: row.size, min: row.size }]
                        }).then(function (values) {
                            if (!values) {
                                return;
                            }
                            volumeAction('volumeResize', { volumeId: row.id, size: parseInt(values.size, 10) || 0 },
                                t('confirm_volume_resize', 'Resize this volume? A volume can only be made larger.'), 'primary');
                        });
                    }, 'fas fa-expand-arrows-alt', true));

                    actionTd.appendChild(smallBtn(t('btn_label', 'Add labels'), '', function () {
                        promptDialog({
                            title: t('btn_label', 'Add labels'),
                            message: t('prompt_volume_label', 'Labels for this volume:'),
                            hint: t('hint_labels', 'Use key=value pairs separated by commas. Labels are notes at the provider and do not rename the resource.'),
                            fields: [{ name: 'labels', label: t('label_labels', 'Labels'), value: row.labels || '', placeholder: 'owner=support, tier=gold' }]
                        }).then(function (values) {
                            if (!values) {
                                return;
                            }
                            volumeAction('volumeLabels', { volumeId: row.id, labels: values.labels },
                                t('confirm_volume_labels', 'Save labels on this volume?'), 'primary');
                        });
                    }, 'fas fa-tags', true));

                    actionTd.appendChild(smallBtn(t('btn_protect', 'Protect'), '', function () {
                        volumeAction('volumeProtection', { volumeId: row.id, enabled: row.deleteProtected ? '0' : '1' },
                            row.deleteProtected
                                ? t('confirm_volume_unprotect', 'Disable delete protection on this volume?')
                                : t('confirm_volume_protect', 'Enable delete protection on this volume? Termination will still release it.'),
                            'primary');
                    }, 'fas fa-shield-alt', true));

                    actionTd.appendChild(smallBtn(t('btn_detach', 'Detach'), 'hcv-btn-danger', function () {
                        volumeAction('volumeDetach', { volumeId: row.id },
                            t('confirm_volume_detach', 'Detach this volume? Unmount it inside the server first.'), 'danger');
                    }, 'fas fa-unlink', true));
                }

                tr.appendChild(actionTd);
                return tr;
            }
        });

        renderVolumeAttach(data);
    }

    function renderVolumeAttach(data) {
        var wrap = qs('#hcv-volume-attach');
        if (!wrap) {
            return;
        }

        wrap.innerHTML = '';
        var pool = data.available || [];

        if (!data.isAdmin || !pool.length) {
            setHidden(wrap, true);
            return;
        }

        setHidden(wrap, false);

        var select = document.createElement('select');
        select.className = 'hcv-input';
        pool.forEach(function (item) {
            var option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.name + ' (' + item.size + ' GB, ' + item.location + ')';
            select.appendChild(option);
        });
        wrap.appendChild(select);

        wrap.appendChild(smallBtn(t('btn_attach', 'Attach'), 'hcv-btn-primary', function () {
            volumeAction('volumeAttach', { volumeId: select.value },
                t('confirm_volume_attach', 'Attach this volume to the server?'), 'primary');
        }, 'fas fa-link'));
    }

    function volumeAction(action, payload, message, variant) {
        confirmDialog({ message: message, variant: variant || 'primary' }).then(function (ok) {
            if (!ok) {
                return;
            }
            api(action, payload).then(function (res) {
                if (res.status !== 'success') {
                    toast(res.message || t('err_generic', 'Something went wrong.'), 'error');
                    return;
                }
                toast(res.message || t('toast_ok', 'Done.'), 'success');
                loadVolumes();
            }).catch(function () {
                toast(t('err_network', 'Network error.'), 'error');
            });
        });
    }

    var tabLoaders = {
        overview: function () { loadOverview(); loadResize(); },
        network: function () { loadNetwork(); },
        traffic: function () { loadTraffic(currentRange); },
        reinstall: function () { loadReinstall(); },
        recovery: function () { loadRecovery(1); },
        snapshots: function () { loadSnapshots(); loadBackups(); },
        volumes: function () { loadVolumes(); },
        firewall: function () { loadFirewall(); },
        tasks: function () { loadTasks(); }
    };

    function activateTab(tab) {
        qsa('[data-hcv-tab]').forEach(function (b) {
            b.classList.toggle('active', b.getAttribute('data-hcv-tab') === tab);
        });
        qsa('[data-hcv-panel]').forEach(function (p) {
            setHidden(p, p.getAttribute('data-hcv-panel') !== tab);
        });

        var loader = tabLoaders[tab];
        if (loader) {
            loader();
        }
    }

    function wireTabs() {
        qsa('[data-hcv-tab]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                activateTab(btn.getAttribute('data-hcv-tab'));
            });
        });
    }

    function wireModals() {
    }

    function boot() {
        ROOT = document.getElementById('hcv-app');
        if (!ROOT) {
            return;
        }

        ENDPOINT = ROOT.getAttribute('data-hcv-endpoint') || window.location.href;
        CSRF = ROOT.getAttribute('data-hcv-csrf') || '';
        ASSETS = ROOT.getAttribute('data-hcv-assets') || ASSETS;
        IS_ADMIN = ROOT.getAttribute('data-hcv-isadmin') === '1';

        trafficCanvas = document.getElementById('hcv-traffic-canvas');

        wireHeroActions();
        wireCredentialControls();
        wireRename();
        wireProtectionControls();
        wireTabs();
        wireModals();
        wireConsole();
        wireTrafficControls();
        wireLockToggle();
        wireReinstallSubmit();
        wireIsoDetach();
        wireSnapshotCreate();
        wireSnapshotSchedule();
        wireBackupToggle();
        wireTrafficTooltip();
        wireFirewallForm();
        wireRescuePasswordCopy();
        wireTasksRefresh();
        setupTrafficResizeObserver();

        if (ROOT.getAttribute('data-hcv-suspended') === '1') {
            return;
        }

        loadOverview();
        startPolling();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();

(function () {
    var ADMIN_HINTS = {
        primaryip: 'Swap, create or release the address the server answers on. Changing it needs the server powered off, and the customer will see the new address.',
        changeplan: 'Move this service to another plan directly, without an order. The server is powered off, resized and started again. The disk can grow but never shrink.',
        volumeprotection: 'Delete protection at the provider. While it is on, neither you nor a termination can remove the volume.',
        firewalltemplate: 'Save this rule set so it can be applied to another server later. Templates are yours, not the customer\u2019s.',
        privatenetwork: 'Private networks are Project-wide. Anything created here is visible to every server in the Project, so name it for the customer it belongs to.',
        snapshotpublish: 'A published snapshot appears in the rebuild picker for every service on this Project.'
    };

    function attach(el, text) {
        if (!el || el.dataset.hcvHint === '1') {
            return;
        }

        el.dataset.hcvHint = '1';

        var hint = document.createElement('span');
        hint.className = 'hcv-hint';
        hint.setAttribute('tabindex', '0');
        hint.setAttribute('role', 'note');
        hint.setAttribute('aria-label', text);
        var icon = document.createElement('i');
        icon.className = 'fas fa-info-circle';
        icon.setAttribute('aria-hidden', 'true');
        hint.appendChild(icon);

        var bubble = document.createElement('span');
        bubble.className = 'hcv-bubble';
        bubble.textContent = text;
        hint.appendChild(bubble);

        el.appendChild(hint);
    }

    function fillRow(root) {
        if (root.getAttribute('data-hcv-filled') === '1') {
            return;
        }

        var cell = root.closest('td');

        if (!cell) {
            return;
        }

        cell.style.paddingLeft = '0';
        cell.style.paddingRight = '0';
        root.setAttribute('data-hcv-filled', '1');
    }

    function run() {
        var root = document.getElementById('hcv-app');

        if (!root || root.getAttribute('data-hcv-isadmin') !== '1') {
            return;
        }

        fillRow(root);

        root.querySelectorAll('[data-hcv-adminhint]').forEach(function (el) {
            var text = ADMIN_HINTS[el.getAttribute('data-hcv-adminhint')];

            if (text) {
                attach(el, text);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }

    document.addEventListener('hcv:rendered', run);
})();
