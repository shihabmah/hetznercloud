<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtO0GJZquha/WR3K6p8XtgXNNB3cPidjrwkuiv09Y64LdlQVhhFn3p62xyMOnWcTKfp+fhMh
LP6uy5yX1EDUhXak2ABL1e4LMrad6sLP7RguTMtGlEJNUKmMrmO+DldMqSmClhQjIEGawM2qbKd8
nfQQKgdNtezBXS8CPKkY+ClLDaeUJ9IEyeAMpveRen7iHehFUfBTofZS823zg4RCIVY9p0V1kEpt
eIvv1fQO1pPyM9S/TP+YO1cDWMmgTSrn/0qIBJ8D/0X6J/ae0dfgTp7oaX5h/LK0N1PgPwb+IqWZ
azuUte5Nr8Hkn+eFyhNI2F2ouOdcn/NQQDNWWmt958lPwXUumK5UDiq4kRFJ5uEHyqTeHpjnHG4w
Mqe5ffdz7VDQYWuCtuDV/8DOH1p+yAZtLE4VoYUuMQ9JfXhyhZV3QmroWUVd5k+9pkFWipzvqMCu
nQWxav7wPahtK3griLJDV3PVxoQMYQjz4w1Hn9OQzd1+aXSbIqgzdC3Ra1YXwnqKI3czmYAy7hb9
a5Kla0ljC9QtBagEUWfIrafHFpfe/jNP5vYkrOF+sRm0wQL/5qz0MePqXDRD5B3auM5Li4wlnfuv
8o0slQVVAidVYlK2Vc0izUdDBnBenY7T2YtrqTtRo5H5NWSBFm5IcbQHUxuEOXg7ZYu8lLE933OC
bowEHLYN0nUTSHyT6YOrdNWzio10vD+iT1bCHUMjotiAEl80U4CV2AQUCbKwlwzG0taKW5ADNVLf
CXIRaGsrJcLBDjh/Uzu+lpJPRD0KSKYmOqzTde3S/9Ut6zbKekIAkw1wzJwRvrRCPL6jlRCKaBzs
T1XMu4hhbNLkitBTPF0kIh5ROB0nyA2BhDIeOSKcL5griQAQCuV73Vyq0BUosPLM