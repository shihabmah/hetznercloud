<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv+sorgPcp2TP0PUUOw1+ezgpr2eYTovvDIONNve2VEK1h/23yrtcqiTW4SaRuUi49fW3h5s
VFHM0KNVNwfpHvQvaJv/di93W8i3h2JmUJVJpCvf4e708v51NUOi4p0hUMNQjTrvmz4xSEmG8RYC
vb1WK8Vm1iWP30oSmoK8eMjTu1cbaM/dC7+OBuRrXVfldHoCvGnD0oAUYsqvf5GlX9z15IqQi7cw
JnZbxFMNmWLf+Zs67qbePR0X/urFUoMb5XLFpoqo3Vm8Ha/vA09wQdSnyfAOOivhE61uY0EJrPfG
eP7UKFzysZNOWz+F6j5CWlK1Z06wmUGOH+k+vmxboZZ48jZQNr1ESgPmvPOk6voJcULOPk4UQL30
1qYOCJFS8o8Zu+ZmMA99ZgWmX+kWBDr0OT6MC3dXKoMFoy/uWyTLTtzAUejK3rhfo4H8/1mP376b
rBM4DDIEU07yZOhVdxdij1PNxDx+2w3hrRlWWyTJrzDFkgDzUVHZQy1So4rvRyqviEWpmNFB+8yx
//fjx7XTJOPD0KTkoIl+oNetivbuicSg1X2OhmimulmBV9+PO7to3vOpyuv4wTx3vfGiANyForEe
eyBb+CVWszcPqnZVqc7/nxDxhB8gxV2ZXQPg+3NbvgPicncmR2yt0nvl7oA3jVEZn4K4woczvvgy
PB0CsHcEUDKrv3Q5438RbgucJj7YBbIiAWCqujtgsSaLUZOOsT8vSjwvkY7E25QTvBR3QDIDRiak
ArXPSZyBtrx0bcsKPBr7iBEaIctCtJW8OY6XHKQfLJEBfX5s/yHyb/JUSFpuL1HVIe4tvKeNzkUh
e38SVsNHBwGO8M6IwVyb/bNhZ0mP4IGLwgifEmr++B43cnxhKigoht/ZvKq=