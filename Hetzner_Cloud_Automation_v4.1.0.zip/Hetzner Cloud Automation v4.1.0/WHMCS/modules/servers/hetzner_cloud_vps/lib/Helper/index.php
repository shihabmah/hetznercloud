<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvKHxncV/DDUPg5wEb/yILLwvCz1jbkNxFzugDvLFOJ9vxyUIg8IlMgnmyR6WJthksrXDNzm
QQpMjPLYlHfH0N14rB0Kdc0HexYsUfD/u8T/6Cx+Rnvvm6y02TV5X88oqY88cqDldvGG0Ut6EWwJ
EWOw+aOznNh5hESuB9LY2s7HOWfPyyrLmzSXGQyn2tmQ2z4K/G7BjZs280HZAvaOQpDq94ZDq9O9
MBDbjU6J7lQ3eVo6qYniJMEAGRYB+I3OrhevtvyjCWty24PF+IW2UcftCVAIlcP+JlUGll8+wGda
o1vkGd1JzLGaWi0GKdL6BljlIwKjZFA90YNMjBxpSTDWhcO1EgUmWLHvUZYl1wfA77dwgOquyZUU
JOGuA2+oN//pH1zv+HPAhzbTHp7n/vlgs6Saop3xUYMGapSZGdcSsJEVp5gfsWcQTMxxmE5wCynV
uLLoP8AYHtxy0Ka+kMkNlGo7EklVs8PwDSqfRDjt/R1w8N0PWZK8JdIXlfe20kEzl+TYmqzNupKB
z63PTmatmiObR9yLy9olJf7wBxsEFtoDw5MOi1aYKT4VZMWxcvTv2aHRC/Op6ucmGvFGRkwAgH2E
e2X4mQBGVGcsJfRuAeGfi0LQfJw+kT4tmvRDvIHj2c06vGPGXHmiVplnMGwcYPXS1+HmInwIe/+6
dUhKejNiDwrUlG1E3XrJrVWXeqEkRPsyZP7tEeskTz7KNLmV9Ew9iiFMEm41jO6p26zI//AHIjDs
IvzyhXclHiIRENCVo1+dJqSYPl0mkw5GpmFkiJHBNI7Hd+Cklywg6BP07AyLmUez/VbSN1OtodSW
9IExw0Yxqgn5I8whQEGCqajehb/HrrEfvPhtO+oM3D7ITD1vMEiVOVfUgklZ7lEmwjntI0==