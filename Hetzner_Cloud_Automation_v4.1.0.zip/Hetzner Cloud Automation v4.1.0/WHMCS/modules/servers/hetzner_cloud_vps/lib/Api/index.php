<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsv00wJ5elUBaF2MXnvM2xqM5E8d9J7JIOcudLwo7tBpU+0aBuZaIuM0TlgmAyFdoVx6WIv+
EvqdQmGxcjtMkqzErGN4XnxQUMQODa2/CP8nxPm91kTT3uS5lVcWxeRQrq7QGZYfCzryb9K7i5aE
vkZsmzL/QScVHodRKKGLkLGQxH1Sq+b/d7fvD52wdiMs1bOEPsubFmGMV5LElxwSGxfCXKNikiQH
fkqIsJ020Xhxp4NV4g7syzWEKL9INf1iXqnqBJ8D/0X6J/ae0dfgTp7oahHbfEIoaq1tvNFLUqYZ
aDuC/+q84MH9jLza3Wz1RXrLlWgtNaW+/PDLC686kskWjkLcz24YNJx0ShccMyG5TFypCQFNrnqI
2rxd8DiZn7hAAb12fg5O1JT9cqginlYsD3cRoo/w0sT+OPeHFxOH+mJ0zP43Kw+G1tq4zcOJXxsu
CAbCnqjPa7UgGND/cmkjE17xSl5483EfFN0MgsMG9Okj4oWrG7rlJuX0wViqyNajToKKMBJF6axT
VhXIaUs3Uecq4vMVASZEqlRnvhfet3HVjLDvmuoGYsNWn+NMBAXxCdQOv174QYSKIxpOCSfaPNZg
irejNEQX6nKDiBcgvUCi3GjT/B3VJHq8V28x7cLHp5gi3o2RK32CzlquxJg1ocBvcV8IP2rlo6AR
/vguJUbCVts2wHmED4XdgsyO395H/kZYLlLIo6FiR6c5UpCs6PNkOtk5yihOL6XtxASLktY2QEtj
qLt2VfnOxESCx3z8+zxGhayb7QaGk3hHri1+M0VhlFwwR6RggHEFkz3uGa56KhUUzVnUwk6kb1c0
IAkh5OSmLxPHyF7/UEh5uSSEOyM+RFO/Necol8cobfVa3ALhs5Ph