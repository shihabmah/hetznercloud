<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpTDPAOmaLoApVtnXVJYzd6B5z6s/ZcVie2uk9zIOKdvC0ojQaPvsjM3P+TF8XCDvUakfZUk
QNQzwp2sT/ZcIlfu5rQQbnJNzHwQTmbkbE81sUtTJX+bXl0I384tTfbliSPUXz36CIndFWAGV/IK
M78iNkwgiutu2/GKY9xHikNgszqi6SxtHl95SFX74YcZzFz1RbjO+bMH2otGQbIg7wKFljnN4ODg
VMIkXEliv7gplLGss7qb/bWw8PBx5ae8A7FQBJ8D/0X6J/ae0dfgTp7oahXhqW2XmZSnRPBW2yYU
SK9FvtHn6VKhRgx12A7L+p8FkpkVkmN8ZWmUHmcDoXSpzO/BECkq4bW1fZDt5z+VnEr2tDZcsmgR
xDQwVfCwAXS8eRHEPRgSc7UvL/xsNkXuN+kYbeAa6MWtVoBtRtLyNmxbUQqiK4coRV/WHTb99cMY
Z7m+53qxpzcDnkgi8dTUxwIxx/rXLNTmHGKql71rszDxZ03YwVqHjv4oZJ2TJOBW5Z09o99TlLmr
s1Ixg0as8tHn2+aKpNxzZCeQzl2p2p6wwXF7VtQtgXrgGfzufx4JZas8uHXE8ITUEFR68KHmKEfr
E1jsLY32ge/dLXSdK2KHXQqboAKqUyOA+BJvDQG0RDUFc3Yj6Sq18ZePQ8iQmA+e9tJHGOdA4V5s
m2nMrqHJu/DKHkg5x2kFj0/AfrUvSE1FoVssjMjERdR0j5Wn3CGKFYF7SuyJk6FFZ7IzLY7123Er
eihlcZuF8b7cOMS17yMcDScThKLEuEMQbknz5i6lkL/BVSb6E4hvQBoxUHsOVefY7849uZ6ECUsI
M8XuM4WUzC03VCJwEGrLmt16o+HQfy46M27S67DIq4stu4UNFSwvlTNssm==