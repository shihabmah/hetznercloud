<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPu9VuXfYezPTU+ztETboqUNRs751cFyvsxgubiepOIqhLalm/aP8qeZbAca5Tb168ZiPrb3G
Z1iq5Yb1KCXeAIthv0+6/6hQ61XHFGXlhXwq1H0zPyJzvwtEt4R3XXULrafScR237bpegcoCTaDG
lk+pyzdE65w57FiqaZ9aG2zY3R7T205ORaRrQzJ0xpBZNzRqpJ5EIAo+yrZXVhu7lSS37EV8aV45
6XQi2FfiClOzOEG26Qx3gscNkDq/I8RCEKEEBJ8D/0X6J/ae0dfgTp7oadTckUVPTdtWlG8iQL2X
NJb2hLJRdc47nh2Xrww0Gw8CLRoi1c92tOgGvlydUveh/TO8e8sbfF5d/PUeGYwuiNkQ4k7EhV0+
sanicBRLm594c4ZpRbxKBIC7vGzlBph4ahwoGBRyQg3GeyhGeMojQBS4zFvSJa1ZeSPEq7cumEQL
vdUl6O0jsy/MA8F9qszC57uum2POXhBFK5bXevE0HtLjvyH4zCmB3wXRANU3Xc6scNOk61kJqSFJ
shUE8PP4WZOAKMEdVTi1N5KmkWQF8RmEobjEQhBfl6SXfV/GZ6euL4jWEO2SJbcxnsU7TjGA4xv4
MV8SqvXizeh/Ao6f6iPBDUK8bPFlNUIVXtoFr32Ou9cwgWCpf55GLDBNmChLUoKn2F4JrCbVeOQU
X3+xD3DT8w/D4JJlHuxjwt1cJq3EnQ/qzNUOwv5hWvbtUKvlszISWcchNXUl1iRX/QtAO58U8wJ8
/JBgIehN+6pgh9135FFlaJTvjdDBRl9GMCXTYqB+IbU6VfUlDV7YmxiWL+YvaINLDHYdcde4Qb39
OxdjKxWsX+OCbtI1Jh7/l5ZQcDBpFmd99QC3jZuTGVDMPXsJKD3FXxgs7kLZmW==