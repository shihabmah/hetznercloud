<link rel="stylesheet" href="{$assetsBase|default:'/modules/servers/hetzner_cloud_vps/assets'}/css/clientarea.css?v={$moduleVersion|default:'1'}">

<div id="hcv-app"
     data-hcv-endpoint="{$dashboardEndpoint|default:$smarty.server.REQUEST_URI|escape}"
     data-hcv-assets="{$assetsBase|default:'/modules/servers/hetzner_cloud_vps/assets'}/"
     data-hcv-isadmin="{if $isAdmin}1{else}0{/if}"
     data-hcv-csrf="{$csrfToken|escape}"
     data-hcv-suspended="{if $suspendedMessage}1{else}0{/if}">

    <div id="hcv-toasts" aria-live="polite"></div>



{if !$isAdmin}
    <div class="hcv-billing-card">
        <div class="hcv-billing-head">
            <span class="hcv-billing-title">
                <i class="fas fa-file-invoice" aria-hidden="true"></i>
                <span>{$LANG.billing_heading|default:'Billing'}</span>
            </span>
{if $billing.status}
            <span class="hcv-badge {if $billing.status == 'Active'}hcv-badge-success{elseif $billing.status == 'Suspended'}hcv-badge-danger{else}hcv-badge-neutral{/if}">{$billing.status|escape}</span>
{/if}
        </div>

        <div class="hcv-billing-figures">
            <div class="hcv-billing-figure hcv-billing-figure--blue">
                <span class="hcv-billing-figure-icon"><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i></span>
                <span class="hcv-billing-figure-label">{$LANG.billing_recurring|default:'Recurring Amount'}</span>
                <strong class="hcv-billing-figure-value">{$billing.recurringAmount|default:'—'|escape}</strong>
                <span class="hcv-billing-figure-meta">{$billing.billingCycle|default:''|escape}</span>
            </div>
{if $billing.dailyRate}
            <div class="hcv-billing-figure hcv-billing-figure--purple">
                <span class="hcv-billing-figure-icon"><i class="fas fa-calendar-day" aria-hidden="true"></i></span>
                <span class="hcv-billing-figure-label">{$LANG.billing_daily_rate|default:'Daily Rate'}</span>
                <strong class="hcv-billing-figure-value">{$billing.dailyRate|escape}</strong>
                <span class="hcv-billing-figure-meta">{$LANG.billing_per_day|default:'per day'}</span>
            </div>
            <div class="hcv-billing-figure hcv-billing-figure--green">
                <span class="hcv-billing-figure-icon"><i class="fas fa-chart-line" aria-hidden="true"></i></span>
                <span class="hcv-billing-figure-label">{$LANG.billing_accrued|default:'Accrued This Period'}</span>
                <strong class="hcv-billing-figure-value">{$billing.accruedThisPeriod|escape}</strong>
                <span class="hcv-billing-figure-meta">{$billing.daysElapsed} / {$billing.periodDays} {$LANG.billing_days|default:'days'}</span>
            </div>
{/if}
        </div>

{if $billing.periodDays}
        <div class="hcv-billing-meter hcv-hint" tabindex="0" role="img"
             aria-label="{$billing.daysElapsed} / {$billing.periodDays} {$LANG.billing_days|default:'days'}">
            <div class="hcv-billing-progress">
                <span style="width:{if $billing.periodDays > 0}{$billing.daysElapsed*100/$billing.periodDays}{else}0{/if}%"></span>
            </div>
            <span class="hcv-bubble">
                <strong>{$billing.daysElapsed} / {$billing.periodDays} {$LANG.billing_days|default:'days'}</strong><br>
                {$LANG.billing_accrued|default:'Accrued This Period'}: {$billing.accruedThisPeriod|default:'—'|escape}<br>
                {$LANG.billing_daily_rate|default:'Daily Rate'}: {$billing.dailyRate|default:'—'|escape}<br>
                {$LANG.billing_next_due|default:'Next Due Date'}: {$billing.nextDueDate|default:'—'|escape}
            </span>
        </div>
{/if}

        <dl class="hcv-billing-facts">
            <div>
                <dt>{$LANG.billing_next_due|default:'Next Due Date'}</dt>
                <dd>{$billing.nextDueDate|default:'—'|escape}</dd>
            </div>
            <div>
                <dt>{$LANG.billing_registered|default:'Registered'}</dt>
                <dd>{$billing.registrationDate|default:'—'|escape}</dd>
            </div>
            <div>
                <dt>{$LANG.billing_payment_method|default:'Payment Method'}</dt>
                <dd>{$billing.paymentMethod|default:'—'|escape}</dd>
            </div>
        </dl>
    </div>
{/if}

{if !$isAdmin && $orderedOptions}
    <div class="hcv-summary-card">
        <div class="hcv-summary-head">
            <span class="hcv-summary-icon"><i class="fas fa-sliders-h" aria-hidden="true"></i></span>
            <span>{$LANG.heading_ordered_options|default:'Configurable Options'}</span>
        </div>
        <dl class="hcv-summary-list">
            {foreach from=$orderedOptions item=option}
                <div>
                    <dt>{$option.name|escape}</dt>
                    <dd>{$option.value|escape}</dd>
                </div>
            {/foreach}
        </dl>
    </div>
{/if}

{if !$isAdmin && $purchasedAddons}
    <div class="hcv-summary-card hcv-summary-card--addons">
        <div class="hcv-summary-head">
            <span class="hcv-summary-icon"><i class="fas fa-cart-plus" aria-hidden="true"></i></span>
            <span>{$LANG.heading_purchased_addons|default:'Add-ons'}</span>
        </div>
        <dl class="hcv-summary-list">
            {foreach from=$purchasedAddons item=addon}
                <div>
                    <dt>{$addon.name|escape}</dt>
                    <dd>
                        {$addon.cycle|escape}
                        {if $addon.status && $addon.status != 'Active'}
                            <span class="hcv-badge hcv-badge-neutral">{$addon.status|escape}</span>
                        {/if}
                    </dd>
                </div>
            {/foreach}
        </dl>
    </div>
{/if}


{if $inactive.status}
    <div class="hcv-fatal" role="alert">
        <i class="fas fa-ban" aria-hidden="true"></i>
        <div>
            <strong>{$inactive.title|escape}</strong>
            <p>{$inactive.message|escape}</p>
        </div>
    </div>

{else}

    <div id="hcv-fatal" class="hcv-fatal" role="alert" hidden>
        <i class="fas fa-exclamation-triangle" aria-hidden="true"></i>
        <div>
            <strong>{$LANG.fatal_title|default:'This dashboard could not load.'}</strong>
            <p id="hcv-fatal-message"></p>
        </div>
    </div>

{if !$suspendedMessage}
    <div class="hcv-hero-card">
        <div class="hcv-hero-top">
            <div class="hcv-hero-identity">
                <span class="hcv-hero-icon-wrap">
                    <img id="hcv-os-icon" src="{$assetsBase|default:'/modules/servers/hetzner_cloud_vps/assets'}/images/os.svg" alt="" hidden>
                    <i class="fas fa-server hcv-icon-fallback" aria-hidden="true"></i>
                </span>
                <div>
                    <span id="hcv-state-badge" class="hcv-badge hcv-badge-neutral">{$LANG.state_unknown|default:'UNKNOWN'}</span>
                    <div class="hcv-hero-name">
                        <h3 id="hcv-hero-title">{$LANG.loading|default:'Loading…'}</h3>
{if $features.rename}                        <button type="button" id="hcv-name-edit" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_rename|default:'Rename'}" hidden>
                            <i class="fas fa-pencil-alt" aria-hidden="true"></i><span>{$LANG.btn_rename|default:'Rename'}</span>
                        </button>
                        <span id="hcv-name-editor" class="hcv-name-editor" hidden>
                            <input type="text" id="hcv-name-input" class="hcv-input" maxlength="253">
                            <button type="button" id="hcv-name-save" class="hcv-btn hcv-btn-sm hcv-btn-primary hcv-btn-icon" title="{$LANG.btn_save|default:'Save'}">
                                <i class="fas fa-save" aria-hidden="true"></i><span>{$LANG.btn_save|default:'Save'}</span>
                            </button>
                            <button type="button" id="hcv-name-cancel" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_cancel|default:'Cancel'}">
                                <i class="fas fa-times" aria-hidden="true"></i><span>{$LANG.btn_cancel|default:'Cancel'}</span>
                            </button>
                        </span>
{/if}
                    </div>
                    <p id="hcv-hero-meta" class="hcv-hero-meta"></p>
                </div>
            </div>
            <div class="hcv-hero-actions">
{if $features.power}
                <button type="button" id="hcv-btn-start" class="hcv-btn hcv-btn-success" hidden>
                    <i class="fas fa-play" aria-hidden="true"></i><span>{$LANG.btn_start|default:'Start'}</span>
                </button>
{/if}
{if $features.power && $features.powerStop}
                <button type="button" id="hcv-btn-stop" class="hcv-btn hcv-btn-danger" hidden>
                    <i class="fas fa-stop" aria-hidden="true"></i><span>{$LANG.btn_stop|default:'Stop'}</span>
                </button>
{/if}
{if $features.power && $features.powerReboot}
                <button type="button" id="hcv-btn-reboot" class="hcv-btn hcv-btn-primary" hidden>
                    <i class="fas fa-redo" aria-hidden="true"></i><span>{$LANG.btn_reboot|default:'Reboot'}</span>
                </button>
{/if}
{if $features.power && $features.powerShutdown}
                <button type="button" id="hcv-btn-shutdown" class="hcv-btn" hidden>
                    <i class="fas fa-power-off" aria-hidden="true"></i><span>{$LANG.btn_shutdown|default:'Shutdown'}</span>
                </button>
{/if}
{if $features.power && $features.powerReset}
                <button type="button" id="hcv-btn-reset" class="hcv-btn hcv-btn-danger" hidden>
                    <i class="fas fa-bolt" aria-hidden="true"></i><span>{$LANG.btn_reset|default:'Reset'}</span>
                </button>
{/if}
{if $features.console}
                <button type="button" id="hcv-btn-console" class="hcv-btn hcv-btn-primary">
                    <i class="fas fa-terminal" aria-hidden="true"></i><span>{$LANG.btn_console|default:'Console'}</span>
                </button>
{/if}
{if $features.resetpw}
                <button type="button" id="hcv-btn-resetpw" class="hcv-btn hcv-btn-danger" hidden>
                    <i class="fas fa-key" aria-hidden="true"></i><span>{$LANG.btn_resetpw|default:'Reset Password'}</span>
                </button>
{/if}
            </div>
        </div>

        <div class="hcv-stat-tiles">
            <div class="hcv-stat-tile">
                <i class="fas fa-microchip" aria-hidden="true"></i>
                <div><span class="hcv-stat-label">{$LANG.stat_cpu|default:'CPU'}</span><span class="hcv-stat-value" id="hcv-stat-cpu-value">—</span></div>
            </div>
            <div class="hcv-stat-tile">
                <i class="fas fa-memory" aria-hidden="true"></i>
                <div><span class="hcv-stat-label">{$LANG.stat_memory|default:'Memory'}</span><span class="hcv-stat-value" id="hcv-stat-memory-value">—</span></div>
            </div>
            <div class="hcv-stat-tile">
                <i class="fas fa-hdd" aria-hidden="true"></i>
                <div><span class="hcv-stat-label">{$LANG.stat_storage|default:'Storage'}</span><span class="hcv-stat-value" id="hcv-stat-storage-value">—</span></div>
            </div>
            <div class="hcv-stat-tile">
                <i class="fas fa-exchange-alt" aria-hidden="true"></i>
                <div><span class="hcv-stat-label">{$LANG.stat_traffic|default:'Traffic'}</span><span class="hcv-stat-value" id="hcv-stat-traffic-value">—</span></div>
            </div>
        </div>
    </div>

    <div class="hcv-tabs" role="tablist">
        <button type="button" class="hcv-tab active" data-hcv-tab="overview">{$LANG.tab_overview|default:'Overview'}</button>
{if $features.console}        <button type="button" class="hcv-tab" data-hcv-tab="console">{$LANG.tab_console|default:'Console'}</button>
{/if}
{if $features.network}        <button type="button" class="hcv-tab" data-hcv-tab="network">{$LANG.tab_network|default:'Network'}</button>
{/if}
{if $features.traffic}        <button type="button" class="hcv-tab" data-hcv-tab="traffic">{$LANG.tab_traffic|default:'Traffic'}</button>
{/if}
{if $features.reinstall}        <button type="button" class="hcv-tab" data-hcv-tab="reinstall">{$LANG.tab_reinstall|default:'Reinstall'}</button>
{/if}
{if $features.recovery}        <button type="button" class="hcv-tab" data-hcv-tab="recovery">{$LANG.tab_iso|default:'ISO'}</button>
{/if}
{if $features.snapshots}        <button type="button" class="hcv-tab" data-hcv-tab="snapshots">{$LANG.tab_snapshots|default:'Snapshots'}</button>
{/if}
{if $features.volumes}        <button type="button" class="hcv-tab" data-hcv-tab="volumes">{$LANG.tab_volumes|default:'Volumes'}</button>
{/if}
{if $features.firewall}        <button type="button" class="hcv-tab" data-hcv-tab="firewall">{$LANG.tab_firewall|default:'Firewall'}</button>
{/if}
{if $features.tasks}        <button type="button" class="hcv-tab" data-hcv-tab="tasks">{$LANG.tab_tasks|default:'Tasks'}</button>
{/if}
    </div>

{include file="`$partialsPath`/overview-panel.tpl"}

{include file="`$partialsPath`/console.tpl"}

{include file="`$partialsPath`/network.tpl"}

{include file="`$partialsPath`/traffic.tpl"}

{include file="`$partialsPath`/reinstall.tpl"}

{include file="`$partialsPath`/recovery.tpl"}

{include file="`$partialsPath`/snapshots.tpl"}

{include file="`$partialsPath`/volumes.tpl"}

{include file="`$partialsPath`/firewall.tpl"}

{include file="`$partialsPath`/tasks.tpl"}

{/if}

    <div id="hcv-prompt-modal" class="hcv-modal-overlay" hidden aria-hidden="true">
        <div class="hcv-modal-box" role="dialog" aria-modal="true" aria-labelledby="hcv-prompt-title">
            <div class="hcv-modal-accent"></div>
            <button type="button" class="hcv-modal-x hcv-prompt-cancel" aria-label="{$LANG.modal_close|default:'Close'}">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
            <div class="hcv-modal-header">
                <h4 class="hcv-modal-title" id="hcv-prompt-title"></h4>
            </div>
            <div class="hcv-modal-body">
                <p class="hcv-modal-message" id="hcv-prompt-message"></p>
                <div id="hcv-prompt-fields"></div>
                <p class="hcv-note" id="hcv-prompt-hint"></p>
            </div>
            <div class="hcv-modal-footer">
                <button type="button" class="hcv-btn hcv-prompt-cancel">
                    <i class="fas fa-times" aria-hidden="true"></i><span>{$LANG.modal_cancel|default:'Cancel'}</span>
                </button>
                <button type="button" class="hcv-btn hcv-btn-primary hcv-prompt-submit">
                    <i class="fas fa-check" aria-hidden="true"></i><span>{$LANG.btn_save|default:'Save'}</span>
                </button>
            </div>
        </div>
    </div>

    <div id="hcv-instructions-modal" class="hcv-modal-overlay" hidden aria-hidden="true">
        <div class="hcv-modal-box" role="dialog" aria-modal="true" aria-labelledby="hcv-instructions-title">
            <div class="hcv-modal-accent"></div>
            <button type="button" class="hcv-modal-x hcv-instructions-close" aria-label="{$LANG.modal_close|default:'Close'}">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
            <div class="hcv-modal-header">
                <h4 class="hcv-modal-title" id="hcv-instructions-title">{$LANG.instructions_title|default:'Configure this resource'}</h4>
            </div>
            <div class="hcv-modal-body">
                <p class="hcv-modal-message" id="hcv-instructions-intro"></p>
                <div id="hcv-instructions-steps"></div>
                <p class="hcv-note" id="hcv-instructions-footnote"></p>
            </div>
            <div class="hcv-modal-footer">
                <button type="button" class="hcv-btn hcv-instructions-close">
                    <i class="fas fa-check" aria-hidden="true"></i><span>{$LANG.btn_done|default:'Done'}</span>
                </button>
            </div>
        </div>
    </div>

    <div id="hcv-confirm-modal" class="hcv-modal-overlay" hidden aria-hidden="true">
        <div class="hcv-modal-box" role="dialog" aria-modal="true" aria-labelledby="hcv-confirm-title-el">
            <div class="hcv-modal-accent"></div>
            <button type="button" class="hcv-modal-x hcv-confirm-cancel" aria-label="{$LANG.modal_close|default:'Close'}">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
            <div class="hcv-modal-header">
                <div class="hcv-modal-icon-circle"><i class="fas fa-question" aria-hidden="true"></i></div>
                <div>
                    <h4 class="hcv-confirm-title" id="hcv-confirm-title-el">{$LANG.modal_confirm_title|default:'Please Confirm'}</h4>
                    <p class="hcv-modal-eyebrow" id="hcv-confirm-eyebrow"></p>
                </div>
            </div>
            <div class="hcv-modal-body">
                <p class="hcv-confirm-message">{$LANG.modal_confirm_message|default:'Are you sure?'}</p>
                <div class="hcv-modal-callout" id="hcv-confirm-callout" hidden>
                    <i class="fas fa-exclamation-triangle" aria-hidden="true"></i>
                    <span id="hcv-confirm-callout-text"></span>
                </div>
            </div>
            <div class="hcv-modal-footer">
                <button type="button" class="hcv-btn hcv-confirm-cancel">
                    <i class="fas fa-times" aria-hidden="true"></i><span>{$LANG.modal_cancel|default:'Cancel'}</span>
                </button>
                <button type="button" class="hcv-btn hcv-confirm-confirm hcv-btn-primary">
                    <i class="fas fa-check" aria-hidden="true"></i><span>{$LANG.modal_confirm|default:'Confirm'}</span>
                </button>
            </div>
        </div>
    </div>
{/if}
</div>

{if !$inactive.status}
<script src="{$assetsBase|default:'/modules/servers/hetzner_cloud_vps/assets'}/js/clientarea.js?v={$moduleVersion|default:'1'}"></script>
{/if}
