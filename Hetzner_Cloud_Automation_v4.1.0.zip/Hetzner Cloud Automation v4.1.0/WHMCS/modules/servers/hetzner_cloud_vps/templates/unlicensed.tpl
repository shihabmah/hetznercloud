<link rel="stylesheet" href="{$assetsBase|default:'/modules/servers/hetzner_cloud_vps/assets'}/css/clientarea.css?v={$moduleVersion|default:'1'}">

<div id="hcv-app" class="hcv-app">
    <div class="hcv-fatal" role="alert">
        <i class="fas fa-ban" aria-hidden="true"></i>
        <div>
            <strong>{$unlicensed.title|escape}</strong>
            <p>{$unlicensed.message|escape}</p>
        </div>
    </div>
</div>
