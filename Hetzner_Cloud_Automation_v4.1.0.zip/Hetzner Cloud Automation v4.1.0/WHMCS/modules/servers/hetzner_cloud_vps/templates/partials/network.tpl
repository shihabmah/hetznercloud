{if $features.network}
    <section class="hcv-panel" data-hcv-panel="network" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.network_note|default:'Reverse DNS (PTR) changes can take a few minutes to propagate.'}</span>
        </p>
        <div class="hcv-table-toolbar" id="hcv-network-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-network-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.network_ip|default:'IP Address'}</th>
                    <th>{$LANG.network_info|default:'Info'}</th>
                    <th>{$LANG.network_rdns|default:'Reverse DNS'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="hcv-network-body">
                <tr><td colspan="4" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-network-pagination" class="hcv-pagination" hidden></div>
        <div id="hcv-rdns-add" class="hcv-inline-form" hidden></div>
{if $features.primaryip}        <h4 class="hcv-subhead"{if $isAdmin} data-hcv-adminhint="primaryip"{/if}>{$LANG.primaryip_heading|default:'Primary IP'}</h4>
        <div id="hcv-primaryip-swap" class="hcv-inline-form" hidden></div>
{/if}

{if $features.floatingips}
        <h4 class="hcv-subhead">{$LANG.network_floating_ips|default:'Floating IPs'}</h4>
        <div class="hcv-table-toolbar" id="hcv-floatingip-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-floatingip-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.network_ip|default:'IP Address'}</th>
                    <th>{$LANG.network_info|default:'Info'}</th>
                    <th>{$LANG.network_rdns|default:'Reverse DNS'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="hcv-floatingip-body">
                <tr><td colspan="4" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-floatingip-pagination" class="hcv-pagination" hidden></div>
        <div id="hcv-floatingip-assign" class="hcv-inline-form" hidden></div>
{/if}

{if $features.privatenetworks}
        <h4 class="hcv-subhead"{if $isAdmin} data-hcv-adminhint="privatenetwork"{/if}>{$LANG.network_private|default:'Private Networks'}</h4>
        <div class="hcv-table-toolbar" id="hcv-privatenet-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-privatenet-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.network_name|default:'Network'}</th>
                    <th>{$LANG.network_range|default:'IP Range'}</th>
                    <th>{$LANG.network_server_ip|default:'Server IP'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="hcv-privatenet-body">
                <tr><td colspan="4" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-privatenet-pagination" class="hcv-pagination" hidden></div>
        <div id="hcv-privatenet-attach" class="hcv-inline-form" hidden></div>
        <div id="hcv-privatenet-manage"></div>
{/if}
    </section>
{/if}
