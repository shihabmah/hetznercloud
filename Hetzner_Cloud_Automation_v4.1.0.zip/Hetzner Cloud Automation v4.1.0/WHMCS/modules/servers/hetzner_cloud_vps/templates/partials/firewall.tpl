{if $features.firewall}
    <section class="hcv-panel" data-hcv-panel="firewall" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.firewall_note|default:'Use ::/0 to match all IPv6 addresses and 0.0.0.0/0 to match all IPv4 addresses.'}</span>
        </p>
        <div class="hcv-panel-footer">
            <button type="button" id="hcv-firewall-new" class="hcv-btn hcv-btn-primary">
                <i class="fas fa-plus" aria-hidden="true"></i><span>{$LANG.btn_new_firewall|default:'New Firewall'}</span>
            </button>
            <div id="hcv-firewall-apply" class="hcv-inline-form" hidden></div>
        </div>
        <div class="hcv-table-toolbar" id="hcv-firewall-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-firewall-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.firewall_name|default:'Name'}</th>
                    <th>{$LANG.firewall_rules|default:'Rules'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="hcv-firewall-body">
                <tr><td colspan="3" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-firewall-pagination" class="hcv-pagination" hidden></div>

        <div id="hcv-firewall-form" class="hcv-form-card" hidden>
            <input type="hidden" id="hcv-firewall-id" value="">
            <label>{$LANG.firewall_name|default:'Name'}
                <input type="text" id="hcv-firewall-name" class="hcv-input">
            </label>
            <div id="hcv-firewall-rules"></div>
            <button type="button" id="hcv-firewall-add-rule" class="hcv-btn hcv-btn-sm">
                <i class="fas fa-plus" aria-hidden="true"></i><span>{$LANG.btn_add_rule|default:'Add Rule'}</span>
            </button>
            <div class="hcv-form-actions">
                <button type="button" id="hcv-firewall-cancel" class="hcv-btn">
                    <i class="fas fa-times" aria-hidden="true"></i><span>{$LANG.btn_cancel|default:'Cancel'}</span>
                </button>
                <button type="button" id="hcv-firewall-save" class="hcv-btn hcv-btn-primary">
                    <i class="fas fa-save" aria-hidden="true"></i><span>{$LANG.btn_save|default:'Save'}</span>
                </button>
            </div>
        </div>
    </section>
{/if}
