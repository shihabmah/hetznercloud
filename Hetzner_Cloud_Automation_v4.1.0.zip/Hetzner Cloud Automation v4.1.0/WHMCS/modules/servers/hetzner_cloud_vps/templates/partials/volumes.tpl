{if $features.volumes}
    <section class="hcv-panel" data-hcv-panel="volumes" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.volumes_note|default:'Block storage attached to this server. Resizing only ever grows a volume, and the filesystem inside the server must be grown separately.'}</span>
        </p>
                <div class="hcv-table-toolbar" id="hcv-volumes-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-volumes-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.volume_name|default:'Name'}</th>
                    <th>{$LANG.volume_size|default:'Size'}</th>
                    <th>{$LANG.volume_device|default:'Device'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="hcv-volumes-body">
                <tr><td colspan="4" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-volumes-pagination" class="hcv-pagination" hidden></div>
        <div id="hcv-volume-attach" class="hcv-inline-form" hidden></div>
    </section>
{/if}
