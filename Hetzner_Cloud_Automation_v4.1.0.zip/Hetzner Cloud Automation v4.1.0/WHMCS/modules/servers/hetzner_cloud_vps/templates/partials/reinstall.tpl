{if $features.reinstall}
    <section class="hcv-panel" data-hcv-panel="reinstall" hidden>
        <div id="hcv-lock-bar" class="hcv-lock-bar">
            <div class="hcv-lock-info">
                <i class="fas fa-shield-alt" aria-hidden="true"></i>
                <div>
                    <strong>{$LANG.lock_title|default:'Action Protection'}</strong>
                    <span class="hcv-muted">{$LANG.lock_help|default:'Blocks reinstall and rebuild from this dashboard until it is switched off.'}</span>
                </div>
            </div>
            <div class="hcv-lock-controls">
                <span class="hcv-badge" id="hcv-lock-badge">—</span>
                <label class="hcv-switch">
                    <input type="checkbox" id="hcv-lock-toggle">
                    <span class="hcv-switch-track"><span class="hcv-switch-thumb"></span></span>
                </label>
            </div>
        </div>
        <p class="hcv-note hcv-note-danger">
            <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.reinstall_warning|default:'Reinstalling ERASES all data on the server. This cannot be undone.'}</span>
        </p>
        <p class="hcv-note" id="hcv-reinstall-blocked" hidden>
            <i class="fas fa-lock" aria-hidden="true"></i><span id="hcv-reinstall-blocked-text"></span>
        </p>
        <p class="hcv-current-os" id="hcv-reinstall-current" hidden>
            <span class="hcv-detail-label">{$LANG.reinstall_current|default:'Currently installed'}</span>
            <strong id="hcv-reinstall-current-name"></strong>
        </p>
        <div class="hcv-loading-host" id="hcv-reinstall-host">
            <div id="hcv-reinstall-images"></div>
            <div class="hcv-spinner-overlay" id="hcv-reinstall-spinner" hidden>
                <span class="hcv-spinner" aria-hidden="true"></span>
                <span>{$LANG.loading|default:'Loading…'}</span>
            </div>
        </div>
        <div class="hcv-panel-footer">
            <button type="button" id="hcv-reinstall-submit" class="hcv-btn hcv-btn-danger" disabled>
                <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.btn_reinstall|default:'Reinstall'}</span>
            </button>
            <span class="hcv-selection" id="hcv-reinstall-selection">{$LANG.select_nothing|default:'Nothing selected yet.'}</span>
        </div>
    </section>
{/if}
