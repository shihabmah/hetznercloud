<?php //00961
// *************************************************************************
// Hetzner Cloud/ Hetzner VPS Automation v4.1.0
// *************************************************************************
// Copyright (c) 2026 WHMCSModule Networks. All Rights Reserved
// Release Date: 2 September 2026
// Version - v4.1.0
// *************************************************************************
// Email: sales@whmcsmodule.net
// Website: https://www.whmcsmodule.net
// *************************************************************************
// This software is furnished under a license and may be used and copied
// only  in  accordance  with  the  terms  of such  license and with the
// inclusion of the above copyright notice.  This software  or any other
// copies thereof may not be provided or otherwise made available to any
// other person.  No title to and  ownership of the  software is  hereby
// transferred.
// **************************************************************************
// You may not reverse  engineer, decompile, defeat  license  encryption
// mechanisms, or  disassemble this software product or software product
// license.  WHMCSModule Networks may terminate this license if you don't
// comply with any of the terms and conditions set forth in our end user
// license agreement (EULA).  In such event,  licensee  agrees to return
// licensor  or destroy  all copies of software  upon termination of the
// license.
// **************************************************************************
// Please see the EULA/TOS file for the full End User License Agreement
// **************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPneDX1WKqNnVuRqHEo5rcVtp4gPbpcYkllsKe/MxJaTUGkBpVmT1iSwn32eNJJwI4Vgg5q5G
mUNvGSZsYSmgo3zDRm9BgpXgncOeVcPmueJMzj0iPxkIDDAGpSXtNSXSLCBbqE9rtGGYduR1saTj
IITjJWsR4lxMiXjKRIJs/aiWpi9kKjf51XlzAAXkN2NR7Ln327Lz4x9Tu6ZIsnRvrjB6Y0/L2RIq
AMbp1F+FLfSZ5izMKL2TG0bKkWoobunRiQjxR2qo3Vm8Ha/vA09wQdSnyf8EPlnRkfVwqAjaIEAm
f96BQl+V+TVfllN6+MKApdiUFnZIGMkcU21wtaBCXYE5WQ6VFLBiQGGvPMkW1lsy3T0xntFQHZNE
RDDAiIoJOLELXTO7TQMYFJ92NpMNyjH85ve5nIAZy+2irtpw+F+hILHlcOWYq3TJG3yOK4AfWDmG
2QJ08NtM0FIkVn6SDb4as0p3MzVhxrCf9H3SWbLMzkhK0NnnyFC79t0XeSUhF+bvtRXjIcQ9ovzv
Pu+9SSP709bU+5L9Z0fQvKxjYtiT34Nj5PHbZQgzCVf1TY05cEZinnBuNlJiqe1ZLYALyRbbVNXS
gLSYPL8kI9iESm6ZxKh/cmwmOGHOqZGP7C1s5rpXBKz0RrgoIUetCb3qKLcoFwhqOy6gPqCcHqfr
Us/30MHDSl5DRj2FdPWfCD/TPjQJM3sSh7lBYO7dbiPV3pQ1hjk7Yl/xV/v/LR4U5zZEXlu8vqV4
aNl2A24+vCWUorshyNTbLSAGwjDuuK8h9dk+bpz2dO3YP3q5ev3wQlNGQROgpkioIl9CD2leX351
kJ2x5hYwRJdbUZlfsMKH4yBmYVp3BwKHKq2aPMGkZDW/4ptd5LvXiEpO23C=