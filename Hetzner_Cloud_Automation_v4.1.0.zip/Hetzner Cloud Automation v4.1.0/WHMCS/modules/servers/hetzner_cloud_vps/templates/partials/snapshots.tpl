{if $features.snapshots}
    <section class="hcv-panel" data-hcv-panel="snapshots" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.snapshots_note|default:'Snapshots you create and automatic backups the provider takes, both restorable. Backups are removed only by turning backups off.'}</span>
        </p>
{if !$isAdmin}
        <p class="hcv-note hcv-note-warning">
            <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.snapshots_client_note|default:'A snapshot you take is kept until support removes it, and its storage is billed for as long as it exists. You can create and restore snapshots here; deleting one is done by support.'}</span>
        </p>
{/if}
{if $features.backups}
        <div class="hcv-panel-footer">
            <label class="hcv-switch">
                <input type="checkbox" id="hcv-backup-toggle">
                <span class="hcv-switch-track"><span class="hcv-switch-thumb"></span></span>
                <span class="hcv-switch-text">{$LANG.backups_auto|default:'Automatic backups'}</span>
            </label>
            <span class="hcv-backup-window" id="hcv-backup-window" hidden>
                <i class="fas fa-clock" aria-hidden="true"></i>
                <span class="hcv-backup-window-label">{$LANG.backup_window|default:'Backup window'}</span>
                <strong id="hcv-backup-window-value"></strong>
                <span class="hcv-backup-window-zone">{$LANG.backup_window_zone|default:'UTC'}</span>
            </span>
        </div>
{/if}

        <div class="hcv-inline-form">
            <input type="text" id="hcv-snapshot-description" class="hcv-input" placeholder="{$LANG.snapshot_description_placeholder|default:'Description (optional)'}">
            <button type="button" id="hcv-snapshot-create" class="hcv-btn hcv-btn-primary">
                <i class="fas fa-camera" aria-hidden="true"></i><span>{$LANG.btn_create|default:'Create Snapshot'}</span>
            </button>
        </div>
                <div class="hcv-table-toolbar" id="hcv-snapshots-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-snapshots-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
{if $isAdmin}
        <div class="hcv-schedule-card">
            <h4 class="hcv-panel-subheading">{$LANG.schedule_heading|default:'Scheduled Snapshots'}</h4>
            <p class="hcv-note hcv-note-warning">
                <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.schedule_not_api|default:'The datacenter has no snapshot schedule of its own. This runs from the WHMCS daily cron inside this module, so it only fires while that cron runs, and a missed day is simply skipped rather than caught up.'}</span>
            </p>
            <p class="hcv-note hcv-note-warning">
                <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.schedule_cost|default:'Snapshot storage is charged by the provider per GB per month. Every kept snapshot adds to that bill, so choose the retention count deliberately.'}</span>
            </p>
            <div class="hcv-inline-form">
                <label for="hcv-schedule-frequency">{$LANG.schedule_frequency|default:'Frequency'}</label>
                <select id="hcv-schedule-frequency" class="hcv-input">
                    <option value="off">{$LANG.schedule_off|default:'Off'}</option>
                    <option value="daily">{$LANG.schedule_daily|default:'Daily'}</option>
                    <option value="weekly">{$LANG.schedule_weekly|default:'Weekly'}</option>
                </select>
                <label for="hcv-schedule-keep">{$LANG.schedule_keep|default:'Keep'}</label>
                <input type="number" id="hcv-schedule-keep" class="hcv-input" min="1" max="30" value="3">
                <button type="button" id="hcv-schedule-save" class="hcv-btn hcv-btn-primary">
                    <i class="fas fa-save" aria-hidden="true"></i><span>{$LANG.btn_save|default:'Save'}</span>
                </button>
                <span class="hcv-selection" id="hcv-schedule-status"></span>
            </div>
        </div>
{/if}

        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.snapshot_description|default:'Description'}</th>
                    <th>{$LANG.snapshot_type|default:'Type'}</th>
                    <th>{$LANG.snapshot_size|default:'Size'}</th>
                    <th>{$LANG.snapshot_created|default:'Created'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="hcv-snapshots-body">
                <tr><td colspan="5" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-snapshots-pagination" class="hcv-pagination" hidden></div>
    </section>
{/if}
