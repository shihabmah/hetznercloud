    <section class="hcv-panel" data-hcv-panel="overview">
        <div class="hcv-overview-split">
        <div class="hcv-overview-main">
        <div class="hcv-detail-grid">
{if $isAdmin}
            <div class="hcv-detail-item">
                <span class="hcv-detail-label">{$LANG.detail_created|default:'Created'}</span>
                <span class="hcv-detail-value" id="hcv-detail-created">—</span>
            </div>
{/if}
            <div class="hcv-detail-item">
                <span class="hcv-detail-label">{$LANG.detail_iso|default:'Mounted ISO'}</span>
                <span class="hcv-detail-value" id="hcv-detail-iso">—</span>
            </div>
        </div>

{if $features.protection || $features.rescue}
        <h4 class="hcv-panel-subheading">{$LANG.protection_heading|default:'Protection &amp; Rescue'}</h4>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.protection_note|default:'Protection blocks destructive actions at the provider, independently of this dashboard. Rescue boots a recovery system on the next reset.'}</span>
        </p>
        <div class="hcv-detail-grid">
{if $features.protection}
            <div class="hcv-detail-item">
                <span class="hcv-detail-label">{$LANG.protection_delete|default:'Delete Protection'}</span>
                <span class="hcv-detail-value hcv-toggle-row">
                    <span id="hcv-protect-delete-badge" class="hcv-badge hcv-badge-neutral">{$LANG.word_off|default:'Off'}</span>
                    <label class="hcv-switch">
                        <input type="checkbox" id="hcv-protect-delete">
                        <span class="hcv-switch-track"><span class="hcv-switch-thumb"></span></span>
                        <span class="hcv-switch-text" id="hcv-protect-delete-text">{$LANG.word_off|default:'Off'}</span>
                    </label>
                </span>
            </div>
            <div class="hcv-detail-item">
                <span class="hcv-detail-label">{$LANG.protection_rebuild|default:'Rebuild Protection'}</span>
                <span class="hcv-detail-value hcv-toggle-row">
                    <span id="hcv-protect-rebuild-badge" class="hcv-badge hcv-badge-neutral">{$LANG.word_off|default:'Off'}</span>
                    <label class="hcv-switch">
                        <input type="checkbox" id="hcv-protect-rebuild">
                        <span class="hcv-switch-track"><span class="hcv-switch-thumb"></span></span>
                        <span class="hcv-switch-text" id="hcv-protect-rebuild-text">{$LANG.word_off|default:'Off'}</span>
                    </label>
                </span>
            </div>
{/if}
{if $features.rescue}
            <div class="hcv-detail-item">
                <span class="hcv-detail-label">{$LANG.rescue_label|default:'Rescue System'}</span>
                <span class="hcv-detail-value">
                    <span id="hcv-rescue-state" class="hcv-badge hcv-badge-neutral">{$LANG.word_off|default:'Off'}</span>
                    <button type="button" id="hcv-rescue-toggle" class="hcv-btn hcv-btn-sm">
                        <i class="fas fa-life-ring" aria-hidden="true"></i><span id="hcv-rescue-btn-text">{$LANG.btn_enable|default:'Enable'}</span>
                    </button>
                </span>
            </div>
{/if}
        </div>
{/if}
        </div>

        <div class="hcv-region-card" id="hcv-region-map" hidden>
            <span class="hcv-detail-label">{$LANG.detail_region|default:'Region'}</span>
            <div class="hcv-region-body">
                <span class="hcv-region-flag" id="hcv-region-flag" aria-hidden="true"></span>
                <div>
                    <span class="hcv-region-city" id="hcv-region-city">—</span>
                    <span class="hcv-region-meta" id="hcv-region-meta"></span>
                </div>
            </div>
            <dl class="hcv-region-facts">
                <div>
                    <dt>{$LANG.region_latitude|default:'Latitude'}</dt>
                    <dd id="hcv-region-lat">—</dd>
                </div>
                <div>
                    <dt>{$LANG.region_longitude|default:'Longitude'}</dt>
                    <dd id="hcv-region-lon">—</dd>
                </div>
            </dl>
            <a class="hcv-region-link" id="hcv-region-link" href="#" target="_blank" rel="noopener noreferrer nofollow" hidden>
                <i class="fas fa-map-marked-alt" aria-hidden="true"></i><span>{$LANG.region_view_map|default:'View on a map'}</span>
            </a>
        </div>
        </div>

        {if $isAdmin}
        <div class="hcv-admin-block">
            <h4>{$LANG.admin_block_title|default:'Account (Admin Only)'}</h4>
            <div class="hcv-detail-grid">
                <div class="hcv-detail-item">
                    <span class="hcv-detail-label">{$LANG.admin_server_id|default:'Server ID'}</span>
                    <span class="hcv-detail-value" id="hcv-admin-serverid">—</span>
                </div>
                <div class="hcv-detail-item">
                    <span class="hcv-detail-label">{$LANG.admin_server_type|default:'Server Type'}</span>
                    <span class="hcv-detail-value" id="hcv-admin-servertype">—</span>
                </div>
            </div>
        </div>
        {/if}

{if $isAdmin && $features.resize}
        <h4 class="hcv-panel-subheading" data-hcv-adminhint="changeplan">{$LANG.resize_heading|default:'Change Plan'}</h4>
        <p class="hcv-note hcv-note-warning">
            <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.resize_note|default:'The server must be powered off. Growing the disk is permanent — once it has grown, the server can never move back to a smaller plan.'}</span>
        </p>
        <div id="hcv-resize-block" class="hcv-inline-form"></div>
{/if}

        <h4 class="hcv-panel-subheading">{$LANG.credentials_heading|default:'Credentials'}</h4>
        <p class="hcv-note hcv-note-warning">
            <i class="fas fa-exclamation-triangle" aria-hidden="true"></i><span>{$LANG.credentials_warning|default:'Resetting generates a brand-new root password and immediately invalidates the previous one. The server must be running, because the new password is applied by the guest agent.'}</span>
        </p>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.cred_type|default:'Operating System'}</th>
                    <th>{$LANG.cred_username|default:'Username'}</th>
                    <th>{$LANG.cred_password|default:'Password'}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td id="hcv-cred-type">—</td>
                    <td id="hcv-cred-username">—</td>
                    <td><code id="hcv-cred-password">••••••••</code></td>
                    <td>
                        <button type="button" id="hcv-cred-toggle" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_show|default:'Show'}">
                            <i class="fas fa-eye" aria-hidden="true"></i><span>{$LANG.btn_show|default:'Show'}</span>
                        </button>
                        <button type="button" id="hcv-cred-copy" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_copy|default:'Copy'}" hidden>
                            <i class="fas fa-copy" aria-hidden="true"></i><span>{$LANG.btn_copy|default:'Copy'}</span>
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </section>
