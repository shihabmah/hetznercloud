{if $features.console}
    <section class="hcv-panel" data-hcv-panel="console" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.console_note|default:'The console gives you keyboard and screen access to the server itself, even when it is unreachable over the network. The server must be running.'}</span>
        </p>
        <div class="hcv-panel-footer">
            <div class="hcv-console-toolbar">
                <button type="button" id="hcv-console-connect" class="hcv-btn hcv-btn-primary">
                    <i class="fas fa-terminal" aria-hidden="true"></i><span>{$LANG.btn_console_connect|default:'Connect'}</span>
                </button>
                <button type="button" id="hcv-console-reconnect" class="hcv-btn" hidden>
                    <i class="fas fa-sync" aria-hidden="true"></i><span>{$LANG.btn_console_reconnect|default:'Reconnect'}</span>
                </button>
                <button type="button" id="hcv-console-disconnect" class="hcv-btn hcv-btn-danger" hidden>
                    <i class="fas fa-times" aria-hidden="true"></i><span>{$LANG.btn_console_disconnect|default:'Disconnect'}</span>
                </button>
            </div>
        </div>
        <div class="hcv-console-credentials">
            <span class="hcv-detail-label">{$LANG.console_login|default:'Console login'}</span>
            <div class="hcv-console-credential-row">
                <span><strong id="hcv-console-username">root</strong></span>
                <code id="hcv-console-password">&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</code>
                <button type="button" id="hcv-console-password-toggle" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_show|default:'Show'}">
                    <i class="fas fa-eye" aria-hidden="true"></i><span>{$LANG.btn_show|default:'Show'}</span>
                </button>
                <button type="button" id="hcv-console-password-copy" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_copy|default:'Copy'}">
                    <i class="fas fa-copy" aria-hidden="true"></i><span>{$LANG.btn_copy|default:'Copy'}</span>
                </button>
            </div>
            <p class="hcv-form-hint">{$LANG.console_login_hint|default:'The root password recorded for this service. If it was changed inside the server, this no longer matches — reset it from Overview.'}</p>
        </div>

        <div id="hcv-console-rescue" class="hcv-note hcv-note-warning" hidden>
            <i class="fas fa-life-ring" aria-hidden="true"></i>
            <span>
                {$LANG.console_rescue_prefix|default:'Rescue system is armed. Root password for the rescue console:'}
                <code id="hcv-console-rescue-password">&mdash;</code>
            </span>
            <button type="button" id="hcv-console-rescue-copy" class="hcv-btn hcv-btn-sm hcv-btn-icon" title="{$LANG.btn_copy|default:'Copy'}">
                <i class="fas fa-copy" aria-hidden="true"></i><span>{$LANG.btn_copy|default:'Copy'}</span>
            </button>
        </div>
        <div class="hcv-console-stage">
            <p id="hcv-console-placeholder" class="hcv-console-placeholder">{$LANG.console_idle|default:'Not connected.'}</p>
            <iframe id="hcv-console-frame" src="about:blank" title="{$LANG.console_title|default:'Remote Console'}" hidden></iframe>
        </div>
    </section>
{/if}
