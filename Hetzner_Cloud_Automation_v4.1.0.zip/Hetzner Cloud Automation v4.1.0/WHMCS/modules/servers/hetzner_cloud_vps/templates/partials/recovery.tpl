{if $features.recovery}
    <section class="hcv-panel" data-hcv-panel="recovery" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.isoimages_note|default:'Attach an ISO image, then restart the server to boot from it.'}</span>
        </p>
        <div id="hcv-iso-banner" class="hcv-note hcv-note-warning" hidden>
            <span>{$LANG.iso_attached_prefix|default:'Attached ISO:'} <strong id="hcv-iso-banner-name"></strong></span>
            <button type="button" id="hcv-iso-detach" class="hcv-btn hcv-btn-sm hcv-btn-danger">
                <i class="fas fa-eject" aria-hidden="true"></i><span>{$LANG.btn_detach|default:'Detach'}</span>
            </button>
        </div>
        <div class="hcv-loading-host" id="hcv-iso-host">
            <div id="hcv-iso-cards"></div>
            <div class="hcv-spinner-overlay" id="hcv-iso-spinner" hidden>
                <span class="hcv-spinner" aria-hidden="true"></span>
                <span>{$LANG.loading|default:'Loading…'}</span>
            </div>
        </div>
        <div class="hcv-panel-footer">
            <button type="button" id="hcv-iso-attach-submit" class="hcv-btn hcv-btn-primary" disabled>
                <i class="fas fa-compact-disc" aria-hidden="true"></i><span>{$LANG.btn_attach|default:'Attach'}</span>
            </button>
            <span class="hcv-selection" id="hcv-iso-selection">{$LANG.select_nothing|default:'Nothing selected yet.'}</span>
            <div id="hcv-iso-pagination" class="hcv-pagination"></div>
        </div>
    </section>
{/if}
