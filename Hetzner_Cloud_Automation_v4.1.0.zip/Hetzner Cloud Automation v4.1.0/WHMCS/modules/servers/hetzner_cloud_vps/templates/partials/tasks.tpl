{if $features.tasks}
    <section class="hcv-panel" data-hcv-panel="tasks" hidden>
        <p class="hcv-note">
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.tasks_note|default:'Every task the provider has run against this server, including any started outside this dashboard.'}</span>
        </p>
        <div class="hcv-panel-footer">
            <button type="button" id="hcv-tasks-refresh" class="hcv-btn hcv-btn-sm">
                <i class="fas fa-sync" aria-hidden="true"></i><span>{$LANG.btn_refresh|default:'Refresh'}</span>
            </button>
        </div>
        <div class="hcv-table-toolbar" id="hcv-tasks-search-wrap">
            <div class="hcv-table-search">
                <i class="fas fa-search" aria-hidden="true"></i>
                <input type="text" id="hcv-tasks-search" placeholder="{$LANG.search_placeholder|default:'Search…'}" aria-label="{$LANG.search_placeholder|default:'Search…'}">
            </div>
        </div>
        <table class="hcv-table">
            <thead>
                <tr>
                    <th>{$LANG.tasks_command|default:'Task'}</th>
                    <th>{$LANG.tasks_status|default:'Status'}</th>
                    <th>{$LANG.tasks_started|default:'Started'}</th>
                    <th>{$LANG.tasks_finished|default:'Finished'}</th>
                </tr>
            </thead>
            <tbody id="hcv-tasks-body">
                <tr><td colspan="4" class="hcv-empty-row">{$LANG.loading|default:'Loading…'}</td></tr>
            </tbody>
        </table>
        <div id="hcv-tasks-pagination" class="hcv-pagination"></div>
        <p class="hcv-note hcv-note-sm" id="hcv-tasks-truncated" hidden>
            <i class="fas fa-info-circle" aria-hidden="true"></i><span>{$LANG.tasks_truncated|default:'Showing the 50 most recent tasks. Search covers those.'}</span>
        </p>
    </section>
{/if}
