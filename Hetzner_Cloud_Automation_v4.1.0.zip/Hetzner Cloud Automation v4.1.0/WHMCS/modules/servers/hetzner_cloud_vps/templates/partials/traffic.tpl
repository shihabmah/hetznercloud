{if $features.traffic}
    <section class="hcv-panel" data-hcv-panel="traffic" hidden>
        <div class="hcv-pill-row hcv-pill-row-metric">
            <button type="button" class="hcv-pill active" data-hcv-metric="network">{$LANG.metric_network|default:'Network Traffic'}</button>
            <button type="button" class="hcv-pill" data-hcv-metric="networkPps">{$LANG.metric_network_pps|default:'Network PPS'}</button>
            <button type="button" class="hcv-pill" data-hcv-metric="cpu">{$LANG.metric_cpu|default:'CPU'}</button>
            <button type="button" class="hcv-pill" data-hcv-metric="diskBandwidth">{$LANG.metric_disk|default:'Disk Throughput'}</button>
            <button type="button" class="hcv-pill" data-hcv-metric="diskIops">{$LANG.metric_disk_iops|default:'Disk IOPS'}</button>
        </div>
        <div class="hcv-pill-row">
            <button type="button" class="hcv-pill" data-hcv-range="live">{$LANG.range_live|default:'Live'}</button>
            <button type="button" class="hcv-pill active" data-hcv-range="today">{$LANG.range_today|default:'Today'}</button>
            <button type="button" class="hcv-pill" data-hcv-range="yesterday">{$LANG.range_yesterday|default:'Yesterday'}</button>
            <button type="button" class="hcv-pill" data-hcv-range="last7">{$LANG.range_last7|default:'Last 7 Days'}</button>
            <button type="button" class="hcv-pill" data-hcv-range="currentmonth">{$LANG.range_currentmonth|default:'Current Month'}</button>
            <button type="button" class="hcv-pill" data-hcv-range="lastmonth">{$LANG.range_lastmonth|default:'Last Month'}</button>
            <button type="button" class="hcv-pill" data-hcv-range="custom">{$LANG.range_custom|default:'Custom'}</button>
        </div>
        <div class="hcv-live" id="hcv-traffic-live">
            <span class="hcv-live-dot" aria-hidden="true"></span>
            <span>{$LANG.traffic_live|default:'Live — refreshing automatically'}</span>
        </div>
        <div id="hcv-traffic-custom" class="hcv-inline-form" hidden>
            <label>{$LANG.range_from|default:'From'} <input type="date" id="hcv-traffic-from" class="hcv-input"></label>
            <label>{$LANG.range_to|default:'To'} <input type="date" id="hcv-traffic-to" class="hcv-input"></label>
            <button type="button" id="hcv-traffic-apply" class="hcv-btn hcv-btn-primary">
                <i class="fas fa-check" aria-hidden="true"></i><span>{$LANG.btn_apply|default:'Apply'}</span>
            </button>
        </div>

        <div class="hcv-stat-tiles" id="hcv-traffic-totals">
            <div class="hcv-stat-tile">
                <i class="fas fa-arrow-up" aria-hidden="true"></i>
                <div><span class="hcv-stat-label">{$LANG.traffic_out|default:'Outgoing'}</span><span class="hcv-stat-value" id="hcv-traffic-total-out">—</span></div>
            </div>
            <div class="hcv-stat-tile">
                <i class="fas fa-arrow-down" aria-hidden="true"></i>
                <div><span class="hcv-stat-label">{$LANG.traffic_in|default:'Incoming'}</span><span class="hcv-stat-value" id="hcv-traffic-total-in">—</span></div>
            </div>
        </div>

        <div class="hcv-traffic-chart-wrap" id="hcv-traffic-chart-wrap">
            <canvas id="hcv-traffic-canvas"></canvas>
            <div class="hcv-traffic-tooltip" id="hcv-traffic-tooltip" hidden>
                <strong id="hcv-tooltip-time"></strong>
                <span id="hcv-tooltip-out"></span><br>
                <span id="hcv-tooltip-in"></span>
            </div>
            <div class="hcv-spinner-overlay" id="hcv-traffic-spinner" hidden>
                <span class="hcv-spinner" aria-hidden="true"></span>
                <span>{$LANG.loading|default:'Loading…'}</span>
            </div>
        </div>
    </section>
{/if}
